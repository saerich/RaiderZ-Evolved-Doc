#pragma once
#include "PMSConnWrapper.h"
#include "IPMSObject.h"
//#include <vector>

class CCallBackObj : public IPMSObject
{
public:						// �⺻ ó�� �Լ� 
	CCallBackObj(void);
	virtual ~CCallBackObj(void);
	virtual BOOL OnAnnounceReq(DWORD dwSSN, DWORD dwCategoryID, LPCSTR lpszMsg);
	virtual BOOL OnHeartbeatReq(LONG lIndex);
	virtual BOOL OnRegionInfoReq(IPMSRegionInfoList* plstRegionInfo);
	virtual BOOL OnStatInfoReq(IPMSStatInfoList* plstStatInfo);
	virtual BOOL OnPerformInfoReq(IPMSPerformanceInfo *pPerformanceInfo);
	virtual BOOL OnOrderReq(LPCSTR lpszCmdName, LPCSTR lpszCtlVal, LPSTR lpResult, LONG *lpResultLen, DWORD dwSSN, DWORD dwCategoryID);
	virtual BOOL OnRegionInfoPCReq(IPMSRegionInfoListPC* plstRegionInfoPC);
	virtual BOOL OnStatInfoPCReq(IPMSStatInfoListPC* plstStatInfoPC);

public:
	typedef std::vector<LONG> vecRegion;
	void SetStatInfo(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt);
	void SetPerfInfo(LONG aPerformanceInfo[]);
	void SetRegionInfo(vecRegion& vec);

	void SetStatInfoPC(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt);
	void SetRegionInfoPC(vecRegion& vec);

	// for TEST
	void SetHeartBeat(BOOL type);

private:
	DWORD m_dwSSN;
	DWORD m_dwCategory;
	DWORD m_dwCU;
    DWORD m_dwSession;	
	DWORD m_dwChannelCnt;
	DWORD m_dwRoomCnt;
	LONG m_aPerformanceInfo[10];
	vecRegion m_vRegionInfo;

	DWORD m_dwCU_PC;
	BOOL bHeartBeat;
	vecRegion m_vRegionInfoPC;
};

