// PMSConnSampleView.cpp : CPMSConnSampleView Ŭ������ ����
//

#include "stdafx.h"
#include "PMSConnSample.h"
#include "PMSConnSampleDoc.h"
#include "PMSConnSampleView.h"
#include "CallBackObj.h"

CPMSConnWrapper<CCallBackObj> thePMSConn;

#include <string>
#include ".\pmsconnsampleview.h"
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPMSConnSampleView
IMPLEMENT_DYNCREATE(CPMSConnSampleView, CFormView)

BEGIN_MESSAGE_MAP(CPMSConnSampleView, CFormView)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnBnClickedButton5)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_ADDED, OnLvnItemchangedListAdded)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_ADDED, OnNMDblclkListAdded)
	ON_BN_CLICKED(IDC_BUTTON6, OnBnClickedButton6)
	ON_NOTIFY(NM_CLICK, IDC_LIST_REGION, OnNMClickListRegion)
	ON_BN_CLICKED(IDC_RADIO_MAN, OnBnClickedRadioMan)
	ON_BN_CLICKED(IDC_RADIO_WOMAN, OnBnClickedRadioWoman)
	ON_BN_CLICKED(IDC_RADIO_AGE0013, OnBnClickedRadioAge0013)
	ON_BN_CLICKED(IDC_RADIO_AGE1416, OnBnClickedRadioAge1416)
	ON_BN_CLICKED(IDC_RADIO_AGE1719, OnBnClickedRadioAge1719)
	ON_BN_CLICKED(IDC_RADIO_AGE2024, OnBnClickedRadioAge2024)
	ON_BN_CLICKED(IDC_RADIO_AGE2529, OnBnClickedRadioAge2529)
	ON_BN_CLICKED(IDC_RADIO_AGE3039, OnBnClickedRadioAge3039)
	ON_BN_CLICKED(IDC_RADIO_AGE4099, OnBnClickedRadioAge4099)
	ON_BN_CLICKED(IDC_RADIO_MODE_NORMAL, OnBnClickedRadioModeNormal)
	ON_BN_CLICKED(IDC_RADIO_MODE_PCROOM, OnBnClickedRadioModePcroom)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON7, OnBnClickedButton7)
END_MESSAGE_MAP()

// CPMSConnSampleView ����/�Ҹ�

CPMSConnSampleView::CPMSConnSampleView()
	: CFormView(CPMSConnSampleView::IDD)
	, m_idc_edit1(0)
	, m_idc_edit2(0)
	, m_idc_edit3(0)
	, m_idc_edit4(0)
	, m_idc_edit5(0)
	, m_idc_edit6(0)
	, m_idc_edit_pfm1(0)
	, m_idc_edit_pfm2(0)
	, m_idc_edit_pfm3(0)
	, m_idc_edit_pfm4(0)
	, m_idc_edit_pfm5(0)
	, m_idc_edit_pfm6(0)
	, m_idc_edit_pfm7(0)
	, m_idc_edit_pfm8(0)
	, m_idc_edit_pfm9(0)
	, m_idc_edit_pfm10(0)
	, m_edit_addcount(0)
{
	bWorkingPMSConn = FALSE;

	m_current_region = -1;
	m_current_age = -1;
	m_current_gender = -1;
	m_current_mode = 0;
}

CPMSConnSampleView::~CPMSConnSampleView()
{
}

void CPMSConnSampleView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_idc_edit1);	// dwSSN 
	DDX_Text(pDX, IDC_EDIT2, m_idc_edit2);	// dwCategory 
	DDX_Text(pDX, IDC_EDIT3, m_idc_edit3);	// dwCU 
	DDX_Text(pDX, IDC_EDIT4, m_idc_edit4);	// dwSession 
	DDX_Text(pDX, IDC_EDIT5, m_idc_edit5);	// dwChannelCnt 
	DDX_Text(pDX, IDC_EDIT6, m_idc_edit6);	// dwRoomCnt 
	DDX_Text(pDX, IDC_EDIT_PFM1, m_idc_edit_pfm1);
	DDX_Text(pDX, IDC_EDIT_PFM2, m_idc_edit_pfm2);
	DDX_Text(pDX, IDC_EDIT_PFM3, m_idc_edit_pfm3);
	DDX_Text(pDX, IDC_EDIT_PFM4, m_idc_edit_pfm4);
	DDX_Text(pDX, IDC_EDIT_PFM5, m_idc_edit_pfm5);
	DDX_Text(pDX, IDC_EDIT_PFM6, m_idc_edit_pfm6);
	DDX_Text(pDX, IDC_EDIT_PFM7, m_idc_edit_pfm7);
	DDX_Text(pDX, IDC_EDIT_PFM8, m_idc_edit_pfm8);
	DDX_Text(pDX, IDC_EDIT_PFM9, m_idc_edit_pfm9);
	DDX_Text(pDX, IDC_EDIT_PFM10, m_idc_edit_pfm10);
	DDX_Control(pDX, IDC_LIST_REGION, m_list_region);
	DDX_Control(pDX, IDC_LIST_ADDED, m_list_added);
	DDX_Text(pDX, IDC_EDIT_ADDCOUNT, m_edit_addcount);
}

BOOL CPMSConnSampleView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	// Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CFormView::PreCreateWindow(cs);
}

void CPMSConnSampleView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	InitDefaultValue();
	InitPMSConn();
}

// CPMSConnSampleView ����

#ifdef _DEBUG
void CPMSConnSampleView::AssertValid() const
{
	CFormView::AssertValid();
}

void CPMSConnSampleView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CPMSConnSampleDoc* CPMSConnSampleView::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPMSConnSampleDoc)));
	return (CPMSConnSampleDoc*)m_pDocument;
}
#endif //_DEBUG

void CPMSConnSampleView::InitDefaultValue(void)
{
	//CWnd *radio_btn = GetDlgItem(IDC_RADIO_MODE_NORMAL);
	//::SendMessage(radio_btn->m_hWnd, BM_SETCHECK, 0, 0);

	GetDlgItem(IDC_RADIO_MODE_NORMAL)->SendMessage(BM_SETCHECK, BST_CHECKED, 0);

	LV_COLUMN lvcolumn1;
	lvcolumn1.mask = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvcolumn1.fmt	= LVCFMT_LEFT;
	lvcolumn1.pszText	=	_T("����");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 98;
	m_list_region.InsertColumn(0, &lvcolumn1);
	m_list_region.InsertItem(0, _T("���"));
	m_list_region.InsertItem(1, _T("����"));
	m_list_region.InsertItem(2, _T("��õ"));
	m_list_region.InsertItem(3, _T("����"));
	m_list_region.InsertItem(4, _T("����"));
	m_list_region.InsertItem(5, _T("����"));
	m_list_region.InsertItem(6, _T("����"));
	m_list_region.InsertItem(7, _T("���"));
	m_list_region.InsertItem(8, _T("�泲"));
	m_list_region.InsertItem(9, _T("�뱸"));
	m_list_region.InsertItem(10, _T("�λ�"));
	m_list_region.InsertItem(11, _T("���"));
	m_list_region.InsertItem(12, _T("����"));
	m_list_region.InsertItem(13, _T("����"));
	m_list_region.InsertItem(14, _T("����"));
	m_list_region.InsertItem(15, _T("����"));
	m_list_region.InsertItem(16, _T("�ܱ�"));

	m_list_region.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);
	m_list_region.SetBkColor(RGB(251,248,241));
	m_list_region.SetTextBkColor(RGB(251,248,241));
	m_list_region.SetTextColor(RGB(0,0,0));

	LV_COLUMN lvcolumn2;
	lvcolumn2.mask = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvcolumn2.fmt	= LVCFMT_LEFT;

	lvcolumn2.pszText	=	_T("NO");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 40;
	m_list_added.InsertColumn(0, &lvcolumn2);
	lvcolumn2.pszText	=	_T("����");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 60;
	m_list_added.InsertColumn(1, &lvcolumn2);
	lvcolumn2.pszText	=	_T("����");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 70;
	m_list_added.InsertColumn(2, &lvcolumn2);
	lvcolumn2.pszText	=	_T("����");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 60;
	m_list_added.InsertColumn(3, &lvcolumn2);
	lvcolumn2.pszText	=	_T("�ο�");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 60;
	m_list_added.InsertColumn(4, &lvcolumn2);


	m_idc_edit1 = 321; // dwSSN 
	m_idc_edit2 = 0; // dwCategory 
	m_idc_edit3 = 153; // dwCU 
	m_idc_edit4 = 279; // dwSession 
	m_idc_edit5 = 34; // dwChannelCnt 
	m_idc_edit6 = 106; // dwRoomCnt 

	m_idc_edit_pfm1 = 1;
	m_idc_edit_pfm2 = 2;
	m_idc_edit_pfm3 = 3;
	m_idc_edit_pfm4 = 4;
	m_idc_edit_pfm5 = 5;
	m_idc_edit_pfm6 = 6;
	m_idc_edit_pfm7 = 7;
	m_idc_edit_pfm8 = 8;
	m_idc_edit_pfm9 = 9;
	m_idc_edit_pfm10 = 10;

	m_aPerformanceInfo[0] = m_idc_edit_pfm1;
	m_aPerformanceInfo[1] = m_idc_edit_pfm2;
	m_aPerformanceInfo[2] = m_idc_edit_pfm3;
	m_aPerformanceInfo[3] = m_idc_edit_pfm4;
	m_aPerformanceInfo[4] = m_idc_edit_pfm5;
	m_aPerformanceInfo[5] = m_idc_edit_pfm6;
	m_aPerformanceInfo[6] = m_idc_edit_pfm7;
	m_aPerformanceInfo[7] = m_idc_edit_pfm8;
	m_aPerformanceInfo[8] = m_idc_edit_pfm9;
	m_aPerformanceInfo[9] = m_idc_edit_pfm10;

	// ����(17) * ����(7) * ����(2) = 238
	m_vRegionInfo7.clear();
	m_vRegionInfo7_PC.clear();
	for (int i=0; i<238; i++)
	{
		m_vRegionInfo7.push_back(0);
		m_vRegionInfo7_PC.push_back(0);
	}

	for (int i=0; i<MAX_REGION; i++)
		for (int j=0; j<MAX_AGE_7; j++)
			for (int k=0; k<MAX_GENDER; k++)
			{
				m_RegionArray7[i][j][k] = 0;
				m_RegionArray7_PC[i][j][k] = 1;
			}

	// ����(2) * ����(8) * ����(17) = 272
	m_vRegionInfo8.clear();
	m_vRegionInfo8_PC.clear();
	for (int i=0; i<272; i++)
	{
		m_vRegionInfo8.push_back(0);
		//m_vRegionInfo8_PC.push_back(0);
	}

	for (int i=0; i<MAX_GENDER; i++)
		for (int j=0; j<MAX_AGE_8; j++)
			for (int k=0; k<MAX_REGION; k++)
			{
				m_RegionArray8[i][j][k] = 0;
				m_RegionArray8_PC[i][j][k] = 2;
			}


	//����(17) * ����(7) * ����(2) = 238
	// PC �� ������
	//m_RegionArray7_PC[0][0][0] = 1;
	//m_RegionArray7_PC[1][0][1] = 1;
	//m_RegionArray7_PC[2][1][0] = 1;
	//m_RegionArray7_PC[3][1][1] = 1;
	//m_RegionArray7_PC[4][2][0] = 1;
	//m_RegionArray7_PC[5][2][1] = 1;
	//m_RegionArray7_PC[6][3][0] = 1;
	//m_RegionArray7_PC[7][3][1] = 1;
	//m_RegionArray7_PC[8][4][0] = 1;
	//m_RegionArray7_PC[9][4][1] = 1;
	//m_RegionArray7_PC[10][5][0] = 1;
	//m_RegionArray7_PC[11][5][1] = 1;
	//m_RegionArray7_PC[12][6][0] = 1;
	//m_RegionArray7_PC[13][6][1] = 1;
	//m_RegionArray7_PC[14][6][0] = 1;
	//m_RegionArray7_PC[15][6][1] = 1;
	//m_RegionArray7_PC[16][6][0] = 1;

	m_vRegionInfo7_PC.clear();
	for (int i=0; i<MAX_REGION; i++)	
	{
		for (int j=0; j<MAX_AGE_7; j++)
		{
			for (int k=0; k<MAX_GENDER; k++)
			{ 
				m_vRegionInfo7_PC.push_back(m_RegionArray7_PC[i][j][k]);
			}
		}
	}

	thePMSConn.SetStatInfoPC(m_idc_edit1, m_idc_edit2, m_idc_edit3 + 10, m_idc_edit4, m_idc_edit5, m_idc_edit6);
	thePMSConn.SetRegionInfoPC(m_vRegionInfo7_PC);


	//����(17) * ����(7) * ����(2) = 238
	//m_RegionArray7[0][0][0] = 5;
	//m_RegionArray7[1][0][1] = 5;
	//m_RegionArray7[2][1][0] = 5;
	//m_RegionArray7[3][1][1] = 5;
	//m_RegionArray7[4][2][0] = 5;
	//m_RegionArray7[5][2][1] = 5;
	//m_RegionArray7[6][3][0] = 5;
	//m_RegionArray7[7][3][1] = 5;
	//m_RegionArray7[8][4][0] = 5;
	//m_RegionArray7[9][4][1] = 5;
	//m_RegionArray7[10][5][0] = 5;
	//m_RegionArray7[11][5][1] = 5;
	//m_RegionArray7[12][6][0] = 5;
	//m_RegionArray7[13][6][1] = 5;
	//m_RegionArray7[14][6][0] = 5;
	//m_RegionArray7[15][6][1] = 5;
	//m_RegionArray7[16][6][0] = 5;

	m_vRegionInfo7.clear();
	for (int i=0; i<MAX_REGION; i++)	
	{
		for (int j=0; j<MAX_AGE_7; j++)
		{
			for (int k=0; k<MAX_GENDER; k++)
			{ 
				m_vRegionInfo7.push_back(m_RegionArray7[i][j][k]);
			}
		}
	}
	thePMSConn.SetRegionInfo(m_vRegionInfo7);

	UpdateData(false);
}

void CPMSConnSampleView::InitPMSConn(void)
{
	tstring strGSID = _T("8");
	//tstring strHAIP = _T("219.254.22.40");
	tstring strHAIP = _T("127.0.0.1");
	tstring strHAPORT = _T("8989");
	tstring strCNFGFILE = _T("CNFGFILE.ini");

	TCHAR *pArguValue[5];
	tstring _gsid = _T("/GSID:") + strGSID;
	pArguValue[0] = new TCHAR[_gsid.length() + 1];
	_tcscpy(pArguValue[0], _gsid.c_str());
	tstring _haip = _T("/HAIP:") + strHAIP;
	pArguValue[1] = new TCHAR[_haip.length() + 1];
	_tcscpy(pArguValue[1], _haip.c_str());
	tstring _haport = _T("/HAPORT:") + strHAPORT;
	pArguValue[2] = new TCHAR[_haport.length() + 1];
	_tcscpy(pArguValue[2], _haport.c_str());
	tstring _cnfgfile = _T("/CNFGFILE:") + strCNFGFILE;
	pArguValue[3] = new TCHAR[_cnfgfile.length() + 1];
	_tcscpy(pArguValue[3], _cnfgfile.c_str());
	tstring _lastargu = _T(" ");
	pArguValue[4] = new TCHAR[_lastargu.length() + 1];
	_tcscpy(pArguValue[4], _lastargu.c_str());

	thePMSConn.SetStatInfo(m_idc_edit1, m_idc_edit2, m_idc_edit3, m_idc_edit4, m_idc_edit5, m_idc_edit6);
	thePMSConn.SetPerfInfo(m_aPerformanceInfo);
	thePMSConn.SetRegionInfo(m_vRegionInfo7);

	for (int i=0; i<5; i++)
		::OutputDebugString(pArguValue[i]);
	
	//DWORD argc = 5; // argc  �� 0���� �����ϸ� default ��
	DWORD argc = 5;

//	thePMSConn.Init(argc, argv);
	BOOL bInit = thePMSConn.Init(argc, pArguValue);
	GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);

	// bInit = 0 �̸� �ʱ�ȭ ����
	if ((bInit == 0) && (bWorkingPMSConn == FALSE))
	{
		if (thePMSConn.Run() == 0)
			bWorkingPMSConn = TRUE;
	}

	for (int i=0; i<5; i++)
		delete pArguValue[i];
}

void CPMSConnSampleView::OnBnClickedRadioMan()
{
	m_current_gender = 0;
}

void CPMSConnSampleView::OnBnClickedRadioWoman()
{
	m_current_gender = 1;
}

void CPMSConnSampleView::OnBnClickedRadioAge0013()
{
	m_current_age = 0;
}

void CPMSConnSampleView::OnBnClickedRadioAge1416()
{
	m_current_age = 1;
}

void CPMSConnSampleView::OnBnClickedRadioAge1719()
{
	m_current_age = 2;
}

void CPMSConnSampleView::OnBnClickedRadioAge2024()
{
	m_current_age = 3;
}

void CPMSConnSampleView::OnBnClickedRadioAge2529()
{
	m_current_age = 4;
}

void CPMSConnSampleView::OnBnClickedRadioAge3039()
{
	m_current_age = 5;
}

void CPMSConnSampleView::OnBnClickedRadioAge4099()
{
	m_current_age = 6;
}

void CPMSConnSampleView::OnBnClickedButton1()
{
	InitPMSConn();
}

void CPMSConnSampleView::OnBnClickedButton2()
{
	if (bWorkingPMSConn == FALSE)
	{
		thePMSConn.Run();
		bWorkingPMSConn = TRUE;
	}
	else
	{
		MessageBox("Already running!");
	}
}

void CPMSConnSampleView::OnBnClickedButton3()
{
	thePMSConn.Stop();
	bWorkingPMSConn = FALSE;
}

void CPMSConnSampleView::OnBnClickedButton4()
{
	thePMSConn.SetHeartBeat(TRUE);
	return;
	// keidw

	UpdateData(true);
	thePMSConn.SetStatInfo(m_idc_edit1, m_idc_edit2, m_idc_edit3, m_idc_edit4, m_idc_edit5, m_idc_edit6);
}

void CPMSConnSampleView::OnBnClickedButton5()
{
	thePMSConn.SetHeartBeat(FALSE);
	return;
	// keidw

	UpdateData(true);

	m_aPerformanceInfo[0] = m_idc_edit_pfm1;
	m_aPerformanceInfo[1] = m_idc_edit_pfm2;
	m_aPerformanceInfo[2] = m_idc_edit_pfm3;
	m_aPerformanceInfo[3] = m_idc_edit_pfm4;
	m_aPerformanceInfo[4] = m_idc_edit_pfm5;
	m_aPerformanceInfo[5] = m_idc_edit_pfm6;
	m_aPerformanceInfo[6] = m_idc_edit_pfm7;
	m_aPerformanceInfo[7] = m_idc_edit_pfm8;
	m_aPerformanceInfo[8] = m_idc_edit_pfm9;
	m_aPerformanceInfo[9] = m_idc_edit_pfm10;
	thePMSConn.SetPerfInfo(m_aPerformanceInfo);
}


void CPMSConnSampleView::OnLvnItemchangedListAdded(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CPMSConnSampleView::OnNMDblclkListAdded(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CPMSConnSampleView::OnBnClickedButton6()	// Add Region Data
{
	if ( (m_current_region < 0) || (m_current_age < 0) || (m_current_gender) < 0 )
		return;

	UpdateData(true);

	//����(17) * ����(7) * ����(2) = 238
	//m_RegionArray7[0][0][0] = 1;
	//m_RegionArray7[1][0][1] = 1;
	//m_RegionArray7[2][1][0] = 1;
	//m_RegionArray7[3][1][1] = 1;
	//m_RegionArray7[4][2][0] = 1;
	//m_RegionArray7[5][2][1] = 1;
	//m_RegionArray7[6][3][0] = 1;
	//m_RegionArray7[7][3][1] = 1;
	//m_RegionArray7[8][4][0] = 1;
	//m_RegionArray7[9][4][1] = 1;
	//m_RegionArray7[10][5][0] = 1;
	//m_RegionArray7[11][5][1] = 1;
	//m_RegionArray7[12][6][0] = 1;
	//m_RegionArray7[13][6][1] = 1;
	//m_RegionArray7[14][6][0] = 1;
	//m_RegionArray7[15][6][1] = 1;
	//m_RegionArray7[16][6][0] = 1;

	m_vRegionInfo7.clear();
	m_RegionArray7[m_current_region][m_current_age][m_current_gender] = m_edit_addcount;
	for (int i=0; i<MAX_REGION; i++)	
	{
		for (int j=0; j<MAX_AGE_7; j++)
		{
			for (int k=0; k<MAX_GENDER; k++)
			{ 
				m_vRegionInfo7.push_back(m_RegionArray7[i][j][k]);
			}
		}
	}
	thePMSConn.SetRegionInfo(m_vRegionInfo7);

//	17(����) * ����(7) * ����(2) = 238 (Publishing)
//	17(����) * ����(8) * ����(2) = 272 (Web)

	//����(2) * ����(8) * ����(17) = 272
	//m_RegionArray8[0][0][0] = 1;
	//m_RegionArray8[1][0][1] = 2;
	//m_RegionArray8[0][1][2] = 3;
	//m_RegionArray8[1][1][3] = 4;
	//m_RegionArray8[0][2][4] = 5;
	//m_RegionArray8[1][2][5] = 6;
	//m_RegionArray8[0][3][6] = 7;
	//m_RegionArray8[1][3][7] = 8;
	//m_RegionArray8[0][4][8] = 9;
	//m_RegionArray8[1][4][9] = 10;
	//m_RegionArray8[0][5][10] = 11;
	//m_RegionArray8[1][5][11] = 12;
	//m_RegionArray8[0][6][12] = 13;
	//m_RegionArray8[1][6][13] = 14;
	//m_RegionArray8[0][6][14] = 15;
	//m_RegionArray8[1][6][15] = 16;
	//m_RegionArray8[0][6][16] = 17;

	//m_vRegionInfo8.clear();
	//m_RegionArray8[m_current_gender][m_current_age][m_current_region] = m_edit_addcount;
	//for (int i=0; i<MAX_GENDER; i++)
	//{
	//	for (int j=0; j<MAX_AGE_8; j++)
	//	{
	//		for (int k=0; k<MAX_REGION; k++)
	//		{ 
	//			m_vRegionInfo8.push_back(m_RegionArray8[i][j][k]);
	//		}
	//	}
	//}
	//thePMSConn.SetRegionInfo(m_vRegionInfo8);

	AddRegionInfoList();
}

void CPMSConnSampleView::AddRegionInfoList()
{
	BOOL bExist = FALSE;
	int row, cp_region, cp_age, cp_gender;
	char strBuff[16];

	for (int i=0; i<m_list_added.GetItemCount(); i++)
	{
		cp_region	= atoi(m_list_added.GetItemText(i,1).GetBuffer()); // ����
		cp_age		= atoi(m_list_added.GetItemText(i,2).GetBuffer()); // ����
		cp_gender	= atoi(m_list_added.GetItemText(i,3).GetBuffer()); // ����
		
		if ( (m_current_region == cp_region) && (m_current_age == cp_age) && (m_current_gender == cp_gender) )
		{
			row = i;
			bExist = TRUE;
			break;
		}
	}

	if (bExist)
	{
		// Modify exist region data
		itoa(m_edit_addcount, strBuff, 10);

		if (m_edit_addcount > 0) 
			m_list_added.SetTextColor(RGB(0,0,128));
		else
			m_list_added.SetTextColor(RGB(0,0,0));

		m_list_added.SetItemText(row, 4, strBuff);
	}
	else
	{
		// Add new region data
		row = m_list_added.GetItemCount();
		itoa(row, strBuff, 10);

		if (m_edit_addcount > 0) 
			m_list_added.SetTextColor(RGB(0,0,128));
		else
			m_list_added.SetTextColor(RGB(0,0,0));

		m_list_added.InsertItem(row , strBuff, 0);
		itoa(m_current_region, strBuff, 10);
		m_list_added.SetItemText(row, 1, strBuff);
		itoa(m_current_age, strBuff, 10);
		m_list_added.SetItemText(row, 2, strBuff);
		itoa(m_current_gender, strBuff, 10);
		m_list_added.SetItemText(row, 3, strBuff);
		itoa(m_edit_addcount, strBuff, 10);

		m_list_added.SetItemText(row, 4, strBuff);
	}

	// Process CListCtrl Sort Function
	// m_list_added.SortItems();
}

void CPMSConnSampleView::OnNMClickListRegion(NMHDR *pNMHDR, LRESULT *pResult)
{
	m_list_region.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);
	m_current_region = m_list_region.GetNextItem(-1, LVNI_FOCUSED);
	
	*pResult = 0;
}


void CPMSConnSampleView::OnBnClickedRadioModeNormal()
{
	m_current_mode = 0;
}

void CPMSConnSampleView::OnBnClickedRadioModePcroom()
{
	m_current_mode = 1;
}

void CPMSConnSampleView::OnClose()
{
	::OutputDebugString("OnClose");	
	PostQuitMessage(0);
}


void CPMSConnSampleView::OnBnClickedButton7()
{
	// warning 
	thePMSConn.SendWarningMsg(0, "WarningMsg", "TreatMsg", 208, 0);
}

