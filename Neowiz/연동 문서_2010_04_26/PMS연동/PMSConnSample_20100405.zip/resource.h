//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PMSConnSample.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_PMSCONNSAMPLE_FORM          101
#define IDR_MAINFRAME                   128
#define IDR_PMSConnSampleTYPE           129
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1004
#define IDC_EDIT3                       1005
#define IDC_EDIT4                       1006
#define IDC_EDIT5                       1007
#define IDC_EDIT6                       1008
#define IDC_BUTTON4                     1009
#define IDC_EDIT_PFM1                   1010
#define IDC_EDIT_PFM2                   1011
#define IDC_EDIT_PFM3                   1012
#define IDC_EDIT_PFM4                   1013
#define IDC_EDIT_PFM5                   1014
#define IDC_EDIT_PFM6                   1015
#define IDC_EDIT_PFM7                   1016
#define IDC_EDIT_PFM8                   1017
#define IDC_EDIT_PFM9                   1018
#define IDC_EDIT_PFM10                  1019
#define IDC_BUTTON5                     1020
#define IDC_BUTTON6                     1021
#define IDC_EDIT_MSG                    1022
#define IDC_RADIO_MAN                   1024
#define IDC_RADIO_WOMAN                 1025
#define IDC_RADIO_AGE0013               1026
#define IDC_RADIO_AGE1416               1027
#define IDC_RADIO_AGE1719               1028
#define IDC_RADIO_AGE2024               1029
#define IDC_RADIO_AGE2529               1030
#define IDC_RADIO_AGE3039               1031
#define IDC_RADIO_AGE4099               1032
#define IDC_EDIT_ADDCOUNT               1033
#define IDC_LIST_REGION                 1035
#define IDC_LIST_ADDED                  1036
#define IDC_RADIO_MODE_NORMAL           1038
#define IDC_RADIO_MODE_PCROOM           1039
#define IDC_BUTTON7                     1040
#define IDC_LIST1                       1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
