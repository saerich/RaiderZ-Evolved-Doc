#ifndef __CPMSCONNWRAPPER_H_
#define __CPMSCONNWRAPPER_H_
#pragma once
#include "PMSConn.h"

#ifdef _UNICODE
#ifdef _DEBUG
	#pragma comment(lib, "../../lib/PMSConnUD.lib")
#else
	#pragma comment(lib, "../../lib/PMSConnU.lib")
#endif
#else
#ifdef _DEBUG
	#pragma comment(lib, "../../lib/PMSConnD.lib")
#else
	#pragma comment(lib, "../../lib/PMSConn.lib")
#endif
#endif

//struct CPMSObject : public IPMSObject
//{
//// Heart Beat �κ��� �ݵ�� ���� ���� �ؾ� �Ѵ�.
////	virtual BOOL OnHeartbeatReq(LONG lIndex) = 0;
//	virtual BOOL OnOrderReq(LPCSTR lpszCmdName, LPCSTR lpszCtlVal, LPSTR lpResult, LONG *lpResultLen, DWORD dwSSN, DWORD dwCategoryID){ return TRUE;}
//	virtual BOOL OnAnnounceReq(DWORD dwSSN, DWORD dwCategoryID, LPCSTR lpszMsg){ return TRUE;}
//	virtual BOOL OnPerformInfoReq(IPMSPerformanceInfo *pPerformanceInfo) { return TRUE;}
//	virtual BOOL OnRegionInfoReq(IPMSReionInfoList* plstRegionInfo){ return TRUE;}
//	virtual BOOL OnStatInfoReq(IPMSStatInfoList* plstStatInfo){ return TRUE;}
//};

template<typename T>
class CPMSConnWrapper //: public BASE
{
//	CPMSConnWrapper()
public:
	virtual ~CPMSConnWrapper(){ Stop();}
public:
	// PMSConn API�� ȣ�� �ϱ� ���� �Լ�
	DWORD	Init(DWORD argc, LPTSTR argv[]) { return ::PMSInitConn(argc, argv); }
	DWORD	Run() { return ::PMSRunConn(&m_callBackObj); }
	void	Stop() { ::PMSStopConn(); }
	BOOL	SendWarningMsg(DWORD dwErrLvl, LPCSTR pszWarningMsg, LPCSTR pszTreatMsg, DWORD dwSSN, DWORD dwCategory)
	{
		return ::PMSSendWarningMsg(dwErrLvl, pszWarningMsg, pszTreatMsg, dwSSN, dwCategory);
	}
	LPCTSTR	GetConfigFileName();
	DWORD	GetStatus();

	typedef std::vector<LONG> vecRegion;
	void SetStatInfo(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt)
	{
		m_callBackObj.SetStatInfo(dwSSN, dwCategory, dwCU, dwSession, dwChannelCnt, dwRoomCnt);
	}

	void SetPerfInfo(LONG aPerformanceInfo[]) 
	{
		m_callBackObj.SetPerfInfo(aPerformanceInfo);
	}

	void SetRegionInfo(vecRegion &vec)
	{
		m_callBackObj.SetRegionInfo(vec);
	}

	void SetStatInfoPC(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt)
	{
		m_callBackObj.SetStatInfoPC(dwSSN, dwCategory, dwCU, dwSession, dwChannelCnt, dwRoomCnt);
	}

	void SetRegionInfoPC(vecRegion &vec)
	{
		m_callBackObj.SetRegionInfoPC(vec);
	}

	void SetHeartBeat(BOOL type)
	{
		m_callBackObj.SetHeartBeat(type);
	}

public:
	T	m_callBackObj;
};

#endif // if not def __CPMSCONNWRAPPER_H_

