// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PMSCONN_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PMSCONN_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef PMSCONN_EXPORTS
#define PMSCONN_API __declspec(dllexport)
#else
#define PMSCONN_API __declspec(dllimport)
#endif

#include "IPMSObject.h"
// This class is exported from the PMSConn.dll
//class PMSCONN_API CPMSConn {
//public:
//	CPMSConn(void);
//	// TODO: add your methods here.
//};
//
//extern PMSCONN_API int nPMSConn;

//PMSCONN_API int fnPMSConn(void);
extern PMSCONN_API	DWORD	PMSInitConn(DWORD argc, LPTSTR argv[]);
extern PMSCONN_API  DWORD	PMSRunConn(IPMSObject *pObj);
extern PMSCONN_API  void	PMSStopConn();
extern PMSCONN_API	BOOL	PMSSendWarningMsg(DWORD dwErrLvl, LPCSTR pszWarningMsg, LPCSTR pszTreatMsg, DWORD dwSSN, DWORD dwCategory);
extern PMSCONN_API	LPCTSTR	PMSGetConfigFileName();
extern PMSCONN_API	DWORD	PMSGetStatus();