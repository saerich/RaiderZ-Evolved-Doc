#include "StdAfx.h"
#include "CallBackObj.h"

CCallBackObj::CCallBackObj(void)
{
	bHeartBeat = TRUE;
}

CCallBackObj::~CCallBackObj(void)
{
}

BOOL CCallBackObj::OnHeartbeatReq(LONG lIndex)
{
	_tprintf(_T("OnHeartbeatReq Seq:%d\n"), lIndex); 
	return bHeartBeat;
}

BOOL CCallBackObj::OnRegionInfoReq(IPMSRegionInfoList* plstRegionInfo)
{
	_tprintf(_T("OnRegionInfoReq\n"));
	VLONG vLong;

	//for(LONG i = 0; i < 238 ; i++) // 272
	//{
	//	vLong.push_back(0);
	//}
	//plstRegionInfo->AddRegionInfo(m_dwSSN, m_dwCategory, &vLong);

	plstRegionInfo->AddRegionInfo(m_dwSSN, m_dwCategory, &m_vRegionInfo);

	return TRUE;
}

BOOL CCallBackObj::OnRegionInfoPCReq(IPMSRegionInfoListPC* plstRegionInfoPC)
{
	_tprintf(_T("OnRegionInfoPCReq\n"));
	VLONG vLong;

	//if (m_vRegionInfoPC.size() == 0) return FALSE;

	plstRegionInfoPC->AddRegionInfoPC(m_dwSSN, m_dwCategory, &m_vRegionInfoPC);

	return TRUE;
}

BOOL CCallBackObj::OnStatInfoReq(IPMSStatInfoList* plstStatInfo)
{ 
	_tprintf(_T("OnStatInfoReq\n"));

	plstStatInfo->AddStatInfoList(m_dwSSN, m_dwCategory, m_dwCU, m_dwSession, m_dwChannelCnt, m_dwRoomCnt, NULL);

	// for ä�θ� TEST
	//plstStatInfo->AddStatInfoList(m_dwSSN, 1001, m_dwCU, m_dwSession, m_dwChannelCnt, m_dwRoomCnt, NULL);
	//plstStatInfo->AddStatInfoList(m_dwSSN, 1002, m_dwCU, m_dwSession, m_dwChannelCnt, m_dwRoomCnt, NULL);

	return TRUE;
}

BOOL CCallBackObj::OnStatInfoPCReq(IPMSStatInfoListPC* plstStatInfoPC)
{ 
	_tprintf(_T("OnStatInfoPCReq\n"));

	//if (m_dwCU_PC == 0) return FALSE;

	plstStatInfoPC->AddStatInfoListPC(m_dwSSN, m_dwCategory, m_dwCU_PC, m_dwSession, m_dwChannelCnt, m_dwRoomCnt, NULL);
	return TRUE;
}

BOOL CCallBackObj::OnPerformInfoReq(IPMSPerformanceInfo *pPerformanceInfo)
{ 
	_tprintf(_T("OnPerformInfoReq\n"));
	VLONG vlong;
	for (LONG i = 0; i<10; i++)
	{
		vlong.push_back(m_aPerformanceInfo[i]);
	}
	pPerformanceInfo->AddPerformanceInfo(&vlong);
	return TRUE;
}

BOOL CCallBackObj::OnAnnounceReq(DWORD dwSSN, DWORD dwCategoryID, LPCSTR lpszMsg)
{
	if (lpszMsg)
		printf("OnAnnounceReq SSN:%u CategoryID:%u lpszMsg:%s\n", dwSSN, dwCategoryID, lpszMsg);

	AfxMessageBox(lpszMsg);

	return TRUE;
}

BOOL CCallBackObj::OnOrderReq(LPCSTR lpszCmdName, LPCSTR lpszCtlVal, LPSTR lpResult, LONG *lpResultLen, DWORD dwSSN, DWORD dwCategoryID)
{
	if (lpszCmdName&&lpszCtlVal)
		_tprintf(_T("OnAnnounceReq SSN:%u CategoryID:%u lpszlpszCmdName:%s lpszCtlVal:%s\n"), dwSSN, dwCategoryID, lpszCmdName, lpszCtlVal);
	return TRUE;
}

void CCallBackObj::SetStatInfo(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt)
{
	m_dwSSN = dwSSN;
	m_dwCategory = dwCategory;
	m_dwCU = dwCU;
	m_dwSession = dwSession;
	m_dwChannelCnt = dwChannelCnt;
	m_dwRoomCnt = dwRoomCnt;
}

void CCallBackObj::SetPerfInfo(LONG aPerformanceInfop[])
{
	for (int i=0; i<10; i++)
		m_aPerformanceInfo[i] = aPerformanceInfop[i];
}

void CCallBackObj::SetRegionInfo(vecRegion &vec)
{
	m_vRegionInfo.assign(vec.begin(), vec.end());
}

void CCallBackObj::SetStatInfoPC(DWORD dwSSN, DWORD dwCategory, DWORD dwCU, DWORD dwSession, DWORD dwChannelCnt, DWORD dwRoomCnt)
{
	m_dwSSN = dwSSN;
	m_dwCategory = dwCategory;
	m_dwCU_PC = dwCU;
	m_dwSession = dwSession;
	m_dwChannelCnt = dwChannelCnt;
	m_dwRoomCnt = dwRoomCnt;
}

void CCallBackObj::SetRegionInfoPC(vecRegion &vec)
{
	m_vRegionInfoPC.assign(vec.begin(), vec.end());
}

void CCallBackObj::SetHeartBeat(BOOL type)
{
	bHeartBeat = type;
}
