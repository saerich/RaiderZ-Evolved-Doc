// PMSConnSampleView.h : iCPMSConnSampleView Ŭ������ �������̽�
//
#pragma once
#include "afxcmn.h"

class CPMSConnSampleView : public CFormView
{
protected: // serialization������ ��������ϴ�.
	CPMSConnSampleView();
	DECLARE_DYNCREATE(CPMSConnSampleView)

public:
	enum{ IDD = IDD_PMSCONNSAMPLE_FORM };

// Ư��
public:
	CPMSConnSampleDoc* GetDocument() const;

// �۾�
public:
	typedef std::vector<LONG> vecRegion;

// ������
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����
	virtual void OnInitialUpdate(); // ���� �� ó�� ȣ��Ǿ����ϴ�.

// ����
public:
	virtual ~CPMSConnSampleView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

private:
	int m_RegionArray7[MAX_REGION][MAX_AGE_7][MAX_GENDER];
	int m_RegionArray8[MAX_GENDER][MAX_AGE_8][MAX_REGION];
	int m_current_region;
	int m_current_age;
	int m_current_gender;
	int m_current_mode;
	BOOL bWorkingPMSConn;
	LONG m_aPerformanceInfo[10];
	vecRegion m_vRegionInfo7;
	vecRegion m_vRegionInfo8;

	// for PC �� ������
	int m_RegionArray7_PC[MAX_REGION][MAX_AGE_7][MAX_GENDER];
	int m_RegionArray8_PC[MAX_GENDER][MAX_AGE_8][MAX_REGION];
	vecRegion m_vRegionInfo7_PC;
	vecRegion m_vRegionInfo8_PC;
	
protected:

// �޽��� �� �Լ��� �����߽��ϴ�.
protected:
	DECLARE_MESSAGE_MAP()
public:
	void InitPMSConn(void);
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	DWORD m_idc_edit1;
	DWORD m_idc_edit2;
	DWORD m_idc_edit3;
	DWORD m_idc_edit4;
	DWORD m_idc_edit5;
	DWORD m_idc_edit6;
	afx_msg void OnBnClickedButton5();
	DWORD m_idc_edit_pfm1;
	DWORD m_idc_edit_pfm2;
	DWORD m_idc_edit_pfm3;
	DWORD m_idc_edit_pfm4;
	DWORD m_idc_edit_pfm5;
	DWORD m_idc_edit_pfm6;
	DWORD m_idc_edit_pfm7;
	DWORD m_idc_edit_pfm8;
	DWORD m_idc_edit_pfm9;
	DWORD m_idc_edit_pfm10;
	void InitDefaultValue(void);
	CListCtrl m_list_region;
	CListCtrl m_list_added;
	afx_msg void OnLvnItemchangedListAdded(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMDblclkListAdded(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButton6();
	afx_msg void OnNMClickListRegion(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedRadioMan();
	afx_msg void OnBnClickedRadioWoman();
	afx_msg void OnBnClickedRadioAge0013();
	afx_msg void OnBnClickedRadioAge1416();
	afx_msg void OnBnClickedRadioAge1719();
	afx_msg void OnBnClickedRadioAge2024();
	afx_msg void OnBnClickedRadioAge2529();
	afx_msg void OnBnClickedRadioAge3039();
	afx_msg void OnBnClickedRadioAge4099();
	int m_edit_addcount;
	void AddRegionInfoList();
	afx_msg void OnBnClickedRadioModeNormal();
	afx_msg void OnBnClickedRadioModePcroom();
	afx_msg void OnClose();
	afx_msg void OnBnClickedButton7();
};

#ifndef _DEBUG  // PMSConnSampleView.cpp�� ����� ����
inline CPMSConnSampleDoc* CPMSConnSampleView::GetDocument() const
   { return reinterpret_cast<CPMSConnSampleDoc*>(m_pDocument); }
#endif

