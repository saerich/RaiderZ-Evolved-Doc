#ifndef __CCONTROL_H
#define __CCONTROL_H
//#include "AgentSocket.h"


class CControl : public IXObject
{
	IMPLEMENT_TISAFEREFCNT(CControl)
protected:
    STDMETHOD_(void, OnSignal)(HSIGNAL hSignal, WPARAM wParam, LPARAM lParam);

public:
	CControl(void);
	virtual ~CControl(void);

	BOOL InitControl();
	BOOL RunControl();
	BOOL Stop();

public:

private:	

};

 void StartTimer();

extern CControl theControl;
#endif