#pragma once

#include "common.h"
#include "gslinkmanager.h"

class PMSPerformInfo;
class CPerfMgr : public IXObject
{
	//CPerfMgr():m_dwCpuCnt(0) {}
	//~CPerfMgr(){}
	IMPLEMENT_TISAFEREFCNT(CPerfMgr)
	typedef IXObject TBase;
	typedef ArcMapT<DWORD, PMSPerformInfo * > PerformInfoMapT;
public:
	STDMETHOD_(void, OnSignal)(HSIGNAL hSig, WPARAM wParam, LPARAM lParam);

public:
	BOOL Start();
	BOOL Stop();

	BOOL AddClient(DWORD dwGSID, CLink *pLink);
	void RemoveClient(DWORD dwGSID);
public:
	CPerfMgr(void);
	~CPerfMgr(void);

private:
	void SendPerformReqMsg();
	void GatherPerformDataReq();

	BOOL WMI_CPUMEM(LONG& lcpu, LONG& lmem, const string strGameName);
	void CheckCount();
	const DWORD GetCpuCount() ;
private:
	GXSigTimer m_PerformTimer;
	PerformInfoMapT m_mapPerform;
	DWORD m_dwCpuCnt;
};

extern CPerfMgr thePfManager;
