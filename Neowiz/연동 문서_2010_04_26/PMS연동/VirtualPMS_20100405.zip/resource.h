//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PMSConnServer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_PMSCONNSERVER_FORM          101
#define IDR_MAINFRAME                   128
#define IDR_PMSConnServerTYPE           129
#define IDD_DIALOG_STATISTICS           132
#define IDI_ICON_NOTE                   134
#define IDI_ICON_SYSTEM                 135
#define IDI_ICON_CIRCLE_GREEN           136
#define IDI_ICON_CIRCLE_RED             137
#define IDI_ICON_MESSAGE                138
#define IDI_ICON_MEMO                   139
#define IDR_241                         140
#define IDC_RICHEDIT_MSG                1001
#define IDC_LIST_MESSAGE                1003
#define IDC_CHECK1                      1004
#define IDC_CHECK2                      1005
#define IDC_CHECK3                      1006
#define IDC_LIST_GS                     1007
#define IDC_BUTTON_GSSTART              1008
#define IDC_BUTTON_GSSTOP               1009
#define IDC_BUTTON_GSRESTART            1010
#define IDC_EDIT_NOTICE                 1011
#define IDC_BUTTON_SENDNOTICE           1012
#define IDC_STATIC_GSINFOTYPe           1013
#define IDC_STATIC_GSINFOTYPE           1013
#define IDC_EDIT_LENGTH                 1015
#define IDC_LIST_PARSESTAT              1016
#define IDC_CHECK4                      1017
#define IDC_BUTTON_SHOWSTAT             1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
