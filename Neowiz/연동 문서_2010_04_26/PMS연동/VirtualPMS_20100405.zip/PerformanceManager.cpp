#include "stdafx.h"
#include <pdh.h>
#include <pdhmsg.h>
#include "common.h"
#include ".\performancemanager.h"

#include "ClientMgr.h"
#include "../include/ADL/PMSStatusManagement.h"
#include "gslinkmanager.h"
#include "GSLinkManagerADL.h"
#include "GSControler.h"
#include "localPdh.h"


CPerfMgr thePfManager;

CPerfMgr::CPerfMgr(void):m_dwCpuCnt(0) 
{
}

CPerfMgr::~CPerfMgr(void)
{
	if(m_PerformTimer.IsActive())
	{
		m_PerformTimer.Deactivate();
		theErr.LOG2(1,_T("[PFMANAGER] Destory Timer Deact\n"));
	}
}

BOOL CPerfMgr::Start()
{
	BOOL bRet=TRUE;
	bRet = bRet && m_PerformTimer.Activate(GetThreadPool(), this, MG_DUETIME, MG_DUETIME+1000);
	return bRet;
}

BOOL CPerfMgr::AddClient(DWORD dwGSID, CLink *pLink)
{
	TLock lo(this);

	tstring _stitle;

	if(!theGSSessionTable.GetTitle(_stitle, dwGSID))
		return FALSE;

	PerformInfoMapT::iterator itr = m_mapPerform.find(dwGSID);

	if(itr != m_mapPerform.end())
	{
		PMSPerformInfo * _p = itr->second;
		delete _p;
		theErr.LOG(1, _T("---- NOTE : alerad exist GSI .. ----"));
	}
	PMSPerformInfo *pItem = new PMSPerformInfo;

	// truewise
	pItem->m_dwGSID = dwGSID;
	pItem->m_sPerfName = tstr2str(_stitle);

	m_mapPerform[dwGSID] = pItem;
	
	return TRUE;
}

void CPerfMgr::RemoveClient(DWORD dwGSID)
{
	TLock lo(this);
	PerformInfoMapT::iterator it = m_mapPerform.find(dwGSID);
	if(it != m_mapPerform.end())
	{
		theErr.LOG(1,_T("[PFMANAGER RemoveClient] GSID : %d \n"),dwGSID );
		PMSPerformInfo *p = it->second;
		m_mapPerform.erase(it);
		delete (p);
	}
}

STDMETHODIMP_(void) CPerfMgr::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	TLock lo(this);

	if(hSig == (HSIGNAL)HASIGNAL_PERFORMREQ)
	{
		GatherPerformDataReq();
	}
	else if(hSig == (HSIGNAL)HASIGNAL_UPDATE)	// structure�� ���� ��� ó���������.. 
	{
		GBuf buf((LPXBUF)lParam, FALSE);
		PMSPerformInfo info;
		::BLoad(info, buf);

		PerformInfoMapT::iterator it = m_mapPerform.find(info.m_dwGSID);		

		if(it == m_mapPerform.end())
			return;

		PMSPerformInfo * pItem = it->second;

		// GS�κ��� ���޹��� ����.. �� HA�� ���� ������ ����Ÿ�� ����
		LONG lMem = 0L;
		LONG lCPU = 0L;
		WMI_CPUMEM(lCPU, lMem, pItem->m_sPerfName);
		info.m_sPerfName = pItem->m_sPerfName;   // truewise - 2005.11.10  SF ��� ���� ���� �ذ�
		info.m_dwCPU = (DWORD)lCPU;
		info.m_dwMEM = (DWORD)lMem;

//theErr.LOG(1,_T("[ADL] info.m_dwCPU : %d\n"),info.m_dwCPU);
//theErr.LOG(1,_T("[ADL] info.m_dwMEM : %d\n"),info.m_dwMEM);


		// truewise : ��Ʈ��Ʈ ���� �ذ�
		//if(pItem->m_lTimeOutCount <= 4)
		{
			info.m_lTimeOutCount = 0;
		}
		
		// update..
		*pItem = info;
	}
	else if(hSig == (HSIGNAL)HASIGNAL_DONOTCARE)	 
	{
		GBuf buf((LPXBUF)lParam, FALSE);
		PMSPerformInfo info;
		::BLoad(info, buf);


		PerformInfoMapT::iterator it = m_mapPerform.find(info.m_dwGSID);

		if(it == m_mapPerform.end())
			return;

		PMSPerformInfo * pItem = it->second;

		LONG lMem = 0L;
		LONG lCPU = 0L;
		WMI_CPUMEM(lCPU, lMem, pItem->m_sPerfName);
		info.m_sPerfName = pItem->m_sPerfName;
		info.m_dwCPU = (DWORD)lCPU;
		info.m_dwMEM = (DWORD)(lMem);

		info.m_lTimeOutCount = 0;
		*pItem = info;
	}

	else if(m_PerformTimer.IsHandle(hSig))
	{
		SendPerformReqMsg();
	}
}

void CPerfMgr::SendPerformReqMsg()
{
	if(theGSmanager.IsExistLink())
	{
		char sztemp[10]={0,};
		sprintf(sztemp,"PERE\r\n");
		GBuf buf((LPVOID)sztemp,strlen(sztemp) + 1);
		LPXBUF lpXBuf = buf.Detach();

		::XsigQueueSignal(GetThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf);
		CheckCount();
	}

	if(theGSLinkManagerADL.IsExistLink()) 
	{
		PayloadGS pld(PayloadGS::msgPMSPerformReq_Tag);	// �޼��� �������
		GBuf buf;
		::LStore(buf, pld);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf);
		CheckCount();
	}
}

void CPerfMgr::GatherPerformDataReq()
{
	tstring sTime;
	::GetTimeFormat(sTime, 3);

	// perform manager���� �ֱ������� update�� perform data�� MA�� ����..
	PMSMessage_MA pld(PMSMessage_MA::performanceAns_Tag);
	pld.un.m_performanceAns->m_lErr = S_OK;
	pld.un.m_performanceAns->m_sTime = tstr2str(sTime);

	ForEachElmt(PerformInfoMapT, m_mapPerform, it, jt)
	{
		PMSPerformInfo *pInfo = it->second;

		PMSGSIPerformance baseInfo;
		baseInfo.m_dwCPU = pInfo->m_dwCPU;
		baseInfo.m_dwGSID = pInfo->m_dwGSID;
		baseInfo.m_dwMEM = pInfo->m_dwMEM;

		baseInfo.m_vPerf.assign(pInfo->m_vecPerform.begin(), pInfo->m_vecPerform.end());

		pld.un.m_performanceAns->m_vGSIPerf.push_back(baseInfo);
	}

	GBuf buf;
	::LStore(buf, pld);
	LPXBUF lpXBuf = buf.Detach();
	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_REQSENDTOMA, 0, (LPARAM)lpXBuf);
}

void CPerfMgr::CheckCount()
{
	tstring strTime;
	PMSFaultInfo pmsFaultInfo;

	ForEachElmt(PerformInfoMapT, m_mapPerform, it, jt)
	{
		// ���� GSI�� ���°� Run �� ���°� �ƴϸ� HeartBeat�� ������ �ʴ´�.
		if (!theGSControler.GetGSIStatus(it->first))
			continue;

		PMSPerformInfo *p = it->second;
		p->m_lTimeOutCount++;

		LONG lLevel = 0L;
		if( (p->m_lTimeOutCount >5 ) && (p->m_lTimeOutCount <= 7 ) )
			lLevel = FL_ALERT;
		else if(p->m_lTimeOutCount >= 8)
			lLevel = FL_CRITICAL;
		else 
			continue;


		GetTimeFormat(strTime,3);

		pmsFaultInfo.m_lGSState = GS_START;
		pmsFaultInfo.m_lLevel = lLevel;
		pmsFaultInfo.m_lReason = FT_GSIDELAYHB; 
		pmsFaultInfo.m_dwGSID = it->first;
		pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
		pmsFaultInfo.m_sReason = "PERFORMANCE ANS DELAY";
		pmsFaultInfo.m_sDesc = "PERFORMANCE ANS DELAY";
		pmsFaultInfo.m_sProc = "STOP";
		pmsFaultInfo.m_sTime = tstr2str(strTime);
		pmsFaultInfo.m_sSSN = "";

		GBuf buf;
		::BStore(buf, pmsFaultInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, 0,(LPARAM)lpXBuf);
		
		theErr.LOG(1,_T("[PFMANAGER] ##### GSID:%d FAULT Count %d##### \n"),it->first,p->m_lTimeOutCount);
		pmsFaultInfo.Clear();
	}
}


BOOL CPerfMgr::WMI_CPUMEM(LONG & lcpu, LONG & lmem, const string strGameName)
{
	TLock lo(this);

	PDH_STATUS status;
	status = g_pdh.OpenQuery();
	BOOL bRet = TRUE;
	if (ERROR_SUCCESS != status )
	{
		theErr.LOG(1, _T("Open Query Failed 0x%x"), status);
		return FALSE;
	}

	status = g_pdh.AddCounter(_T(""), TEXT("Process"), TEXT("Working Set"), str2tstr(strGameName));
	if (ERROR_SUCCESS != status && DWORD(-1) != status)
	{
		theErr.LOG(2, _T("Add Counter Failed Memory ErrorCode : 0x%x, Game Name : %s\n"), status, strGameName.c_str());
		return FALSE;
	}

	status = g_pdh.AddCounter(_T(""), TEXT("Process"), TEXT("% Processor Time"), str2tstr(strGameName));
	if (ERROR_SUCCESS != status && DWORD(-1) != status)
	{
		theErr.LOG(2, _T("Add Counter Failed Cpu ErrorCode : 0x%x, Game Name : %s\n"), status, strGameName.c_str());
		return FALSE;
	}
	status = g_pdh.CollectQueryData();
	if (ERROR_SUCCESS != status)
	{
		theErr.LOG(2, _T("Collect Query Datar Failed ErrorCode : 0x%x, Game Name : %s\n"), status, strGameName.c_str());
		return FALSE;
	}
	PDH_FMT_COUNTERVALUE * pMem ;
	pMem = g_pdh.AllocMemory();
	if (pMem == NULL )
	{
		theErr.LOG(0, _T("Alloc Memory Error"));
		return FALSE;
	}
	
	status = g_pdh.GetFormattedCounterValue(_T(""), TEXT("Process"), TEXT("Working Set"), str2tstr(strGameName), pMem, PDH_FMT_LONG | PDH_FMT_NOSCALE);
	if (ERROR_SUCCESS != status)
	{
		theErr.LOG(2, _T("GetFormattedCounterValue Failed Memory ErrorCode : 0x%x, Game Name : %s\n"), status, strGameName.c_str());
		
		bRet = FALSE;
	}
	lmem = pMem->longValue;
	status = g_pdh.GetFormattedCounterValue(_T(""), TEXT("Process"), TEXT("% Processor Time"), str2tstr(strGameName), pMem, PDH_FMT_LONG | PDH_FMT_NOCAP100);
	if (ERROR_SUCCESS != status)
	{
		theErr.LOG(2, _T("GetFormattedCounterValue Failed CPU ErrorCode : 0x%x, Game Name : %s\n"), status, strGameName.c_str());
		bRet = FALSE;
	}
	lcpu = pMem->longValue / (long)( GetCpuCount() );
	g_pdh.FreeMemory(pMem);
	return bRet;
} 

const DWORD CPerfMgr::GetCpuCount()
{
	if (m_dwCpuCnt != 0)
	{
		return m_dwCpuCnt;
	}

	else //if (m_dwCpuCnt == 0)
	{
		SYSTEM_INFO sysInfo;
		GetSystemInfo(&sysInfo);
		m_dwCpuCnt = sysInfo.dwNumberOfProcessors;
		return m_dwCpuCnt ? m_dwCpuCnt : 1;
	}


}
