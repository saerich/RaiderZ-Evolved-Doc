#include "StdAfx.h"
#include "control.h"
#include "ClientMgr.h"
#include "GSLinkManager.h"
#include "GSListener.h"
#include "PerformanceManager.h"
#include "StatisticManager.h"

#include "GSLinkManagerADL.h"
#include "GSListenerADL.h"
#include "GSControler.h"

void StartTimer()
{
	theErr.LOG(0, _T("[StartTimer] ==== Start ====\n"));

	theHBManager.Start();
	Sleep(100);
	thePfManager.Start();
	Sleep(100);
	theStManager.Start();	
	return ;
}


CControl theControl;

CControl::CControl(void)
{
}

CControl::~CControl(void)
{
}

BOOL CControl::InitControl()
{
	::XlinkInit(::GetThreadPool());

	if(!theGSInfoTable.InitSeverBaseInfo())
		return FALSE;
	if(!theGSSessionTable.InitGSSessionTable())
		return FALSE;

	//theManagerCli.InitCliManager();

return TRUE;
}


STDMETHODIMP_(void)  CControl::OnSignal (HSIGNAL hSignal,WPARAM wParam,LPARAM lParam)
{
	TLock lo(this);
	theErr.LOG(0, _T("[Control] Timer\n"));
}


BOOL CControl::RunControl()
{
	if(!theGSListener.RunGSListener(_tstol(theGSInfoTable.GetHAPort().c_str())))
	{
		theErr.LOG(0, _T("theGSListener Run Err\n"));
		return FALSE;
	}

	if(!theGSListenerADL.RunGSListenerADL(_tstol(theGSInfoTable.GetHAPort().c_str()) + 1L))
	{
		theErr.LOG(0, _T("theGSListenerADL Run Err\n"));
		return FALSE;
	}

	StartTimer();

	return TRUE;
}

BOOL CControl::Stop()
{	
	return TRUE;
}

