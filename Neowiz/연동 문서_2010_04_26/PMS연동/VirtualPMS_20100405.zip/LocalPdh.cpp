#include "stdafx.h"
#include "LocalPdh.h"

CLocalPdh g_pdh;

CLocalPdh::CLocalPdh(void):m_bIsOpen(FALSE), m_hQuery(NULL)
{
}

CLocalPdh::~CLocalPdh(void)
{
}
PDH_STATUS	CLocalPdh::GetDllVersion(DWORD& dwVer)
{
	return ::PdhGetDllVersion(&dwVer);
}
PDH_STATUS	CLocalPdh::SetDefaultRealTimeDataSource(const DWORD& dwSourceID )
{
	return	::PdhSetDefaultRealTimeDataSource(dwSourceID);
}

PDH_STATUS	CLocalPdh::OpenQuery()
{
	// is Open is not assurence
	if (m_bIsOpen)
	{
		return ERROR_SUCCESS;
	}
	PDH_STATUS status;
	status = ::PdhOpenQuery (NULL,	0, &m_hQuery);
	if (status == ERROR_SUCCESS)
	{
		m_bIsOpen = TRUE;
	}
	return status;
}

PDH_STATUS	CLocalPdh::CloseQuery()
{
	if (m_hQuery == NULL)
	{
		return ERROR_SUCCESS;
	}
	CounterMap::iterator itr, enditr;
	enditr	=	m_mapCounter.begin();

	for (itr = m_mapCounter.begin(); itr != enditr; itr++)
	{
		RemoveCounter(itr->second.m_sName.c_str());
	}

	PDH_STATUS status =  ::PdhCloseQuery(m_hQuery);


	if (status == ERROR_SUCCESS)
	{
		m_hQuery = NULL;
		m_bIsOpen = FALSE;
	}
	return status;
}

PDH_STATUS	CLocalPdh::AddCounter(const tstring& sName, const tstring& sType)
{
	CounterInfo _info;
	_info.m_sName = sName;
	
	if ( m_mapCounter.find(sName) == m_mapCounter.end())
	{
		PDH_STATUS status;
		status = ::PdhAddCounter(m_hQuery, sType.c_str(), NULL, &(_info.m_hCounter));
		if (status != ERROR_SUCCESS)
		{
			return status;
		}
		m_mapCounter[sName] = _info;
		return ERROR_SUCCESS;
	}
	else
	{
		//�����϶� ������ ����� ����.. T.T
		return -1;
	}
}

PDH_STATUS	CLocalPdh::RemoveCounter(const tstring& sName)
{
	PDH_STATUS status = ERROR_SUCCESS;
	CounterMap::iterator itr = m_mapCounter.find(sName);
	if (itr != m_mapCounter.end())
	{
		status = ::PdhRemoveCounter(itr->second.m_hCounter);
	}
	else
	{
		status = -1;
	}
	return status;
}

PDH_STATUS	CLocalPdh::CollectQueryData()
{
	return ::PdhCollectQueryData(m_hQuery);
}

PDH_FMT_COUNTERVALUE*	CLocalPdh::AllocMemory()
{
	return static_cast<PDH_FMT_COUNTERVALUE*> (::GlobalAlloc(GPTR, sizeof(PDH_FMT_COUNTERVALUE)));
}
void	CLocalPdh::FreeMemory(PDH_FMT_COUNTERVALUE* pMem)
{
	if (pMem == NULL)
	{
		return;
	}
	else
	{
		::GlobalFree(static_cast<HGLOBAL> (pMem)	);
	}
	return;
}
PDH_STATUS CLocalPdh::GetFormattedCounterValue(const tstring&	sName, PDH_FMT_COUNTERVALUE* pMem, DWORD dwFormat)
{
	CounterMap::iterator itr = m_mapCounter.find(sName);
	if (itr == m_mapCounter.end())
	{
		return -1;
	}
	return ::PdhGetFormattedCounterValue(itr->second.m_hCounter, dwFormat, (LPDWORD)NULL, pMem);
}

PDH_STATUS CLocalPdh::GetFormattedCounterValue(const tstring& sMachine, 
													  const tstring& sObject,
													  const tstring& sCounter,
													  const tstring& sInstance,
													  PDH_FMT_COUNTERVALUE* pMem, 
													  DWORD dwFormat,
													  const DWORD& dwInstanceIndex,
													  const tstring& sParentIndex)

{
	tstring sName = sMachine + _T("/") + sObject + _T("/") + sCounter + _T("/") + sInstance + _T("/") + sParentIndex + _T("/");
	TCHAR temp[34];
	_itot(int(dwInstanceIndex), temp, 10);
	sName += temp;

	CounterMap::iterator itr = m_mapCounter.find(sName);
	if (itr == m_mapCounter.end())
	{
		return -1;
	}
	return ::PdhGetFormattedCounterValue(itr->second.m_hCounter, dwFormat, (LPDWORD)NULL, pMem);
}

PDH_STATUS	CLocalPdh::AddCounter(const tstring& sMachine, 
								const tstring& sObject,
								const tstring& sCounter,
								const tstring& sInstance,
								const DWORD& dwInstanceIndex,
								const tstring& sParentIndex)
{
	tstring sName = sMachine + _T("/") + sObject + _T("/") + sCounter + _T("/") + sInstance + _T("/") + sParentIndex + _T("/");

	TCHAR temp[34];
	_itot(LONG(dwInstanceIndex), temp, 10);
	sName += temp;
	PDH_COUNTER_PATH_ELEMENTS _info;
	::ZeroMemory(&_info, sizeof(PDH_COUNTER_PATH_ELEMENTS));
	_info.dwInstanceIndex = dwInstanceIndex;
	if (sObject.length())
		_info.szObjectName = const_cast<LPTSTR> (sObject.c_str());
	if (sMachine.length())
		_info.szMachineName = const_cast<LPTSTR> (sMachine.c_str());
	if (sCounter.length())
		_info.szCounterName = const_cast<LPTSTR> (sCounter.c_str());
	if (sInstance.length())
		_info.szInstanceName = const_cast<LPTSTR> (sInstance.c_str());
	if (sParentIndex.length())
		_info.szParentInstance = const_cast<LPTSTR> (sParentIndex.c_str());
	TCHAR buf[1024];
	DWORD dwSize = 1023;
	PDH_STATUS status = ::PdhMakeCounterPath(&_info, buf, &dwSize, 0);

	if (ERROR_SUCCESS != status)
	{
		return status;
	}
	if (sMachine.length())
	{
		if (m_setHostInfo.find(sMachine) == m_setHostInfo.end())
		{
			//TLOG1("machine not Exist : %s", sMachine.c_str());
			status = ::PdhConnectMachine(sMachine.c_str());
			if (ERROR_SUCCESS != status)
			{
				return status;
			}
			m_setHostInfo.insert(sMachine);
		}
	}
	return AddCounter(sName, buf);
}


