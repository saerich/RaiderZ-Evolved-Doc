// PMSConnServerView.cpp : CPMSConnServerView Ŭ������ ����
//

#include "stdafx.h"
#include "PMSConnServer.h"

#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"
#include ".\pmsconnserverview.h"

#include "ConfigInfo.h"
#include "Control.h"

#include "GSControler.h"
#include "GSLinkManager.h"
#include "GSLinkManagerADL.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

static HTHREADPOOL _HThreadPool = 0;

HTHREADPOOL GetThreadPool()
{
	ASSERT(_HThreadPool != NULL);
	return _HThreadPool;
}

// CPMSConnServerView

IMPLEMENT_DYNCREATE(CPMSConnServerView, CFormView)

BEGIN_MESSAGE_MAP(CPMSConnServerView, CFormView)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_MESSAGE, OnNMDblclkListMessage)
	ON_NOTIFY(NM_CLICK, IDC_LIST_GS, OnNMClickListGs)
	ON_BN_CLICKED(IDC_BUTTON_GSSTART, OnBnClickedButtonGsstart)
	ON_BN_CLICKED(IDC_BUTTON_GSSTOP, OnBnClickedButtonGsstop)
	ON_BN_CLICKED(IDC_BUTTON_GSRESTART, OnBnClickedButtonGsrestart)
	ON_BN_CLICKED(IDC_BUTTON_SENDNOTICE, OnBnClickedButtonSendnotice)
	ON_EN_CHANGE(IDC_EDIT_NOTICE, OnEnChangeEditNotice)
	ON_NOTIFY(NM_CLICK, IDC_LIST_MESSAGE, OnNMClickListMessage)
	ON_BN_CLICKED(IDC_BUTTON_SHOWSTAT, OnBnClickedButtonShowstat)
END_MESSAGE_MAP()

// CPMSConnServerView ����/�Ҹ�

CPMSConnServerView::CPMSConnServerView()
	: CFormView(CPMSConnServerView::IDD)
	, m_edit_notice(_T(""))
{
	gsrow = -1;
}

CPMSConnServerView::~CPMSConnServerView()
{
	delete statDlg;
}

void CPMSConnServerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RICHEDIT_MSG, m_richedit_msg);
	DDX_Control(pDX, IDC_LIST_MESSAGE, m_list_message);
	DDX_Control(pDX, IDC_LIST_GS, m_list_gs);
	DDX_Control(pDX, IDC_CHECK1, m_button_check1);
	DDX_Control(pDX, IDC_CHECK2, m_button_check2);
	DDX_Control(pDX, IDC_CHECK3, m_button_check3);
	DDX_Control(pDX, IDC_CHECK4, m_button_check4);
	DDX_Text(pDX, IDC_EDIT_NOTICE, m_edit_notice);
}

BOOL CPMSConnServerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	// Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CFormView::PreCreateWindow(cs);
}

void CPMSConnServerView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	//ResizeParentToFit();

	SetDefaultComponents();

	//SetRichEditColor(11,135,211);
	//SetRichEditColor(30,50,80);

	// 12345
//	SetListItem(123, 1, _T("���"), _T("0,4,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0"));
	//SetListItem(123, 1, _T("���"), _T("0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237"));
//	SetListGS(_T("name"), _T("path"), _T("gsid"), _T("255.255.255.255"), _T("port"), _T("��ũ��Ʈ"), _T("cnf"));


	InitializeModule();
}


// CPMSConnServerView ����

#ifdef _DEBUG
void CPMSConnServerView::AssertValid() const
{
	CFormView::AssertValid();
}

void CPMSConnServerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CPMSConnServerDoc* CPMSConnServerView::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPMSConnServerDoc)));
	return (CPMSConnServerDoc*)m_pDocument;
}
#endif //_DEBUG


// CPMSConnServerView �޽��� ó����

void CPMSConnServerView::SetDefaultComponents(void)
{
	m_button_check1.SetCheck(TRUE);
	m_button_check2.SetCheck(TRUE);
	m_button_check3.SetCheck(TRUE);
	m_button_check4.SetCheck(FALSE);

	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_COLOR | CFM_UNDERLINE | CFM_BOLD;
	cf.dwEffects =(unsigned long) ~( CFE_AUTOCOLOR | CFE_UNDERLINE | CFE_BOLD);
	cf.crTextColor = RGB(30,50,80);
	m_richedit_msg.SetDefaultCharFormat(cf);

	cf2.dwMask = CFM_COLOR | CFM_SPACING | CFM_OFFSET;
	cf2.dwEffects = CFE_UNDERLINE;
	cf2.yOffset = 30;

	m_richedit_msg.SetSel(-1, -1);

	SetRichEditColor(230,50,80);
	SetRichEditText(_T("[Start]\n\n"));

	LV_COLUMN lvcolumn1;
	lvcolumn1.mask = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvcolumn1.fmt	= LVCFMT_LEFT;

	lvcolumn1.pszText	=	_T("NO");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 50;
	m_list_message.InsertColumn(0, &lvcolumn1);

	lvcolumn1.pszText	=	_T("DATE/TIME");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 140;
	m_list_message.InsertColumn(1, &lvcolumn1);

	lvcolumn1.pszText	=	_T("GSID");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 50;
	m_list_message.InsertColumn(2, &lvcolumn1);

	lvcolumn1.pszText	=	_T("COMM");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 55;
	m_list_message.InsertColumn(3, &lvcolumn1);

	lvcolumn1.pszText	=	_T("SIZE");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 50;
	m_list_message.InsertColumn(4, &lvcolumn1);

	lvcolumn1.pszText	=	_T("TYPE");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 70;
	m_list_message.InsertColumn(5, &lvcolumn1);

	lvcolumn1.pszText	=	_T("VALUE");
	lvcolumn1.iSubItem	=	0;
	lvcolumn1.cx = 600;
	m_list_message.InsertColumn(6, &lvcolumn1);
	m_list_message.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);


	LV_COLUMN lvcolumn2;
	lvcolumn2.mask = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvcolumn2.fmt	= LVCFMT_LEFT;

	lvcolumn2.pszText	=	_T("NO");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 35;
	m_list_gs.InsertColumn(0, &lvcolumn2);

	lvcolumn2.pszText	=	_T("Name");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 150;
	m_list_gs.InsertColumn(1, &lvcolumn2);

	lvcolumn2.pszText	=	_T("Path");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 0;
	m_list_gs.InsertColumn(2, &lvcolumn2);

	lvcolumn2.pszText	=	_T("GSID");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 45;
	m_list_gs.InsertColumn(3, &lvcolumn2);

	lvcolumn2.pszText	=	_T("HA IP");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 110;
	m_list_gs.InsertColumn(4, &lvcolumn2);

	lvcolumn2.pszText	=	_T("PORT");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 50;
	m_list_gs.InsertColumn(5, &lvcolumn2);

	lvcolumn2.pszText	=	_T("Run Type");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 70;
	m_list_gs.InsertColumn(6, &lvcolumn2);

	lvcolumn2.pszText	=	_T("CNF File");
	lvcolumn2.iSubItem	=	0;
	lvcolumn2.cx = 160;
	m_list_gs.InsertColumn(7, &lvcolumn2);

	m_list_gs.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);

	UpdateData(false);
}

void CPMSConnServerView::SetRichEditColor(int ColorR, int ColorG, int ColorB)
{
	cf2.crTextColor = RGB(ColorR,ColorG,ColorB);
	m_richedit_msg.SetSelectionCharFormat(cf2);
}

void CPMSConnServerView::SetRichEditText(CString strMessage)
{
	m_richedit_msg.ReplaceSel(strMessage);
	m_richedit_msg.SendMessage(WM_VSCROLL, SB_BOTTOM);
}

void CPMSConnServerView::SetRichEditInteger(int numMessage)
{
	CString convertString;
	convertString.Format(_T("%d"), numMessage);
	m_richedit_msg.ReplaceSel(convertString);
	m_richedit_msg.SendMessage(WM_VSCROLL, SB_BOTTOM);
}

void CPMSConnServerView::SetListItem(int gsid, int comm, int size, CString type, CString value)
{
	int row = m_list_message.GetItemCount();

	if ( (m_button_check1.GetCheck() == FALSE) && (type == _T("�����ս�")) ) return;
	if ( (m_button_check2.GetCheck() == FALSE) && (type == _T("����")) ) return;
	if ( (m_button_check3.GetCheck() == FALSE) && (type == _T("���")) ) return;
	if ( (m_button_check3.GetCheck() == FALSE) && (type == _T("���(PC)")) ) return;

	TCHAR buff[8];

	_itot(row+1, buff, 10);
	m_list_message.InsertItem(row, buff);
	m_list_message.SetItemText(row, 1, GetCurrentDateTime());
	_itot(gsid, buff, 10);
	m_list_message.SetItemText(row, 2, buff);
	switch (comm)
	{
	case 0:
		m_list_message.SetItemText(row, 3, _T("TEXT"));
		break;
	case 1:
		m_list_message.SetItemText(row, 3, _T("ADL"));
		break;
	default:
		m_list_message.SetItemText(row, 3, _T("Unknown"));
		break;
	}

	_itot(size, buff, 10);
	m_list_message.SetItemText(row, 4, buff);
	m_list_message.SetItemText(row, 5, type);
	m_list_message.SetItemText(row, 6, value);	

	m_list_message.SendMessage(WM_VSCROLL, SB_BOTTOM);
}

void CPMSConnServerView::SetListGS(CString name, CString path, CString gsid, CString ipaddress, CString port, CString run, CString cnffile)
{
	int row = m_list_gs.GetItemCount();

	TCHAR buff[8];

	_itot(row+1, buff, 10);
	m_list_gs.InsertItem(row, buff);
	m_list_gs.SetItemText(row, 1, name);
	m_list_gs.SetItemText(row, 2, path);
	m_list_gs.SetItemText(row, 3, gsid);
	m_list_gs.SetItemText(row, 4, ipaddress);
	m_list_gs.SetItemText(row, 5, port);
	m_list_gs.SetItemText(row, 6, run);
	m_list_gs.SetItemText(row, 7, cnffile);
}

CString CPMSConnServerView::GetCurrentDateTime()
{
	CString strTemp;
	getDateTime = CTime::GetCurrentTime();

	TCHAR curDateTime[20];

	_stprintf(curDateTime, _T("%04d-%02d-%02d %02d:%02d:%02d"),
		getDateTime.GetYear(),getDateTime.GetMonth(),getDateTime.GetDay(),
		getDateTime.GetHour(),getDateTime.GetMinute(),getDateTime.GetSecond());

	strTemp = curDateTime;
	strTemp.TrimRight();

	return strTemp;
}

void CPMSConnServerView::OnNMClickListMessage(NMHDR *pNMHDR, LRESULT *pResult)
{
	int row = m_list_message.GetNextItem(-1, LVNI_FOCUSED);

	if (m_list_message.GetItemText(row,4) != "���") return;
	
//	SetRichEditText(m_list_message.GetItemText(row,5).GetBuffer());
//	ClipCopy(m_list_message.GetItemText(row,5).GetBuffer());

	*pResult = 0;
}


void CPMSConnServerView::OnNMDblclkListMessage(NMHDR *pNMHDR, LRESULT *pResult)
{
	int row = m_list_message.GetNextItem(-1, LVNI_FOCUSED);

	if ( (m_list_message.GetItemText(row,5) == "���") || (m_list_message.GetItemText(row,5) == "���(PC)") )
	{
		statDlg->AddData(m_list_message.GetItemText(row,2), 
			m_list_message.GetItemText(row,4),
			m_list_message.GetItemText(row,1),
			m_list_message.GetItemText(row,6));
			
		statDlg->ShowWindow(SW_SHOW);
	}

	*pResult = 0;
}

void CPMSConnServerView::OnNMClickListGs(NMHDR *pNMHDR, LRESULT *pResult)
{
	gsrow = m_list_gs.GetNextItem(-1, LVNI_FOCUSED);
	
	*pResult = 0;
}

void CPMSConnServerView::OnBnClickedButtonGsstart()
{
	gsrow = m_list_gs.GetNextItem(-1, LVNI_FOCUSED);
	if (gsrow == -1) return; 

	PMSControlReq msg;

	msg.m_dwTargetID = _tstol(m_list_gs.GetItemText(gsrow,3).GetBuffer());
	msg.m_lCtrType = CT_GSISTART;
	theGSControler.GSIControl(msg);
}

void CPMSConnServerView::OnBnClickedButtonGsstop()
{
	gsrow = m_list_gs.GetNextItem(-1, LVNI_FOCUSED);
	if (gsrow == -1) return; 

	PMSControlReq msg;
	msg.m_dwTargetID = _tstol(m_list_gs.GetItemText(gsrow,3).GetBuffer());
	msg.m_lCtrType = CT_GSISHUTDOWN;
	theGSControler.GSIControl(msg);
}

void CPMSConnServerView::OnBnClickedButtonGsrestart()
{
	gsrow = m_list_gs.GetNextItem(-1, LVNI_FOCUSED);
	if (gsrow == -1) return; 

	PMSControlReq msg;
	msg.m_dwTargetID = _tstol(m_list_gs.GetItemText(gsrow,3).GetBuffer());
	msg.m_lCtrType = CT_GSIRESTART;
	theGSControler.GSIControl(msg);
}


void CPMSConnServerView::OnBnClickedButtonSendnotice()
{
	gsrow = m_list_gs.GetNextItem(-1, LVNI_FOCUSED);
	if (gsrow == -1) return; 


	CString AnnounceMsg;
	GetDlgItemText(IDC_EDIT_NOTICE, AnnounceMsg);

	if (AnnounceMsg.IsEmpty() == TRUE) return;

	PMSAnnounceReq msg;

	msg.m_unitID.m_dwGSID = _tstol(m_list_gs.GetItemText(gsrow,3).GetBuffer());
	msg.m_sAnnMsg = AnnounceMsg;

	GBuf buf, buf2;
	::BStore(buf, msg);
	::BStore(buf2, msg);
	LPXBUF lpXBuf = buf.Detach();
	LPXBUF lpXBuf2 = buf2.Detach();
	::XsigQueueSignal(GetThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_ANNOUNCEREQ, 0, (LPARAM)lpXBuf);
	::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_ANNOUNCEREQ, 0, (LPARAM)lpXBuf2);
}

void CPMSConnServerView::OnEnChangeEditNotice()
{
	UpdateData(true);

	int length = 0;

	for (int i = 0; i<lstrlen(m_edit_notice); i++)
	{
		if ( m_edit_notice.GetAt(i) > 127)
			length = length + 2;
		else
			length = length + 1;
	}

	TCHAR ComboLength[16];
	_itot(length, ComboLength, 10);

	SetDlgItemText(IDC_EDIT_LENGTH, ComboLength);
}


void CPMSConnServerView::ClipCopy(TCHAR *txt)
{
	HGLOBAL hglbCopy;
	TCHAR *lptstrCopy;

	if ( !OpenClipboard() ) return;
	if( !EmptyClipboard() ) return;

	hglbCopy = GlobalAlloc(GMEM_MOVEABLE, _tcslen(txt)*2+2);
	if (hglbCopy == NULL)
	{
		CloseClipboard();
		return;
	}
	lptstrCopy = (TCHAR*)GlobalLock(hglbCopy);
	memcpy(lptstrCopy, txt, _tcslen(txt)*2+2);
	GlobalUnlock(hglbCopy);

	SetClipboardData(CF_TEXT, hglbCopy);
	CloseClipboard();
}

void CPMSConnServerView::InitializeModule(void)
{
	_HThreadPool = ::XtpCreatePool(10);
	::xsehSetStructuredExceptionHandler(_T("VirtualPMS"), LOG_DIRECTORY, true, MINIDUMP_FULL, true);
	//HRESULT hr = ::CoInitializeEx(NULL,COINIT_MULTITHREADED);

	//if (FAILED(hr))
	//{
	//	SetRichEditText(_T("Coinitialize Error\n"));
	//}

	statDlg = new CStatisticsDialog(this);
	statDlg->Create(IDD_DIALOG_STATISTICS, GetDesktopWindow());

	if (!g_ConfigInfo.LoadConfig())
	{
		SetRichEditText(_T("Cannot find config\n"));
	}

	if (!theControl.InitControl())
	{
		SetRichEditText(_T("Control Init Error\n"));
	}

	if (!theControl.RunControl())
	{
		SetRichEditText(_T("Control Run Error\n"));
	}

	if (g_ConfigInfo.GetLoadType() == 1)
		SetDlgItemText(IDC_STATIC_GSINFOTYPE, _T("(.ini file)"));
	else
		SetDlgItemText(IDC_STATIC_GSINFOTYPE, _T("(DB)"));
}

BOOL CPMSConnServerView::GetAddStatisticsFlag()
{
	return m_button_check4.GetCheck();
}

void CPMSConnServerView::AddStatisticsData(long gsid, int size, CString data)
{
	CString strGSID;
	strGSID.Format(_T("%d"), gsid);

	TCHAR strSize[8];
	_itot(size, strSize, 10);

	statDlg->AddData(strGSID, strSize, GetCurrentDateTime(), data);
}

void CPMSConnServerView::OnBnClickedButtonShowstat()
{
	statDlg->ShowWindow(SW_SHOW);
}

