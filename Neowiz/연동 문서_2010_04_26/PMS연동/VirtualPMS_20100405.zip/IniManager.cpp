#include "StdAfx.h"
#include "IniManager.h"
#include <windows.h>

using std::string;

CIniManager::CIniManager(void)
{
}

CIniManager::~CIniManager(void)
{
}

CIniManager::CIniManager(const tstring&sIniFileName)
:m_sIniFileName(sIniFileName)
{
}

#ifdef UNICODE 
tstring CIniManager::GetValueByAscii(const tstring& sSectionName, const tstring& sLeftValue)
{
	return tstring(_T(""));

}
#endif
tstring CIniManager::GetValue(const tstring& sSectionName, const tstring& sLeftValue)
{
	TCHAR szBuf[512] = {0};
	DWORD ret = ::GetPrivateProfileString(sSectionName.c_str(), sLeftValue.c_str(), _T(""), szBuf, 512, m_sIniFileName.c_str());
	if (ret == 0 || _tcslen(szBuf) == 0)
	{
		return tstring(_T(""));
	}
	else
	{
		return tstring(szBuf);
	}
}
int	   CIniManager::GetIntValue(const tstring& sSectionName, const tstring& sLeftValue)
{
	return ::GetPrivateProfileInt(sSectionName.c_str(), sLeftValue.c_str(), 0, m_sIniFileName.c_str());
	
}

BOOL CIniManager::PutValue(const tstring& sSectionName, const tstring& sLeftValue, const int& nRightValue)
{
	TCHAR temp[128];
	_itot(nRightValue, temp, 10);
	return PutValue(sSectionName, sLeftValue, temp);
}

BOOL CIniManager::PutValue(const tstring& sSectionName, const tstring& sLeftValue, const tstring& sRightValue)
{
	return ::WritePrivateProfileString(sSectionName.c_str(), sLeftValue.c_str(), sRightValue.c_str(), m_sIniFileName.c_str());
}

void CIniManager::SetIniFileName(const tstring& sIniFileName, const BOOL& isCurFolder)
{
	if (isCurFolder)
	{
		TCHAR buf[_MAX_PATH+1] = {0, };
		DWORD dwLen = _MAX_PATH;
		dwLen = ::GetModuleFileName(NULL, buf, dwLen);
		m_sIniFileName.clear();
		if (dwLen )
		{
			LPTSTR pLastSlash = _tcsrchr(buf, '\\');
			if (pLastSlash != NULL)
			{
				*(pLastSlash+1) = 0;
				m_sIniFileName.assign( buf, _tcslen(buf));
			}
		}
		if (m_sIniFileName.length() == 0)
			m_sIniFileName = INI_DIRECTORY;
		m_sIniFileName += sIniFileName;
	}
	else
	{
		m_sIniFileName = sIniFileName;
	}
}
