#include "stdafx.h"
#include "common.h"

#include "ClientMgr.h"
#include "DBManager.h"

#include "GSLinkManager.h"
#include "GSLinkManagerADL.h"
#include "HeartBeatManager.h"
#include "PerformanceManager.h"
#include "StatisticManager.h"
#include "control.h"
#include "../include/ADL/PMS_HA.h"
#include "../include/ADL/PMS_MA.h"
#include "GSControler.h"

CClientManager theManagerCli;

CClientManager::CClientManager()
{
	m_bConnect = FALSE;
}

CClientManager::~CClientManager()
{
	if(m_ConnectTimer.IsActive())
	{
		m_ConnectTimer.Deactivate();
		theErr.LOG2(1,_T("[CClientManager] Destory Timer Deact\n"));
	}
}

/////////////////////////////////////////////////////////////////////
// MA�� ���� �޴� �޽���

BOOL CClientManager::OnError(CLink* pLink, long lEvent, int nErrorCode)
{
	TLock lo(this);
	theErr.LOG(1,_T("CClientManager] OnError(%d)\n"), pLink->GetHandle());

	BOOL bRet = TRUE;
	m_bConnect = FALSE;
	if(!m_ConnectTimer.IsActive())
		bRet = bRet  && m_ConnectTimer.Activate(GetThreadPool(), this, INTERVAL, INTERVAL);

	CLink* pLink1 = Detach();
	ASSERT(pLink1 == pLink);

	pLink->Unregister();
	delete (pLink);
	return TRUE;
}

STDMETHODIMP_(void)  CClientManager::OnSignal (HSIGNAL hSignal, WPARAM wParam, LPARAM lParam)
{
	if(hSignal == (HSIGNAL)HASIGNAL_GSFAULT)
	{
		TLock lo(this);
		PMSFaultInfo pmsFaultInfo;
		GBuf buf((LPXBUF)lParam, FALSE);
		::BLoad(pmsFaultInfo, buf);
		TreatGSFault(pmsFaultInfo);
	}
	else if(hSignal == (HSIGNAL)HASIGNAL_GSISTARTNTF)
	{
		TLock lo(this);
		SendGSStartNtf(lParam);
	}
	else if(hSignal == (HSIGNAL)HASIGNAL_WARNINGNTF)
	{
		TLock lo(this);
		PMSFaultInfo pmsFaultInfo;
		GBuf buf((LPXBUF)lParam, FALSE);
		::BLoad(pmsFaultInfo, buf);
		TreatGSWarningNtf(pmsFaultInfo);
	}
	else if(hSignal == (HSIGNAL)HASIGNAL_REQSENDTOMA)
	{
		TLock lo(this);
		LPXBUF lpXBuf = (LPXBUF) lParam;
		GBuf buf(lpXBuf, FALSE);
		SendToMA(buf);
		//m_pLink->DoSend(buf);
	}
	else if(hSignal == 0)
	{
		return;
	}
	else
	{
		if(m_ConnectTimer.IsHandle(hSignal)) 
		{
			TLock lo(this);
			if(!m_bConnect)
			{
				if(MAConnect())
				{
					m_ConnectTimer.Deactivate();
					theErr.LOG(1,_T("[CClientManager] Retry Connect Success\n"));
				}
				else 
					theErr.LOG(1,_T("[CClientManager] Retry Connect Fail\n"));
			}
		}
		else
		{
			TLock lo(this);
			TBase::OnSignal(hSignal,wParam,lParam);
		}
	}
}

void CClientManager::TreatGSFault(PMSFaultInfo & info)
{
	theErr.LOG(1,_T("[CClientManager] TreatGSFault\n"));

	if(info.m_lGSState == GS_START)
	{
		//int nFID = thedbmanager.InsertLog(info);
		int nFID = S_OK;
		if(nFID < 0)
			nFID = -1;
		info.m_lFaultID = nFID;

		if(info.m_lReason == FT_GSITERM)
		{
			theErr.LOG(1,_T("[CClientManager] Remove St/Pf/HB Manager\n"));
			theStManager.RemoveClient(info.m_dwGSID);
			thePfManager.RemoveClient(info.m_dwGSID);
			theHBManager.RemoveClient(info.m_dwGSID);
		}

		SendFaultNtf(info);
		theErr.LOG(1,_T("[CClientManager] Treat GS terminate notify : GSID %d FID %d \n"), info.m_dwGSID, nFID);
	}
	else 
	{
		theErr.LOG(1,_T("[CClientManager] Treat GS : theStManager.RemoveClient"));
		theStManager.RemoveClient(info.m_dwGSID);
		theErr.LOG(1,_T("[CClientManager] Treat GS : thePfManager.RemoveClient"));
		thePfManager.RemoveClient(info.m_dwGSID);
		theErr.LOG(1,_T("[CClientManager] Treat GS : theHBManager.RemoveClient"));
		theHBManager.RemoveClient(info.m_dwGSID);
		theErr.LOG(1,_T("[CClientManager] Treat GS : RemoveClient (%d) finished"), info.m_dwGSID);
	}
}

void CClientManager::TreatGSWarningNtf(PMSFaultInfo & info)
{
	//LONG _fid = thedbmanager.InsertLog(info);
	LONG _fid = S_OK;

	if(_fid < 0) _fid = -1;
	info.m_lFaultID = _fid;

	//PMSMessage_MA pld(PMSMessage_MA::faultNtf_Tag);
	//pld.un.m_faultNtf->m_dwFaultID = _fid;
	//pld.un.m_faultNtf->m_dwGSID = info.m_dwGSID;
	//pld.un.m_faultNtf->m_dwHAID = atoi(info.m_sHAID.c_str()); 
	//pld.un.m_faultNtf->m_lLevel = info.m_lLevel;
	//pld.un.m_faultNtf->m_lReason = info.m_lReason;
	//pld.un.m_faultNtf->m_sDesc = info.m_sDesc;
	//pld.un.m_faultNtf->m_sProc = info.m_sProc;
	//pld.un.m_faultNtf->m_sTime = info.m_sTime;

	SendFaultNtf(info);
}

BOOL CClientManager::OnRcvMsg(CLink*pLink, PMSPayload_HA& msg)
{
	printf("[CClientManager] Recv from MA : TagID %d \n", msg.m_message.mTagID);
	switch(msg.m_message.mTagID)
	{
	case PMSMessage_HA::registerhaAns_Tag:
		OnRcvHARegisterAns(*msg.m_message.un.m_registerhaAns);
		break;
	case PMSMessage_HA::announceReq_Tag:
		OnRcvAnnounceReq(*msg.m_message.un.m_announceReq);
		break;
	case PMSMessage_HA::controlReq_Tag:
		OnRcvControlReq(*msg.m_message.un.m_controlReq);
		break;
	//case PMSMessage_HA::gameStatusReq_Tag:	// statistics �� ����?
	case PMSMessage_HA::statisticsReq_Tag:
		OnRcvStatisticsReq(*msg.m_message.un.m_statisticsReq);
		break;
	//case PMSMessage_HA::haConfigUpdateReq_Tag:
	//	bRet = OnRcvHAConfigUpdateReq(pLink,msg.m_message.un.m_haConfigUpdateReq);
	//	break;
	case PMSMessage_HA::orderReq_Tag:
		OnRcvOrderReq(*msg.m_message.un.m_orderReq);
		break;
	case PMSMessage_HA::performanceReq_Tag:
		OnRcvPerformanceReq(*msg.m_message.un.m_performanceReq);
		break;
	case PMSMessage_HA::heartBeatReq_Tag:
		OnRcvHeartBeatReq(*msg.m_message.un.m_heartBeatReq);
		break;
	default:
		theErr.LOG(1, _T("[CClientManager] Unknown message from MA .. %d"), msg.m_message.mTagID);
	}
	return TRUE;
}



BOOL CClientManager::ReadHAConfigFile()
{
	BOOL bRet=TRUE;
	DWORD dwSize = 0UL;
	LPTSTR lpFileName = NULL;
	LPTSTR lpszReturnBuffer = NULL;
	DWORD dwRet = GetPrivateProfileSectionNames(lpszReturnBuffer,dwSize,lpFileName);
	if(dwRet == 0)
	{
		return FALSE;
	}

	while(TRUE)
	{

	}

	return bRet;

}
BOOL CClientManager::InitCliManager()
{	
	if(!MAConnect())
	{
		m_bConnect=FALSE;
		return FALSE;
	}	
	return TRUE;
}


BOOL CClientManager::MAConnect()
{
	GSocket gSocket;
	gSocket.Create(0,SOCK_STREAM,0);

	if(!gSocket.Connect(theGSInfoTable.GetMAIP(), _tstoi( theGSInfoTable.GetMAPort().c_str() ) ))
	{	// WOULDBLOCK ó���� .. jsp
		BOOL bRet=TRUE;
		theErr.LOG(1,_T("[CClientManager] Connect Error IP( %s ) / PORT (%s)\n"),theGSInfoTable.GetMAIP().c_str(), theGSInfoTable.GetMAPort().c_str());
		if(!m_ConnectTimer.IsActive())
		{
			bRet = bRet && m_ConnectTimer.Activate(GetThreadPool(), this, HEART_INTERVAL, HEART_INTERVAL);
			VALIDATE(bRet);
		}
		return FALSE; 
	}
	theErr.LOG(1,_T("[CClientManager] Connect to MA Success\n"));
	m_bConnect = TRUE;

	SOCKET hSocket = gSocket.Detach();

	m_pLink = new CLink();
	m_pLink->Register(hSocket, this, HSIGNAL_XLINKHANDLER);

	VALIDATE(Attach(m_pLink));

	SendHARegisterReq();

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
// MA�κ��� ������ �޼����� GSLinkManager �Ǵ� GSLinkManagerADL�� �б�..��û	jsp
// 
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

void CClientManager::OnRcvControlReq(PMSControlReq & msg)
{
	GBuf buf;
	::BStore(buf, msg);
	LPXBUF lpXBuf = buf.Detach();
	::XsigQueueSignal(GetThreadPool(), &theGSControler, (HSIGNAL)HASIGNAL_CONTROLREQ, 0, (LPARAM)lpXBuf);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void CClientManager::OnRcvStatisticsReq(PMSStatisticsReq & msg)
{

	::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_STATINFOREQ, 0, (LPARAM)0);//lpXBuf);

}

///////////////////////////////////////////////////////////////////////////////////////////////////
void CClientManager::OnRcvOrderReq(PMSOrderReq & msg)
{
	GBuf buf;
	::BStore(buf, msg);
	LPXBUF lpXBuf = buf.Detach();

	// manager �������� ��� ����.. ���� ������ ó������ ���� ����? .. jsp
	// �� ���, ������ �ΰ����� �� ��� ��� ó���ϳ�?
	// ADL link manager������ order�� �����(�߰���)..
	//::XsigQueueSignal(GetMThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_ORDERREQ, 0, (LPARAM)lpXBuf);
	::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_ORDERREQ, 0, (LPARAM)lpXBuf);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void CClientManager::OnRcvPerformanceReq(PMSPerformanceReq & msg)
{
	//GBuf buf;
	//::BStore(buf, msg);
	//LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &thePfManager, (HSIGNAL)HASIGNAL_PERFORMREQ, 0, (LPARAM)0);//lpXBuf);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void CClientManager::OnRcvHeartBeatReq(PMSHeartBeatReq & msg)
{
	// MA�� HA�� Active ���¸� Ȯ���ϱ� ���� �޼���.. 
	PMSMessage_MA pld(PMSMessage_MA::heartBeatAns_Tag);
	pld.un.m_heartBeatAns->m_dwSeq = msg.m_dwSeq;
	GBuf buf;
	::LStore(buf, pld);
	SendToMA(buf);
}

void CClientManager::SendHARegisterReq()
{
	PMSMessage_MA pld(PMSMessage_MA::haregisterReq_Tag);
	pld.un.m_haregisterReq->m_dwHAID = (DWORD)_tstol(theGSInfoTable.GetHAID().c_str());
	pld.un.m_haregisterReq->m_sHostName = tstr2str(theGSInfoTable.GetHostName());

	GBuf buf;
	::LStore(buf, pld);
	SendToMA(buf);
}


///////////////////////////////////////////////////////////////////////////////////////////////////


void CClientManager::OnRcvHARegisterAns(PMSHARegisterAns & msg)
{	
	LONG lErrType = msg.m_lErr;
	switch(lErrType)
	{
	case HRE_NOTREGISTERED:// ��ϵ��� ���� HAID
		break;
	case HRE_SUCCESS:// ��� ���� 
		theErr.LOG(1,_T("[LINKMANAGERCLI] Reg SUCCESS \n"));
		break;
	case HRE_UNKNOWN:// �� �� ���� ����
		theErr.LOG(1,_T("HARegisterAns UNKNOWN \n"));
		break;
	case HRE_ALREADYRUN:// ���� �������� HAID
		theErr.LOG(1,_T("HARegisterAns ALREADYRUN\n"));
		break;
	}
	
	SendStartedServerNtf();
}

void CClientManager::SendStartedServerNtf()
{
	typedef ArcMapT<tstring, GSINFO*> GSINFOTABLE;
	GSINFOTABLE & tbl = theGSSessionTable.GetTable();

	ForEachElmt(GSINFOTABLE, tbl, it, jt)
	{
		tstring sGSID = it->first;
		GSINFO * pInfo = it->second;

		if(pInfo->m_sStartTime.length() > 4)
		{
			PMSStartupInfo info;
			info.m_dwGSID = _tstol(sGSID.c_str());
			info.m_sOptAddr = tstr2str(pInfo->m_sOptAddr);
			info.m_sStartTime = tstr2str(pInfo->m_sStartTime);
			_SendGSStartNtf(info);
		}
	}
}

// server�� ��û�� �ƴ϶�, GS�� �⵿�� ���� �߻��ϴ� �޼���. 
// .. control message�� answer�� ��� ���� ä�� �� ���� ����.. 
void CClientManager::SendGSStartNtf(LPARAM lParam)
{
	GBuf _temp((LPXBUF)lParam, FALSE);
	PMSStartupInfo startInfo;
	::BLoad(startInfo, _temp);

	_SendGSStartNtf(startInfo);
}

void CClientManager::_SendGSStartNtf(PMSStartupInfo & startInfo)
{
	PMSMessage_MA pld(PMSMessage_MA::gsistartNtf_Tag);
	pld.un.m_gsistartNtf->m_dwGSID = startInfo.m_dwGSID;
	pld.un.m_gsistartNtf->m_sOptAddr = startInfo.m_sOptAddr;
	pld.un.m_gsistartNtf->m_sStartTime = startInfo.m_sStartTime;

	GBuf buf;
	::LStore(buf, pld);
	SendToMA(buf);
}

//DB�� ������ ���� �ϰ� FID�� �޾Ƽ� MA�� �����Ѵ�.
void CClientManager::SendFaultNtf(PMSFaultInfo &info)
{
	GBuf buf;

	PMSMessage_MA pld(PMSMessage_MA::faultNtf_Tag);
	pld.un.m_faultNtf->m_dwFaultID = info.m_lFaultID;
	pld.un.m_faultNtf->m_dwGSID = info.m_dwGSID;
	pld.un.m_faultNtf->m_dwHAID = (DWORD)atoi(info.m_sHAID.c_str());
	pld.un.m_faultNtf->m_lHGID = theGSInfoTable.GetHostGroupID();
	pld.un.m_faultNtf->m_lLevel = info.m_lLevel;
	pld.un.m_faultNtf->m_lReason = info.m_lReason;
	pld.un.m_faultNtf->m_sDesc = info.m_sDesc;
	pld.un.m_faultNtf->m_sProc = info.m_sProc;
	pld.un.m_faultNtf->m_sTime = info.m_sTime;

	::LStore(buf, pld);
	SendToMA(buf);
}

/////////////////////////////////////////////////////////////////////////////////////////////////

void CClientManager::OnRcvAnnounceReq(PMSAnnounceReq &msg)
{		
	GBuf buf, buf2;
	::BStore(buf, msg);
	::BStore(buf2, msg);
	LPXBUF lpXBuf = buf.Detach();
	LPXBUF lpXBuf2 = buf2.Detach();

	// manager �������� ��� ����.. ���� ������ ó������ ���� ����
	::XsigQueueSignal(GetThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_ANNOUNCEREQ, 0, (LPARAM)lpXBuf);
	::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_ANNOUNCEREQ, 0, (LPARAM)lpXBuf2);

	theErr.LOG(0,_T("[CClientManager] ANN FROM MA\n"));
	tstring strDate;
	GetTimeFormat(strDate,3);

	PMSMessage_MA pld(PMSMessage_MA::announceAns_Tag);
	pld.un.m_announceAns->m_dwHAID = msg.m_dwHAID;
	pld.un.m_announceAns->m_dwMCID = msg.m_dwMCID;
	pld.un.m_announceAns->m_lErr = 0L;
	pld.un.m_announceAns->m_lHGID = msg.m_lHGID;
	pld.un.m_announceAns->m_lTargetRange = msg.m_lTargetRange;
	pld.un.m_announceAns->m_sAnnMsg = msg.m_sAnnMsg;
	pld.un.m_announceAns->m_sAnsTime = tstr2str(strDate);
	pld.un.m_announceAns->m_sReqTime = msg.m_sReqTime;
	pld.un.m_announceAns->m_unitID = msg.m_unitID;

	GBuf buf3;
	::LStore(buf3, pld);
	SendToMA(buf3);
}

