#pragma once

#include <GXLinkUtl.h>
#include "Link.h"
#include "../include/ADL/PMS_GS.h"

class CGSLinkManagerADL : public XLinkAdlManagerT<CLink, PayloadHA>
{
	IMPLEMENT_TISAFEREFCNT(CGSLinkManagerADL)

public:
	typedef PayloadHA TMsg;

	CGSLinkManagerADL(void);
	~CGSLinkManagerADL(void);
	
	BOOL AddADLClient(SOCKET hSocket, LPCSTR sIP);
	BOOL IsExistLink();
protected:
	virtual BOOL OnError(CLink* pLink, long lEvent, int nErrorCode);
	STDMETHOD_(void, OnSignal) (HSIGNAL hSig, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnRcvMsg(CLink* pLink, TMsg& msg);

	void TreatAnnounceMsg(LPVOID lpV);
	void TreatOrderMsg(LPVOID lpV);

	BOOL OnGSInitNtf(CLink * pLink, PMSAGSInitNtf & msg);
	void OnGSInitFaultNtf(CLink * pLink, PMSAInitFaultNtf & msg);
	BOOL SendToConfigInfo(CLink * pLink, tstring & sAppName, tstring & sGSID);
	void OnHeartBeatAns(PMSAHeartBeatAns & msg);
	void OnStatInfoAns(CLink * pLink, PMSAStatInfoAns & msg);
	void OnAnnounceAns(PMSAAnnounceAns & msg);
	void OnOrderAns(PMSAOrderAns & msg);
	void OnWarningNtf(PMSAWarningNtf & msg);
	void OnPerformAns(CLink * pLink, PMSAPerformAns & msg);
	void OnRegionInfoAns(PMSARegionInfoAns & msg, CLink * pLink);
	void OnStatInfoPCAns(CLink * pLink, PMSAStatInfoPCAns & msg);
	void OnRegionInfoPCAns(PMSARegionInfoPCAns & msg, CLink * pLink);


public:

private:

};

extern CGSLinkManagerADL theGSLinkManagerADL;