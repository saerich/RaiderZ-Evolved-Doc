#ifndef _LOCAL_PDH_H__
#define _LOCAL_PDH_H__
#pragma once
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <string>
#include <map>

using namespace std;

class CLocalPdh
{
public:
	struct CounterInfo
	{
		tstring m_sName;
		HCOUNTER	m_hCounter;
	};
	typedef map<tstring, CounterInfo> CounterMap;
	typedef set<tstring> HostInfoSet;
public:
	
	static PDH_STATUS	SetDefaultRealTimeDataSource(const DWORD& dwSourceID = DATA_SOURCE_WBEM);
	static PDH_STATUS	GetDllVersion(DWORD& dwVer);
public:
	CLocalPdh(void);
	virtual ~CLocalPdh(void);
public:
	PDH_STATUS	OpenQuery();
	PDH_STATUS	CloseQuery();
	PDH_STATUS	AddCounter(const tstring& sName, const tstring& sType);
	PDH_STATUS	AddCounter(const tstring& sMachine, 
						   const tstring& sObject,
						   const tstring& sCounter,
						   const tstring& sInstance,
						   const DWORD& dwInstanceIndex = -1,
						   const tstring& sParentIndex = _T(""));
	PDH_STATUS	GetFormattedCounterValue(const tstring& sMachine, 
						   			     const tstring& sObject,
									     const tstring& sCounter,
										 const tstring& sInstance,
										 PDH_FMT_COUNTERVALUE* pMem, 
										 DWORD dwFormat = PDH_FMT_DOUBLE,
										 const DWORD& dwInstanceIndex = -1,
										 const tstring& sParentIndex = _T(""));

	PDH_STATUS	RemoveCounter(const tstring& sName);
	PDH_STATUS	CollectQueryData();
	PDH_FMT_COUNTERVALUE*	AllocMemory();
	void		FreeMemory(PDH_FMT_COUNTERVALUE* pMem);
	PDH_STATUS	GetFormattedCounterValue(const tstring&	sName, PDH_FMT_COUNTERVALUE* pMem, DWORD dwFormat = PDH_FMT_DOUBLE);
protected:
	BOOL		m_bIsOpen;
	HQUERY		m_hQuery;
	map<tstring, CounterInfo>	m_mapCounter;
	set<tstring>	m_setHostInfo;

};

extern CLocalPdh g_pdh;
#endif // if not def _LOCAL_PDH_H__