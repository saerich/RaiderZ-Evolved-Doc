#pragma once

#include <string>
struct tagConfig
{
	int type;
	tstring m_sDBName;
	tstring m_sDBServer;
};

typedef tagConfig _Config;

class CConfigInfo
{
public:
	CConfigInfo(void);
	~CConfigInfo(void);
public:
	BOOL LoadConfig();
	tstring GetDBName() const;
	tstring GetDBServer() const;
	int GetLoadType() const;
	int GetLogValue() const;
private:
	_Config m_config;
	int nLog;
};

extern CConfigInfo g_ConfigInfo;

