// PMSConnServerView.h : iCPMSConnServerView Ŭ������ �������̽�
//

#pragma once
#include "afxcmn.h"

#include "StatisticsDialog.h"
#include "afxwin.h"

class CPMSConnServerView : public CFormView
{
protected: // serialization������ ��������ϴ�.
	DECLARE_DYNCREATE(CPMSConnServerView)

public:
	enum{ IDD = IDD_PMSCONNSERVER_FORM };

// Ư��
public:
	CPMSConnServerView();
	CPMSConnServerDoc* GetDocument() const;

private:
	CTime getDateTime;

// �۾�
public:
	CString GetCurrentDateTime();
	CStatisticsDialog *statDlg;
	int gsrow;
	void ClipCopy(TCHAR *txt);
	BOOL GetAddStatisticsFlag();
	void AddStatisticsData(long gsid, int size, CString data);

// ������
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����
	virtual void OnInitialUpdate(); // ���� �� ó�� ȣ��Ǿ����ϴ�.

// ����
public:
	virtual ~CPMSConnServerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CHARFORMAT cf; 
	CHARFORMAT2 cf2;

protected:

// �޽��� �� �Լ��� �����߽��ϴ�.
protected:
	DECLARE_MESSAGE_MAP()
public:
	CRichEditCtrl m_richedit_msg;
	void SetDefaultComponents(void);
	void SetRichEditColor(int ColorR, int ColorG, int ColorB);
	void SetRichEditText(CString strMessage);
	void SetRichEditInteger(int numMessage);
	void InitializeModule(void);
	CListCtrl m_list_message;
	void SetListItem(int gsid, int comm, int size, CString type, CString value);
	afx_msg void OnNMDblclkListMessage(NMHDR *pNMHDR, LRESULT *pResult);
	CListCtrl m_list_gs;
	void SetListGS(CString name, CString path, CString gsid, CString ipaddress, CString port, CString run, CString cnffile);
	afx_msg void OnNMClickListGs(NMHDR *pNMHDR, LRESULT *pResult);
	CButton m_button_check1;
	CButton m_button_check2;
	CButton m_button_check3;
	CButton m_button_check4;
	afx_msg void OnBnClickedButtonGsstart();
	afx_msg void OnBnClickedButtonGsstop();
	afx_msg void OnBnClickedButtonGsrestart();
	afx_msg void OnBnClickedButtonSendnotice();
	afx_msg void OnEnChangeEditNotice();
	CString m_edit_notice;
	afx_msg void OnNMClickListMessage(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonShowstat();
};

#ifndef _DEBUG  // PMSConnServerView.cpp�� ����� ����
inline CPMSConnServerDoc* CPMSConnServerView::GetDocument() const
   { return reinterpret_cast<CPMSConnServerDoc*>(m_pDocument); }
#endif


