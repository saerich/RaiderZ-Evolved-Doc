#pragma once

#include "../include/ADL/PMSCommon.h"
#include "../include/ADL/PMSControl.h"
#include <winsvc.h>

class GSControler : public IXObject
{
	IMPLEMENT_TISAFEREFCNT(GSControler)
public:
	GSControler(void);
	~GSControler(void);

	STDMETHOD_(void, OnSignal) (HSIGNAL hSig, WPARAM wParam, LPARAM lParam);

	int StartGameServer();
	int ExecuteGameServer(tstring strGSID);
	int ShutDownGameServer(tstring strGSID);

	int ExecuteScript(tstring strGSID);
	int ShutDownScript(tstring strGSID);

	BOOL GSIControl(PMSControlReq & msg);
	BOOL GameServiceControl(int nCommandType,LPCTSTR lpServiceName,LPCTSTR *lpArgu);
	BOOL GetGSInfo();
	BOOL GetGSIStatus(DWORD dwGSID);

};

extern GSControler theGSControler;	// global function���� �ٲܰ�.. jsp