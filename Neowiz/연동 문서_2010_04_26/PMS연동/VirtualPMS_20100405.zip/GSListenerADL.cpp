
#include "stdafx.h"
#include "gslisteneradl.h"
#include "GSLinkManagerADL.h"

CGSListenerADL theGSListenerADL;
CGSListenerADL::CGSListenerADL(void)
{
}

CGSListenerADL::~CGSListenerADL(void)
{
}

BOOL CGSListenerADL::RunGSListenerADL(LONG lPort)
{	
	BOOL bRet = TBase::Create(lPort, NULL);
	if(!bRet)
	{
		theErr.LOG(1, _T("fail to inilize ADL listener"));
		return FALSE;
	}
	return bRet;
}

BOOL CGSListenerADL::OnError(CLink* pLink, long lEvent, int nErrorCode)
{
	theErr.LOG(1, _T("OnError from ADL listener : %d, %d"), pLink->GetHandle(), nErrorCode);
	return TRUE;
}

void CGSListenerADL::OnAccept(SOCKET hSocket,int nErrorCode,LPCSTR szAddr,LONG lPort)
{
  	if (hSocket == INVALID_SOCKET)
	{
		theErr.LOG(1,_T("[CGSListener] invalid socket  : %d\n"),1);
		return;
	}
	if (nErrorCode)
	{
		theErr.LOG(1,_T("[CGSListener] Accept Error ErrorCode  : %d\n"),nErrorCode);
		::closesocket(hSocket);
		return;
	}

	USES_CONVERSION;

	if(!theGSLinkManagerADL.AddADLClient(hSocket, szAddr))
		closesocket(hSocket);	
	
	char printbuf[256];
	sprintf(printbuf, "[ADL] connected listener..   %d, %d, %s, %d \n", hSocket, nErrorCode, szAddr, lPort);
	theErr.LOG(1, _T("%s"), A2T(printbuf));


}

