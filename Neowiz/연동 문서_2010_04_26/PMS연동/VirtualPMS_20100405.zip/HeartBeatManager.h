#pragma once
#include "common.h"

class CHeartBeatInfo 
{
public:
	LONG m_lTimeOutCount;

	CHeartBeatInfo(){}
	~CHeartBeatInfo()
	{
	}
//	int m_SEQ;
};
class CHBMgr : public IXObject
{
	IMPLEMENT_TISAFEREFCNT(CHBMgr)
	typedef IXObject TBase;
	typedef ArcMapT<DWORD, CHeartBeatInfo*> TMapHB;
public:
	STDMETHOD_(void, OnSignal) (HSIGNAL hSig, WPARAM wParam, LPARAM lParam);

public:
	CHBMgr(void);
	~CHBMgr(void);

public:
	BOOL Start();
	BOOL Stop();
	BOOL AddClient(DWORD dwGSID, CLink *pLink);
	void RemoveClient(DWORD dwGSID);

private:

	void CheckCount();
private:
	static int	m_TSEQ;
	GXSigTimer m_HBTimer;
	TMapHB m_mapHBTbl;
};

extern CHBMgr theHBManager;
