#include "stdafx.h"
#include ".\statisticmanager.h"
#include "ClientMgr.h"
#include "gslinkmanager.h"
#include "GSLinkManagerADL.h"
#include "GSControler.h"
#include "common.h"

CStMgr theStManager;

CStMgr::CStMgr(void)
{
}

CStMgr::~CStMgr(void)
{
	if(m_StatTimer.IsActive())
	{
		m_StatTimer.Deactivate();
		theErr.LOG2(1,_T("[STMANAGER] Destory Timer Deact\n"));
	}
}

BOOL CStMgr::Start()
{
	BOOL bRet=TRUE;
	bRet = bRet && m_StatTimer.Activate(GetThreadPool(), this, MG_DUETIME, MG_DUETIME+2000);
	return bRet;
}

BOOL CStMgr::AddClient(DWORD dwGSID)
{
	TLock lo(this);
	//PMSStatInfo *pItem = new PMSStatInfo;

	//m_mapStatInfo[strGSID] = pItem;
	//theErr.LOG(1,"[STMANAGER AddClient] GSID : %s\n",strGSID.c_str());
	return TRUE;
}

void CStMgr::RemoveClient(DWORD dwGSID)
{
	TLock lo(this);
	// �ش� GSID�� ã�Ƽ� ��� �����ؾ� ��.. jsp
	TMapStatTbl::iterator itr = m_mapStatTbl.begin();
	for(itr; itr != m_mapStatTbl.end(); )
	{
		PMSStatInfo * pInfo = itr->second;
		if(pInfo->m_unitID.m_dwGSID == dwGSID)
		{
			m_mapStatTbl.erase(itr++);
			delete pInfo;
			continue;
		}
		++itr;
	}
	TMapRegionTbl::iterator its = m_mapRegionTbl.begin();
	for(its; its != m_mapRegionTbl.end(); )
	{
		PMSRegionInfo * pInfo = its->second;
		if(pInfo->m_unitID.m_dwGSID == dwGSID)
		{
			m_mapRegionTbl.erase(its++);
			delete pInfo;
			continue;
		}
		++its;
	}
}

STDMETHODIMP_(void) CStMgr::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	TLock lo(this);
	if(hSig == (HSIGNAL)HASIGNAL_STATINFOREQ)
	{
		GatherStatDataReq();
	}
	else if(hSig == (HSIGNAL)HASIGNAL_UPDATE)
	{
		UpdateStatInfo(wParam, lParam);
	}
	else if(hSig == (HSIGNAL)HASIGNAL_DONOTCARE)
	{
		DoNotCare(wParam, lParam);
	}
	else if(m_StatTimer.IsHandle(hSig))
	{
		SendStatReqMsg();
	}
}

void CStMgr::UpdateStatInfo(WPARAM wParam, LPARAM lParam)
{	// record�� update���� , gather function���� summary.. 
	if(wParam)	// update stat info
	{
		GBuf buf((LPXBUF)wParam, FALSE);
		PMSStatInfo info;
		::BLoad(info, buf);

		PMSStatInfo * pItem = NULL;
		TMapStatTbl::iterator itr = m_mapStatTbl.find(info.m_unitID);
		if(itr == m_mapStatTbl.end())
		{
			pItem = new PMSStatInfo();
			*pItem = info;
			m_mapStatTbl.insert(PairT(pItem->m_unitID, pItem));
		}
		else 
		{
			pItem = itr->second;
			info.m_lTimeOutCount = 0;
			*pItem = info;
		}		
	}
	if(lParam)	// update region stat info
	{
		GBuf buf((LPXBUF)lParam, FALSE);
		PMSRegionInfo info;
		::BLoad(info, buf);

		PMSRegionInfo * pItem = NULL;
		TMapRegionTbl::iterator itr = m_mapRegionTbl.find(info.m_unitID);
//printf("CStMgr::UpdateStatInfo - info.m_unitID : %d\n", info.m_unitID.m_dwGSID);
//printf("CStMgr::UpdateStatInfo - info.m_vecRegion.size() : %d\n", info.m_vecRegion.size());

/*
		printf("value = ");
		ForEachElmt(vecRegionInfoT, info.m_vecRegion, it, jt)
		{
			printf("%d ", *it);
		}
		printf("\n");
*/

		if(itr == m_mapRegionTbl.end())
		{
			pItem = new PMSRegionInfo();
			*pItem = info;
			m_mapRegionTbl.insert(PairT2(pItem->m_unitID, pItem));
		}
		else 
		{
			pItem = itr->second;
			*pItem = info;
		}
	}
}

void CStMgr::DoNotCare(WPARAM wParam, LPARAM lParam)
{
	if(wParam)
	{
		GBuf buf((LPXBUF)wParam, FALSE);
		PMSStatInfo info;
		::BLoad(info, buf);

		PMSStatInfo * pItem = NULL;
		TMapStatTbl::iterator itr = m_mapStatTbl.find(info.m_unitID);
		if(itr == m_mapStatTbl.end())
		{
			pItem = new PMSStatInfo();
			m_mapStatTbl.insert(PairT(info.m_unitID, pItem));
		}
		else 
		{
			pItem = itr->second;
			pItem->m_lTimeOutCount = 0;
		}
	}

	if(lParam)
	{
		GBuf buf((LPXBUF)lParam, FALSE);
		PMSRegionInfo info;
		::BLoad(info, buf);

		PMSRegionInfo * pItem = NULL;
		TMapRegionTbl::iterator itr = m_mapRegionTbl.find(info.m_unitID);

		if(itr == m_mapRegionTbl.end())
		{
			pItem = new PMSRegionInfo();
			m_mapRegionTbl.insert(PairT2(info.m_unitID, pItem));
		}
		//else 
		//{
		//	pItem = itr->second;
		//	pItem->m_lTimeOutCount = 0;
		//}
	}
}

void CStMgr::SendStatReqMsg()
{
	if(theGSmanager.IsExistLink())
	{
		char sztemp[256]={0,};
		sprintf(sztemp,"STRE\r\n");
		GBuf buf((LPVOID)sztemp,strlen(sztemp)+1);

		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0,(LPARAM)lpXBuf);
		//CheckCount();
	}
	if(theGSLinkManagerADL.IsExistLink())
	{	//service statistics�� region statistics�� �и��� �޼����� ���ÿ� .. 
		PayloadGS pld(PayloadGS::msgPMSStatInfoReq_Tag);	// �޼��� �������.
		GBuf buf;
		::LStore(buf, pld);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf);

		PayloadGS pld2(PayloadGS::msgPMSRegionInfoReq_Tag, PMSARegionInfoReq());
		GBuf buf2;
		::LStore(buf2, pld2);
		LPXBUF lpXBuf2 = buf2.Detach();
		::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf2);
		//CheckCount();		
	}
}

void CStMgr::GatherStatDataReq()
{
	tstring sTime;
	::GetTimeFormat(sTime, 3);

	// statistics manager���� �ֱ������� update�� stat data�� MA�� ����..
	PMSMessage_MA pld(PMSMessage_MA::statisticsAns_Tag);
	pld.un.m_statisticsAns->m_lErr = S_OK;
	pld.un.m_statisticsAns->m_sUpdateTime = tstr2str(sTime);

	ForEachElmt(TMapStatTbl, m_mapStatTbl, it, jt)
	{
		PMSUnitID punit = it->first;
		PMSStatInfo * pInfo = it->second;

		// truewise : ��� ���� ���� (2005/11/05)
		TCHAR cGSID[128];
		_itot(punit.m_dwGSID, cGSID, 10);
		tstring sGSID = cGSID;
		GSINFO *gs = theGSSessionTable.FindServer(sGSID);

		PMSUnitStatistics stat_info;

		if ((gs) && (gs->m_lState != GS_STOP))
		{
			stat_info.m_unitID = pInfo->m_unitID;
			stat_info.m_dwChannelCnt = pInfo->m_dwChannelCnt;
			stat_info.m_dwCU = pInfo->m_dwCU;
			stat_info.m_dwRoomCnt = pInfo->m_dwRoomCnt;
			stat_info.m_dwSession = pInfo->m_dwSession;
		}
		// ���� MA����
		pld.un.m_statisticsAns->m_vUnitStat.push_back(stat_info);
	}
	ForEachElmt(TMapRegionTbl, m_mapRegionTbl, it, jt)
	{
		PMSUnitID punit = it->first;
		PMSRegionInfo * pInfo = it->second;

		TCHAR cGSID[128];
		_itot(punit.m_dwGSID, cGSID, 10);
		tstring sGSID = cGSID;
		GSINFO *gs = theGSSessionTable.FindServer(sGSID);

		PMSUnitRegionStatistics region_info;
		region_info.m_unitID = pInfo->m_unitID;

		if ((gs) && (gs->m_lState != GS_STOP))
			region_info.m_vUserStat.assign(pInfo->m_vecRegion.begin(), pInfo->m_vecRegion.end());

		pld.un.m_statisticsAns->m_vRegionStat.push_back(region_info);
	}

	//theErr.LOG(1,"[HA->MA] ������ ���� ������ %d \n",pld.un.m_statisticsAns->m_vRegionStat.size());

	GBuf buf;
	::LStore(buf, pld);
	LPXBUF lpXBuf = buf.Detach();
	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_REQSENDTOMA, 0, (LPARAM)lpXBuf);
}

void CStMgr::CheckCount()
{
	tstring strTime, strCU, strTemp;
	PMSFaultInfo pmsFaultInfo;

	ForEachElmt(TMapStatTbl, m_mapStatTbl, it, jt)
	{
		// ���� GSI�� ���°� Run �� ���°� �ƴϸ� HeartBeat�� ������ �ʴ´�.
		if (!theGSControler.GetGSIStatus(it->first.m_dwGSID))
		{
			continue;
		}

		PMSStatInfo *pStat = it->second;
		pStat->m_lTimeOutCount++;

		LONG lLevel = 0L;
		if( (pStat->m_lTimeOutCount >=5 ) && (pStat->m_lTimeOutCount <= 7 ) )
			lLevel = FL_ALERT;
		else if(pStat->m_lTimeOutCount >= 8)
			lLevel = FL_CRITICAL;
		else 
			continue;
		
		GetTimeFormat(strTime,3);

		pmsFaultInfo.m_lGSState = GS_START;
		pmsFaultInfo.m_lLevel = lLevel;
		pmsFaultInfo.m_lReason = FT_GSIDELAYHB;
		pmsFaultInfo.m_dwGSID = it->first.m_dwGSID;
		pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
		pmsFaultInfo.m_sReason = "STATISC ANS DELAY";
		pmsFaultInfo.m_sDesc = "STATISC ANS DELAY";
		pmsFaultInfo.m_sProc = "STOP";
		pmsFaultInfo.m_sTime = tstr2str(strTime);
		pmsFaultInfo.m_sSSN = "";

		GBuf buf;
		::BStore(buf, pmsFaultInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(),&theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, 0,(LPARAM)lpXBuf);
		theErr.LOG(1,_T("[STMANAGER] ##### GSID : %d FAULT Count %d ##### \n"), it->first.m_dwGSID, pStat->m_lTimeOutCount);

		pmsFaultInfo.Clear();
	}//FOR
}

BOOL CStMgr::CalcStatistic(tstring strsour,tstring &strCU)
{
	tstring strGE;
	int nGE[2]={0};
//	int nAG[7]={0};
//	int nRE[17]={0};	
	TCHAR szCU[30]={0};

//	theErr.LOG(1,"[STMANAGER] CUNAME %s\n",strsour.c_str());

	for(int i =0; i< 17; i++)
	{
		for(int j=0; j< 7 ; j++)
		{
			for(int k =0;k <2; k++)
			{
				GetString(strsour,strGE,'%');
				nGE[k]+=_tstoi(strGE.c_str());
			}
//			GetString(strsour,strAG,'%');
//			nAG[j] += atoi(strAG.c_str());			
		}
//		GetString(strsour,strRE,'%');
//		nRE[i]= atoi(strRE.c_str());		
	}
	_stprintf(szCU,_T("%d"),nGE[0]+nGE[1]);
	strCU.assign(szCU);

//	theErr.LOG(1,"[STMANAGER] TOT CU %s\n",szCU);

	return TRUE;
}

