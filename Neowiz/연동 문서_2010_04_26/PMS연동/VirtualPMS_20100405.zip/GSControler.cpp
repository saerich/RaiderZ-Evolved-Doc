#include "stdafx.h"
#include "GSControler.h"
#include "Common.h"
#include "ClientMgr.h"
#include "../include/ADL/PMSCommon.h"


GSControler theGSControler;	 // global function���� �ٲܰ�.. jsp

GSControler::GSControler(void)
{
}

GSControler::~GSControler(void)
{
}

void GSControler::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	if(hSig == (HSIGNAL)HASIGNAL_CONTROLREQ)
	{
//		TLock lo(this);
		LPXBUF lpXBuf = (LPXBUF) lParam;
		GBuf buf(lpXBuf, FALSE);

		PMSControlReq msg;
		::BLoad(msg, buf);

		GSIControl(msg);
	}
	else if(hSig == 0)

	{
		return;
	}

}

int GSControler::StartGameServer()
{	
	return CE_SUCCESS;
}

int GSControler::ExecuteScript(tstring strGSID)
{
	int nRet = 0;
	GSINFO *gs = theGSSessionTable.FindServer(strGSID);
	if(!gs)
		return FALSE;

	tstring strExecuteName = ::format(_T("%s%s"),gs->m_infoMap[_T("EXEPATH")].c_str(), gs->m_infoMap[_T("EXETITLE")].c_str());

	tstring strParameter = ::format(_T("%s /GSID:%s /HAIP:%s /HAPORT:%s /CNFGFILE:%s"), gs->m_infoMap[_T("STARTMETHOD")].c_str(), 
	strGSID.c_str(),theGSInfoTable.GetHAIP().c_str(),theGSInfoTable.GetHAPort().c_str(),gs->m_infoMap[_T("CFGNAME")].c_str());
	tstring sExeParam = strExecuteName + tstring(_T(" ")) + strParameter;
	
	//theErr.LOG(1,_T("[ExecuteScript] EXE NAME  : %s\n"),strExecuteName.c_str());
	//theErr.LOG(1,_T("[ExecuteScript] Parameter : %s\n"),strParameter.c_str());
	//TLOG1("ExeParam : %s", sExeParam.c_str());
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);
	ZeroMemory( &pi, sizeof(pi) );

	if(_tstoi(gs->m_infoMap[_T("STATUS")].c_str()))
	{
		//if(!CreateProcess(strExecuteName.c_str(),const_cast<char*>(strParameter.c_str()),NULL,NULL,FALSE,CREATE_NEW_CONSOLE,NULL,NULL,&si,&pi))
		if(!CreateProcess(NULL , (LPWSTR)sExeParam.c_str(), NULL,NULL,FALSE,CREATE_NEW_CONSOLE,NULL,NULL,&si,&pi))
		{
			nRet = GetLastError();
			theErr.LOG(1,_T("[ExecuteScript] GSI(%s) Create is Failed!\n"),strGSID.c_str());
			strExecuteName.clear();
			nRet = CE_UNKNOWN;
		}
		else
		{
			theErr.LOG(1,_T("[ExecuteScript] GSI(%s) Create is Success!\n"),strGSID.c_str());
			strExecuteName.clear();
			gs->m_handle = pi.hProcess;
			CloseHandle(pi.hThread);
			CloseHandle(gs->m_handle);
			nRet = CE_SUCCESS;
		}
	}
	return nRet;

}
BOOL GSControler::ExecuteGameServer(tstring strGSID)
{
	int nRet = 0;
	GSINFO *gs = theGSSessionTable.FindServer(strGSID);
	VALIDATE(gs);

	tstring strExecuteName = gs->m_infoMap[_T("EXEPATH")] + gs->m_infoMap[_T("EXETITLE")] + _T(".exe");

	tstring strParameter =  
	::format(_T(" /GSID:%s /HAIP:%s /HAPORT:%s /CNFGFILE:%s"), \
	strGSID.c_str(),theGSInfoTable.GetHAIP().c_str(),theGSInfoTable.GetHAPort().c_str(),gs->m_infoMap[_T("CFGNAME")].c_str());
	
	theErr.LOG(1,_T("execute game server EXE NAME : %s\n"),strExecuteName.c_str());
	theErr.LOG(1,_T("execute game server Param NAME : %s\n"),strParameter.c_str());

	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);
	ZeroMemory( &pi, sizeof(pi) );

	if(_tstoi(gs->m_infoMap[_T("STATUS")].c_str()))
	{
		if(!CreateProcess(strExecuteName.c_str(), (LPWSTR)strParameter.c_str(),NULL,NULL,FALSE,CREATE_NEW_CONSOLE,NULL,NULL,&si,&pi))
		{
			nRet = GetLastError();
			strExecuteName.clear();
			nRet = CE_UNKNOWN;
		}
		else
		{
			strExecuteName.clear();
			gs->m_handle = pi.hProcess;
			nRet = CE_SUCCESS;
		}
	}
	return nRet;
}
int GSControler::ShutDownScript(tstring strGSID)
{
	int nRet = 0;
	GSINFO *gs = theGSSessionTable.FindServer(strGSID);
	VALIDATE(gs);

	tstring strExecuteName = ::format(_T("%s%s"),gs->m_infoMap[_T("EXEPATH")].c_str(), gs->m_infoMap[_T("EXETITLE")].c_str());

	tstring strParameter =  gs->m_infoMap[_T("KILLMEHTOD")];
	tstring sExeParam = strExecuteName + tstring(_T(" ")) + strParameter;
	
	//theErr.LOG(1,_T("[ExecuteScript] EXE NAME  : %s\n"),strExecuteName.c_str());
	//theErr.LOG(1,_T("[ExecuteScript] Parameter : %s\n"),strParameter.c_str());
	//TLOG1("ExeParam : %s", sExeParam.c_str());

	theErr.LOG(1,_T("shut down script EXE NAME : %s\n"),strExecuteName.c_str());

	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);
	ZeroMemory( &pi, sizeof(pi) );

	if(_tstoi(gs->m_infoMap[_T("STATUS")].c_str()))
	{
		if(!CreateProcess(NULL, (LPWSTR)sExeParam.c_str(),NULL,NULL,FALSE,CREATE_NEW_CONSOLE,NULL,NULL,&si,&pi))
		{
			nRet = GetLastError();
			strExecuteName.clear();
			nRet = CE_UNKNOWN;
		}
		else
		{
			strExecuteName.clear();
			gs->m_handle = pi.hProcess;
			nRet = CE_SUCCESS;
		}
	}
	return nRet;
}

int GSControler::ShutDownGameServer(tstring strGSID)
{

	BOOL bRet = TRUE;
	int nRet;
	GSINFO *gs = theGSSessionTable.FindServer(strGSID);
	VALIDATE(gs);

	bRet = TerminateProcess(gs->m_handle,0);
	gs->m_lState = GS_STOP;


	if(bRet)
	{
		nRet = CE_SUCCESS;
		gs->m_lState = GS_STOP;
		CloseHandle(gs->m_handle);
		gs->m_handle = NULL;

	}
	else
		nRet = CE_UNKNOWN;
	
	return nRet;
}

BOOL GSControler::GSIControl(PMSControlReq & msg)
{
	LONG nRet = CE_SUCCESS;
	tstring strGSID; 
	TCHAR temp_gsid[10] = {0, };
	_itot(msg.m_dwTargetID, temp_gsid, 10);
	strGSID = tstring(temp_gsid);

	GSINFO *gs = theGSSessionTable.FindServer(strGSID);
	if(!gs)
	{
		theErr.LOG(1, _T("Requested Ctl message to not exit server : %d\n"), msg.m_dwTargetID);
		return FALSE;
	}

	int exetype = _tstoi(gs->m_infoMap[_T("EXECUTEKIND")].c_str());//0 is Exe File

	tstring strTitle = gs->m_infoMap[_T("EXETITLE")].c_str();
	BOOL bIsStart = _tstoi(gs->m_infoMap[_T("STATUS")].c_str());

	// make arguments list for starting service.. 

	TCHAR *pArguValue[5];
	tstring _gsid = _T("/GSID:") + strGSID;
	pArguValue[0] = new TCHAR[_gsid.length() + 1];
	_tcscpy(pArguValue[0], _gsid.c_str());
	tstring _haip = _T("/HAIP:") + theGSInfoTable.GetHAIP();
	pArguValue[1] = new TCHAR[_haip.length() + 1];
	_tcscpy(pArguValue[1], _haip.c_str());
	tstring _haport = _T("/HAPORT:") + theGSInfoTable.GetHAPort();
	pArguValue[2] = new TCHAR[_haport.length() + 1];
	_tcscpy(pArguValue[2], _haport.c_str());
	tstring _cnfgfile = _T("/CNFGFILE:") + gs->m_infoMap[_T("CFGNAME")];
	pArguValue[3] = new TCHAR[_cnfgfile.length() + 1];
	_tcscpy(pArguValue[3], _cnfgfile.c_str());
	tstring _lastargu = _T(" ");	// why ???
	pArguValue[4] = new TCHAR[_lastargu.length() + 1];
	_tcscpy(pArguValue[4], _lastargu.c_str());

	LONG lErrCode = 0L;
	switch(msg.m_lCtrType)
	{
	case CT_GSISTART:
		theErr.LOG(1,_T("[GSILINKMANAGER] CT_GSISTART\n"));
		//Exe or Service Type or script
		// 2004-01-02 exetype�� 2�ϰ�� ��ũ��Ʈ�� ���� ��Ű�� �κ� �߰�
		if (bIsStart) // ���� ���� �ʵ��� �����Ǿ� ������ GSI�� ���� �Ǹ� �ȵȴ�.
		{		
			if (exetype == 2)
			{
				theErr.LOG(1, _T("[GSIControl] ExecuteScript : EXE TYPE : %d\n"), exetype);
				lErrCode = ExecuteScript(strGSID);
			}
			else if(!exetype)
			{
				theErr.LOG(1, _T("[GSIControl] ExecuteGameServer : EXE TYPE : %d\n"), exetype);
				lErrCode = ExecuteGameServer(strGSID);
			}
			else
			{
				theErr.LOG(1, _T("[GSIControl] GameServiceControl : EXE TYPE : %d\n"), exetype);

				lErrCode = GameServiceControl(SERVICE_START, strTitle.c_str(), (LPCTSTR*)pArguValue);
			}
		}
		break; // status�� 1�� �ƴϸ� ���� �ߴٴ� ������ ���� �ʿ䰡 ����.
	case CT_GSISHUTDOWN:
		{
			theErr.LOG(1,_T("[GSILINKMANAGER] CT_GSISHUTDOWN\n"));
			// 2004-01-02 exetype�� 2�ϰ�� ��ũ��Ʈ�� ���� ��Ű�� �κ� �߰�
			LONG lOldGameServerState = gs->m_lState;
			gs->m_lState = GS_STOP;
			if (exetype == 2)
				ShutDownScript(strGSID);
			else if(!exetype)
				lErrCode = ShutDownGameServer(strGSID);
			else
				lErrCode = GameServiceControl(SERVICE_STOP,strTitle.c_str(),NULL);
			if(nRet != CE_SUCCESS)
				gs->m_lState = lOldGameServerState;
		}
		break;
	case CT_GSIRESTART:		
		theErr.LOG(1,_T("[GSILINKMANAGER] CT_GSIRESTART\n"));
		// 2004-01-02 exetype�� 2�ϰ�� ��ũ��Ʈ�� ���� ��Ű�� �κ� �߰�
		if (exetype == 2)
		{
			LONG lOldGameServerState = gs->m_lState;
			gs->m_lState = GS_STOP;

			lErrCode = ShutDownScript(strGSID);
			if(lErrCode != CE_SUCCESS)
			{
				gs->m_lState = lOldGameServerState;	
				break;
			}
			Sleep(1500);
			if (bIsStart) // ���� ���� �ʵ��� �����Ǿ� ������ GSI�� ���� �Ǹ� �ȵȴ�.
				lErrCode = ExecuteScript(strGSID);
			break; // status�� 1�� �ƴϸ� ���� �ߴٴ� ������ ���� �ʿ䰡 ����.
		}
		else if(!exetype)
		{
			LONG lOldGameServerState = gs->m_lState;
			gs->m_lState = GS_STOP;

			lErrCode = ShutDownGameServer(strGSID);
			if(nRet!=CE_SUCCESS)
			{
				gs->m_lState = lOldGameServerState;
			}
			if (bIsStart) // ���� ���� �ʵ��� �����Ǿ� ������ GSI�� ���� �Ǹ� �ȵȴ�.
				lErrCode = ExecuteGameServer(strGSID);
			break; 
		}
		else
		{
			LONG lOldGameServerState = gs->m_lState;
			gs->m_lState = GS_STOP;
			lErrCode = GameServiceControl(SERVICE_STOP,strTitle.c_str(),NULL);

			if(nRet!=CE_SUCCESS)
			{
				gs->m_lState = lOldGameServerState;
				break;
			}
			Sleep(1000);
			if (bIsStart) // ���� ���� �ʵ��� �����Ǿ� ������ GSI�� ���� �Ǹ� �ȵȴ�.
				lErrCode = GameServiceControl(SERVICE_START, strTitle.c_str(), (LPCTSTR*)pArguValue);
			break; // status�� 1�� �ƴϸ� ���� �ߴٴ� ������ ���� �ʿ䰡 ����.
		}
		break;
	default:
		break;
	}
	
	long lCnt = 5L;
	while(lCnt > 0)
	{
		delete [] pArguValue[--lCnt];
	}
	if(!bIsStart)	// ���� �޽��� ���� ���� �ʿ䰡 ����??? jsp
		return TRUE;	

	tstring sAnsTime;
	GetTimeFormat(sAnsTime, 3);

	PMSMessage_MA pld(PMSMessage_MA::controlAns_Tag);
	pld.un.m_controlAns->m_dwMCID = msg.m_dwMCID;
	pld.un.m_controlAns->m_dwTargetID = msg.m_dwTargetID;
	pld.un.m_controlAns->m_lCtrType = msg.m_lCtrType;
	pld.un.m_controlAns->m_lErr = lErrCode;
	pld.un.m_controlAns->m_lFaultID = msg.m_lFaultID;
	pld.un.m_controlAns->m_sAnsTime = tstr2str(sAnsTime);
	pld.un.m_controlAns->m_sReqTime = msg.m_sReqTime;
	pld.un.m_controlAns->m_sUserID = msg.m_sUserID;

	GBuf buf;
	::LStore(buf, pld);
	LPXBUF lpXBuf = buf.Detach();	
	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_REQSENDTOMA, 0, (LPARAM)lpXBuf);
	return nRet;
}

BOOL GSControler::GameServiceControl(int nCommandType,LPCTSTR lpServiceName,LPCTSTR * lpArgu)
{
	int nRet = CE_UNKNOWN;

	SERVICE_STATUS ssStatus; 
	memset(&ssStatus, '\0', sizeof(SERVICE_STATUS)); // must 

    DWORD dwOldCheckPoint = 0; 
    DWORD dwStartTickCount = 0;
    DWORD dwWaitTime = 0;
	
	SC_HANDLE schSCManager = NULL;
	SC_HANDLE schService = NULL;

	int nCheckStatus = ( ( nCommandType == SERVICE_START ) ? SERVICE_START_PENDING : SERVICE_STOP_PENDING ) ;
	// by grayo test 2004-02-03 ���� ������ ���������� �ȵǾ����� .. result�� SERVICE_RUNNING�� �´°� ����
//	int nResultStatus = ( ( nCommandType == SERVICE_START) ? SERVICE_START_PENDING : SERVICE_STOPPED ) ;
	int nResultStatus = ( ( nCommandType == SERVICE_START) ? SERVICE_RUNNING : SERVICE_STOPPED ) ;

	__try
	{
		schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		if (!schSCManager ) 
		{
			theErr.LOG(1,_T("[CGSLINKMANAGER] ##### OpenSCManager Fail Error Code (%d) #####\n"),GetLastError()); 
			__leave; 
		}
		schService = OpenService(schSCManager, lpServiceName, SERVICE_ALL_ACCESS); 
	
		if (!schService) 
		{ 
			theErr.LOG(1,_T("[CGSLINKMANAGER] ##### OpenService Fail Error Code [%d] Servivce Name %s #####\n"), GetLastError(),lpServiceName); 
			__leave; 
		}

		if ( nCommandType == SERVICE_START )
		{
//	CE_SUCCESS = 0,	���� ����	CE_UNKNOWN = 1, �� �� ���� ����	CE_INVALIDLEVLE = 2, �������� ����� ����
//	CE_INVALIDID = 3,����� ã�� �� ����CE_PROCESSING = 4	

			theErr.LOG(1,_T("[CGSLINKMANAGER] SERVICE START\n"));
			for(int ar =0 ;ar< 4; ar++)
			{
				theErr.LOG(1,_T("[CGSLINKMANAGER] ARGUMENT %s\n"),lpArgu[ar]);
			}

			
			if (!StartService(schService, 4, lpArgu))      // number of arguments, no arguments 
			{
				int nErr = GetLastError();
				switch(nErr)
				{
				case ERROR_ACCESS_DENIED:
					nRet = CE_INVALIDLEVEL;
					break;
				case ERROR_PATH_NOT_FOUND:
					nRet = CE_INVALIDID;
					break;
				case ERROR_SERVICE_ALREADY_RUNNING:
					theErr.LOG(1,_T("[CGSLINKMANAGER] ##### StartService ALREADY RUN #####\n")); 
					nRet = CE_PROCESSING;
					break;
				default:
					nRet = CE_UNKNOWN;
				}
				theErr.LOG(1,_T("[CGSLINKMANAGER] ##### StartService Fail Error Code [%d] #####\n"), nErr); 
				__leave; 
			}
		}
		else if ( nCommandType == SERVICE_STOP )
		{
			theErr.LOG(1,_T("[CGSLINKMANAGER] SERVICE SPOT\n"));
			if (! ControlService( schService, SERVICE_CONTROL_STOP, &ssStatus) )
			{
				theErr.LOG(1,_T("[CGSLINKMANAGER] ##### ControlService Fail ServerName ##### \n ")); 
				__leave; 
			}
		}
		else
			__leave;			// reserved for pause/resume 

		// Check the status until the service is no longer start pending. 
		if (!QueryServiceStatus(schService, &ssStatus) )  
		{
			theErr.LOG(1,_T("[CGSLINKMANAGER] ##### QueryServiceStatus Fail Error Code [%d] ##### \n"), GetLastError()); 
			__leave;
		}

		// Save the tick count and initial checkpoint.
		dwStartTickCount = GetTickCount();
		dwOldCheckPoint = ssStatus.dwCheckPoint;
		
		
		theErr.LOG(1,_T("[CGSLINKMANAGER]  Control Service  NCHECKSTATUS %d CurrentState %d\n"), nCheckStatus , ssStatus.dwCurrentState); 
		dwWaitTime = 0;
		while (ssStatus.dwCurrentState == (DWORD)nCheckStatus) 
		{ 
			// Do not wait longer than the wait hint. A good interval is one tenth the wait hint, but no less than 1 second and no more than 10 seconds. 
			//dwWaitTime = ssStatus.dwWaitHint / 10;
			//if( dwWaitTime < 1000 )
			//{
			//	theErr.LOG(1,"[CGSLINKMANAGER]  Wait Short\n"); 
			//	dwWaitTime = 1000;
			//}
			//else if ( dwWaitTime > 6000 )
			//{
			//	theErr.LOG(1,"[CGSLINKMANAGER]  Wait Long\n"); 
			//	dwWaitTime = 6000;
			//}
			if (dwWaitTime > 180000)
			{
				theErr.LOG(1,_T("[CGSLINKMANAGER]  Wait Failed because of over time 180 second\n")); 
				break;
			}
			Sleep( 1000 );
			dwWaitTime += 1000;
			theErr.LOG(1,_T("[CGSLINKMANAGER]  Wait \n")); 
	
		
			if (!QueryServiceStatus( schService, &ssStatus) ) 
				break; 

			//if ( ssStatus.dwCheckPoint > dwOldCheckPoint )
			//{
			//	dwStartTickCount = GetTickCount();
			//	dwOldCheckPoint = ssStatus.dwCheckPoint;
			//}
			//else
			//{
			//	if(GetTickCount()-dwStartTickCount > ssStatus.dwWaitHint)
			//		break;
			//}
		}	
	}

	/*
#define SERVICE_STOPPED                        0x00000001
#define SERVICE_START_PENDING                  0x00000002
#define SERVICE_STOP_PENDING                   0x00000003
#define SERVICE_RUNNING                        0x00000004
#define SERVICE_CONTINUE_PENDING               0x00000005
#define SERVICE_PAUSE_PENDING                  0x00000006
#define SERVICE_PAUSED                         0x00000007

	*/
	__finally
	{
		if (ssStatus.dwCurrentState == (DWORD)nResultStatus)  // nResultStatus�� 0 �̸� �ȵ�
		{
			theErr.LOG(1,_T("[CGSLINKMANAGER]  Control Service SUCCESS: Service:%s, Command:%d RetStatus %d\n"), lpServiceName , nCommandType,nResultStatus); 
			nRet = CE_SUCCESS;
		}
		else 
		{
			theErr.LOG(1,_T("[CGSLINKMANAGER] ##### Control Service FAILED: Service:%s, Command:%d RetStatus %d CuuretStat %d#####\n"), lpServiceName , nCommandType,nResultStatus,ssStatus.dwCurrentState); 
		}

		if ( schService )
			CloseServiceHandle(schService); 
		if ( schSCManager )
			CloseServiceHandle(schSCManager);
	}	
	return nRet;
}

BOOL GSControler::GetGSIStatus(DWORD dwGSID)
{
	TCHAR _gsid[10] = {0, };
	_itot(dwGSID, _gsid, 10);
	tstring sGSID = _gsid;
	GSINFO * pgsInfo = theGSSessionTable.FindServer(sGSID);
	if(pgsInfo)
		if(pgsInfo->m_lState == GS_START)
			return TRUE;
	return FALSE;
}
