// Log.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
//#include <GService.h>

void __cdecl glog(LPCTSTR fmt,...)
{
	TCHAR buf[1024];
	va_list vl;
	va_start(vl, fmt);
	_vsntprintf(buf, 255, fmt, vl);
	buf[255] = 0;
	va_end(vl);

#ifdef _DEBUG
	OutputDebugString(buf);
	_ftprintf(stderr, buf);
#endif
}
 
void __cdecl tlog(LPCTSTR fmt,...)
{
	TCHAR buf[256];
	va_list vl;
	va_start(vl, fmt);
	_vsntprintf(buf, 255, fmt, vl);
	buf[255] = 0;
	va_end(vl);
#ifdef _DEBUG
	OutputDebugString(buf);
#endif
#ifdef _DEBUG_VERBOSE
	_ftprintf(stderr, buf);
#endif
}

void __cdecl svclog(LPCTSTR fmt,...)
{
	TCHAR buf[256];
	va_list vl;
	va_start(vl, fmt);
	_vsntprintf(buf, 255, fmt, vl);
	buf[255] = 0;
	va_end(vl);

#ifdef _DEBUG
	OutputDebugString(buf);
#endif
	//GetCurrentService()->LogEvent(buf);
}

