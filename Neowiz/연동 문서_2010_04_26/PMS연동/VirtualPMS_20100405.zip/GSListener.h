#ifndef __GSLISTNER_H
#define __GSLISTNER_H
#include "link.h"

class CGSListener : public GXListener
{
	IMPLEMENT_TISAFEREFCNT(CGSListener)
public:
	typedef GXListener TBase;

private:
	//CGSListener(const CGSListener&rhs);

public:
	CGSListener();
	virtual ~CGSListener();

	BOOL RunGSListener(LONG lPort);

protected:
	virtual BOOL OnError(CLink* pSocket, long lEvent, int nErrorCode);
	virtual void OnAccept(SOCKET hSocket,int nErrorCode,LPCSTR szAddr,LONG lPort);
private:

};

extern CGSListener theGSListener;
#endif