#ifndef __CLIENTMANAGER_H
#define __CLIENTMANAGER_H

#include <GXLinkUtl.h>
#include "../include/ADL/PMS_HA.h"
#include "../include/ADL/PMS_MA.h"
#include "../include/ADL/PMS_GS.h"
#include "Link.h"

#define HOSTNAMELEN 30
#define ANSWAITTIME 20000

#define INTERVAL 20000

#define MA_RECONNECT 1
enum {
	GSI_FAULT_NTF = 101,
	GSI_START_NTF,
	GSI_GAMESTATUS,
	GSI_HEALTYCHEKC_ANS,

	GSI_HEALTH_THREATEN_EVENT = 200,
};

class GSINFO;

//class CClientManager : public XLinkAdlManagerT<CLink,PMSPayload_HA>
class CClientManager : public XLinkAdlSingleT<CLink,PMSPayload_HA>
{
	IMPLEMENT_TISAFEREFCNT(CClientManager)
public:
//	typedef XLinkAdlManagerT<CLink, PMSPayload_HA> TBase;
	typedef XLinkAdlSingleT<CLink, PMSPayload_HA> TBase;
	typedef PMSPayload_HA TMsg;

	CClientManager();
	virtual ~CClientManager();

protected:
    STDMETHOD_(void, OnSignal)(HSIGNAL hSignal, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnRcvMsg(CLink* pLink, PMSPayload_HA& msg);
	virtual BOOL OnError(CLink* pSocket, long lEvent, int nErrorCode);

public:
	BOOL InitCliManager();
	BOOL SendData();

protected:
	// HA�� �޴� �޽���
	void OnRcvHARegisterAns(PMSHARegisterAns & msg);
	void OnRcvAnnounceReq(PMSAnnounceReq &msg);
	void OnRcvControlReq(PMSControlReq & msg);
	void OnRcvOrderReq(PMSOrderReq & msg);
	void OnRcvPerformanceReq(PMSPerformanceReq & msg);
	void OnRcvStatisticsReq(PMSStatisticsReq & msg);
	void OnRcvHeartBeatReq(PMSHeartBeatReq &pmsg);

	// HA�� ���� �޽���
	void SendStartedServerNtf();
	void SendGSStartNtf(LPARAM lParam);
	void SendFaultNtf(PMSFaultInfo &info);
	BOOL SendEventNtf();
	void SendHARegisterReq();
	BOOL SendGameStatusAns();

	void TreatGSFault(PMSFaultInfo & pmsFaultInfo);
	void TreatGSWarningNtf(PMSFaultInfo & info);

private:
	void _SendGSStartNtf(PMSStartupInfo & startInfo);
	int InsertFaultLog();
	void TLOGAlive();
	BOOL GameStatusTNtf(tstring str);

	BOOL MAConnect();
	BOOL ReadHAConfigFile();
	void SendToMA(GBuf &buf)
	{
		if(m_bConnect)
			m_pLink->DoSend(buf);
	}

private:

	GXSigTimer m_ConnectTimer;
	GXSigTimer m_Timer;
	CLink* m_pLink;
	BOOL m_bConnect;
};

extern CClientManager theManagerCli;
#endif
