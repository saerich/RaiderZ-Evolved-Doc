
#include "stdafx.h"
#include "GSLinkManagerADL.h"
#include "common.h"
#include "ClientMgr.h"
#include "PerformanceManager.h"
#include "statisticmanager.h"
#include "ConfigInfo.h"

#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

CGSLinkManagerADL theGSLinkManagerADL;

CGSLinkManagerADL::CGSLinkManagerADL()
{
}

CGSLinkManagerADL::~CGSLinkManagerADL()
{

}

BOOL CGSLinkManagerADL::OnError(CLink* pLink, long lEvent, int nErrorCode)
{
	if(!pLink) return FALSE;
	if(pLink->m_sSourceIP.length() > 100) return FALSE;

	int nIndex;
	tstring strGSID;
	GSINFO *pInfo = theGSSessionTable.FindServer(pLink, nIndex ,strGSID);
	if(pInfo) 
	{
		tstring strTime; 
		GetTimeFormat(strTime, 3);

		PMSFaultInfo pmsFaultInfo;
		pmsFaultInfo.m_lGSState = pInfo->m_lState;
		pmsFaultInfo.m_lLevel = FL_CRITICAL;
		pmsFaultInfo.m_lReason = FT_GSITERM;
		pmsFaultInfo.m_dwGSID = _tstol(strGSID.c_str());
		pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
		pmsFaultInfo.m_sReason = "GSI TERMINATED" ;
		pmsFaultInfo.m_sDesc = "GSI TERMINATED";
		pmsFaultInfo.m_sProc = "RESTRART";
		pmsFaultInfo.m_sTime = tstr2str(strTime);
		pmsFaultInfo.m_sSSN = "";// theGSInfoTable.GetSSN();

		GBuf buf;
		::BStore(buf, pmsFaultInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, (WPARAM)0, (LPARAM)lpXBuf);

		theHBManager.RemoveClient(pmsFaultInfo.m_dwGSID);
		thePfManager.RemoveClient(pmsFaultInfo.m_dwGSID);
		theStManager.RemoveClient(pmsFaultInfo.m_dwGSID);
		
		
		theErr.LOG(1,_T("[CGSLinkManagerADL OnError] From GSLinkManagerADL %d (%d) ErrorCode :%u\n"), pmsFaultInfo.m_dwGSID, pLink->GetHandle(), GetLastError());
		theGSSessionTable.ResetRecord(pmsFaultInfo.m_dwGSID);
	}
	theErr.LOG(1,_T("[CGSLinkManagerADL OnError] From GSLinkManagerADL  (%d) ErrorCode :%u\n"), pLink->GetHandle(), GetLastError());

	RemoveLink(pLink);
	pLink->Unregister();
	delete pLink; 
	pLink = NULL;

	return FALSE;
}

BOOL CGSLinkManagerADL::AddADLClient(SOCKET hSocket, LPCSTR sIP)
{
	TLock lo(this);

	CLink *pLink = new CLink(sIP);

	if(!pLink->Register(hSocket,this,HSIGNAL_XLINKHANDLER))
	{
		delete pLink;
		return FALSE;
	}
	
	if(!AddLink(pLink))
	{
		delete pLink;
		return FALSE;
	}

	theErr.LOG(1,_T("[ADL] GS ADL Link Count .. TOTAL GSI  : %d\n"), mLinkMap.size());
	printf("GS ADL Link Count .. TOTAL GSI  : %d\n", mLinkMap.size());
	return TRUE;
}

BOOL CGSLinkManagerADL::IsExistLink()
{
	return !mLinkMap.empty();
}

void CGSLinkManagerADL::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	TLock lo(this);
	if(hSig == (HSIGNAL)HASIGNAL_ANNOUNCEREQ)
	{
		TreatAnnounceMsg((LPVOID)lParam);
	}
	else if(hSig == (HSIGNAL)HASIGNAL_ORDERREQ)
	{
		TreatOrderMsg((LPVOID)lParam);
	}
	else if(hSig == (HSIGNAL)HASIGNAL_REQSENDTOGS)
	{
		LPXBUF lpXBuf = (LPXBUF)lParam;
		GBuf buf(lpXBuf, FALSE);
		ForEachElmt(TLinkMap, mLinkMap, it, jt)
		{
			CLink *p = (*it).second;
			ASSERT(p!=NULL);
			p->DoSend(buf);
		}		
	}
	else if(hSig == 0)
	{
	}
	else 
		TBase::OnSignal(hSig, wParam, lParam);
}

void CGSLinkManagerADL::TreatAnnounceMsg(LPVOID lpV)
{
	if(!IsExistLink()) return;
	LPXBUF lpXBuf = (LPXBUF)lpV;
	GBuf buf(lpXBuf, FALSE);
	PMSAnnounceReq msg;
	::BLoad(msg, buf);

	PayloadGS pld(PayloadGS::msgPMSAnnounceReq_Tag);
	pld.un.m_msgPMSAnnounceReq->m_pmsUnitID = msg.m_unitID;

	// Original 
	pld.un.m_msgPMSAnnounceReq->m_sMessage = wstr2str(msg.m_sAnnMsg);

/*
	// Japan
	char *strUnicode=NULL;
	int len = msg.m_sAnnMsg.length() * 2 + 1;
	strUnicode = new char[len];
	memcpy(strUnicode, msg.m_sAnnMsg.c_str(), len);
	pld.un.m_msgPMSAnnounceReq->m_sMessage.assign(strUnicode, len);

	//strUnicode = (char*)(void*)msg.m_sAnnMsg.c_str();
	//pld.un.m_msgPMSAnnounceReq->m_sMessage.assign(strUnicode, sizeof(strUnicode));
*/


	GBuf buf2;
	::LStore(buf2, pld);

	ForEachElmt(TLinkMap, mLinkMap, it, jt)
	{
		CLink *p = (*it).second;
		ASSERT(p!=NULL);
// by gryao 2005-06-15 
// ���� �޽����� �޾����� ������ ����� ��� GSI�� Broad Casting�� �� ��� ���� �޽����� ������ ���ư��� ������ �ִ�.
		if (msg.m_unitID.m_dwGSID != 0 && (LONG)msg.m_unitID.m_dwGSID != p->GetGSID())
			continue;
		
		if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Announce Message .. To : [ %s ]  Msg : [ %s ] \n"), str2tstr(p->m_sSourceIP).c_str(), msg.m_sAnnMsg.c_str());
		p->DoSend(buf2);
	}
}

void CGSLinkManagerADL::TreatOrderMsg(LPVOID lpV)
{
	// string base������ order�� �������� �ʾ���...
	GBuf buf((LPXBUF)lpV, FALSE);
	PMSOrderReq msg;
	::BLoad(msg, buf);

	PayloadGS pld(PayloadGS::msgPMSOrderReq_Tag);
	pld.un.m_msgPMSOrderReq->m_dwMCID = msg.m_dwMCID;
	pld.un.m_msgPMSOrderReq->m_lTargetRange = msg.m_lTargetRange;
	pld.un.m_msgPMSOrderReq->m_pmsUnitID = msg.m_unitID;
	pld.un.m_msgPMSOrderReq->m_sOrderName = msg.m_sOrderName;
	pld.un.m_msgPMSOrderReq->m_sOrderVal = msg.m_sOrderVal;
	pld.un.m_msgPMSOrderReq->m_sReqTime = msg.m_sReqTime;

	GBuf buf2;
	::LStore(buf, pld);
	ForEachElmt(TLinkMap, mLinkMap, it, jt)
	{
		CLink *p = (*it).second;
		ASSERT(p!=NULL);
// by gryao 2005-06-15 
// Order �޽����� �޾����� ������ ����� ��� GSI�� Broad Casting�� �� ��� ���� �޽����� ������ ���ư��� ������ �ִ�.
		if (msg.m_unitID.m_dwGSID != 0 &&  (LONG)msg.m_unitID.m_dwGSID != p->GetGSID())
			continue;


		if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Order Message .. To : [ %s ]  Msg : [ %s ] \n"), p->m_sSourceIP.c_str(), msg.m_sOrderName.c_str());
		p->DoSend(buf);
	}
}

BOOL CGSLinkManagerADL::OnRcvMsg(CLink* pLink, TMsg& msg)
{
	BOOL bRet = TRUE;
	switch(msg.mTagID)
	{
	case TMsg::msgPMSGSInitNtf_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSGSInitNtf_Tag]\n"));
		bRet = OnGSInitNtf(pLink, *msg.un.m_msgPMSGSInitNtf);
		break;
	case TMsg::msgPMSInitFaultNtf_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSInitFaultNtf_Tag]\n"));
		OnGSInitFaultNtf(pLink, *msg.un.m_msgPMSInitFaultNtf);
		break;
	case TMsg::msgPMSHeartBeatAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSHeartBeatAns_Tag]\n"));
		OnHeartBeatAns(*msg.un.m_msgPMSHeartBeatAns);
		break;
	case TMsg::msgPMSPerformAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSPerformAns_Tag]\n"));
		OnPerformAns(pLink, *msg.un.m_msgPMSPerformAns);
		break;
	case TMsg::msgPMSStatInfoAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSStatInfoAns_Tag]\n"));
		OnStatInfoAns(pLink, *msg.un.m_msgPMSStatInfoAns);
		break;
	case TMsg::msgPMSRegionInfoAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSRegionInfoAns_Tag]\n"));
		OnRegionInfoAns(*msg.un.m_msgPMSRegionInfoAns, pLink);
		break;
	case TMsg::msgPMSAnnounceAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSAnnounceAns_Tag]\n"));
		OnAnnounceAns(*msg.un.m_msgPMSAnnounceAns);
		break;
	case TMsg::msgPMSOrderAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSOrderAns_Tag]\n"));
		OnOrderAns(*msg.un.m_msgPMSOrderAns);
		break;
	case TMsg::msgPMSWarningNtf_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSWarningNtf_Tag]\n"));
		OnWarningNtf(*msg.un.m_msgPMSWarningNtf);
		break;
	case TMsg::msgPMSStatInfoPCAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSStatInfoPCAns_Tag]\n"));
		OnStatInfoPCAns(pLink, *msg.un.m_msgPMSStatInfoPCAns);
		break;
	case TMsg::msgPMSRegionInfoPCAns_Tag:
		if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0, _T("[OnRcvMsg::msgPMSRegionInfoPCAns_Tag]\n"));
		OnRegionInfoPCAns(*msg.un.m_msgPMSRegionInfoPCAns, pLink);
		break;
	default:
		theErr.LOG(1, _T("[OnRcvMsg ERROR] Unknown Tag message received from GSLinkManagerADL : %d \n"), msg.mTagID);
	};
	return TRUE;
}

BOOL CGSLinkManagerADL::OnGSInitNtf(CLink * pLink, PMSAGSInitNtf & msg)
{
	printf("ADL Recv GSInitNtf : %s \n", msg.m_sOptAddr.c_str());
	theErr.LOG(1, _T("[ADL] Recv GSInitNtf : %s \n"), str2tstr(msg.m_sOptAddr).c_str());
	GSINFO gsInfo;
	gsInfo.m_pLink = pLink;
	gsInfo.m_lState = GS_START;
	tstring sStartTime;
	GetTimeFormat(sStartTime, 3);
	gsInfo.m_infoMap[_T("TIME")] = sStartTime;
	TCHAR _gsid[10] = {0, };
	_itot(msg.m_dwGSID, _gsid, 10);
	tstring sGSID = _gsid;
	gsInfo.m_sOptAddr = str2tstr(msg.m_sOptAddr);
	gsInfo.m_sStartTime = sStartTime;
	
	if (msg.m_dwProcID)
	{
		gsInfo.m_dwProcessID = msg.m_dwProcID;
		gsInfo.m_handle = ::OpenProcess(PROCESS_ALL_ACCESS, FALSE, gsInfo.m_dwProcessID);
	}
	if(msg.m_dwGSID == 0)// || !theGSSessionTable.IsExist(msg.m_dwGSID))
	{
		tstring sOptAddr = str2tstr(msg.m_sOptAddr);
		//if(!SendToConfigInfo(pLink, str2tstr(msg.m_sOptAddr), sGSID))
		if(!SendToConfigInfo(pLink, sOptAddr, sGSID))
		{
			OnError(pLink, FD_READ, msg.m_dwErrCode);
			return FALSE;
		}
		msg.m_dwGSID = _tstol(sGSID.c_str());
	}
//	gsInfo.m_handle == 
	if(!theGSSessionTable.SetRecord(sGSID, gsInfo))
	{
		OnError(pLink, FD_READ, msg.m_dwErrCode);
		theErr.LOG(1,_T("[ADL] Error GSInitNtf ..  GSID %s\n"), sGSID.c_str());
		return FALSE;
	}
	if(msg.m_lVersion != ADL_VERSION)
	{
		OnError(pLink, FD_READ, msg.m_dwErrCode);
		theErr.LOG(1,_T("[ADL] Error GS Init Ntf .. mismatch ADL version  %d \n"), msg.m_lVersion);
		return FALSE;
	}

	PMSStartupInfo startInfo;
	startInfo.m_dwErrCode = msg.m_dwErrCode;
	startInfo.m_dwGSID = msg.m_dwGSID;
	startInfo.m_dwProcID = msg.m_dwProcID;
	startInfo.m_sOptAddr = msg.m_sOptAddr;
	startInfo.m_sStartTime = tstr2str(sStartTime);
	startInfo.m_vecNSAP = msg.m_vecNSAP;
	GBuf buf;
	::BStore(buf, startInfo);
	LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSISTARTNTF, 0, (LPARAM)lpXBuf);

	theHBManager.AddClient(msg.m_dwGSID, pLink);
	thePfManager.AddClient(msg.m_dwGSID, pLink);
	theStManager.AddClient(msg.m_dwGSID);

	pLink->SetGSID(msg.m_dwGSID);
	return TRUE;
}

BOOL CGSLinkManagerADL::SendToConfigInfo(CLink * pLink, tstring & sAppName, tstring & sGSID)
{
	theErr.LOG(1,_T("[ADL] SendToConfigInfo Isolate Start  GS : %s\n"), sAppName.c_str());
	// Send Order message for confing information setting.. : "__ISOLATE__"
	tstring _sGSID(_T(""));
	if(!theGSSessionTable.FindServer(sAppName, _sGSID))
		return FALSE;
	sGSID = _sGSID;

	PayloadGS pld(PayloadGS::msgPMSOrderReq_Tag);
	pld.un.m_msgPMSOrderReq->m_sOrderName = "__ISOLATE__";
	pld.un.m_msgPMSOrderReq->m_sOrderVal = tstr2str(sGSID);	// argument list ���� �����ϴ� ���� ���ǹ�.. 
	pld.un.m_msgPMSOrderReq->m_dwMCID = 0UL;
	pld.un.m_msgPMSOrderReq->m_lTargetRange = 0L;
	//pld.un.m_msgPMSOrderReq->m_sReqTime = ;
	//pld.un.m_msgPMSOrderReq->m_pmsUnitID  = ;
	GBuf buf;
	::LStore(buf, pld);
	pLink->DoSend(buf);
	return TRUE;
}

void CGSLinkManagerADL::OnGSInitFaultNtf(CLink * pLink, PMSAInitFaultNtf & msg)
{
	printf("ADL Recv GSInitFaultNtf : %d %d GSID,SSN \n", msg.m_unitID.m_dwGSID, msg.m_unitID.m_dwSSN);

	TCHAR gsid[100] = {0, };
	_itot(msg.m_unitID.m_dwGSID, gsid, 10);
	tstring sGSID(gsid);
	GSINFO *pinfo = theGSSessionTable.FindServer(sGSID);
	if(!pinfo)
	{
		theErr.LOG(1, _T("[CGSLinkManagerADL OnGSInitFaultNtf] Error Unknowm server..at GS Init fault notify : %s\n"), sGSID.c_str());
		return;	
	}
	TCHAR _ssn[10] = {0, };
	_itot(msg.m_unitID.m_dwSSN, _ssn, 10);
	tstring ssn = _ssn;
	tstring sTime; 
	GetTimeFormat(sTime, 3);

	PMSFaultInfo pmsFaultInfo;
	pmsFaultInfo.m_dwGSID = msg.m_unitID.m_dwGSID;
	pmsFaultInfo.m_lGSState = GS_START;
	pmsFaultInfo.m_sReason = "GSI INITFAULT";
	pmsFaultInfo.m_lLevel =  FL_CRITICAL;
	pmsFaultInfo.m_lReason = FT_GSDETAIL;
	pmsFaultInfo.m_sDesc = "GSI INITFAULT";
	pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
	pmsFaultInfo.m_sProc = "RESTRART";
	pmsFaultInfo.m_sSSN = tstr2str(ssn);
	pmsFaultInfo.m_sTime = tstr2str(sTime);

	GBuf buf;
	::BStore(buf, pmsFaultInfo);
	LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, (WPARAM)0, (LPARAM)lpXBuf);
	
	theErr.LOG(1,_T("[CGSLinkManagerADL OnGSInitFaultNtf] Error .. GS Init Fault.. GSID : %d SVR : %s\n"), msg.m_unitID.m_dwGSID, pinfo->m_pLink->m_sSourceIP.c_str());
}

void CGSLinkManagerADL::OnHeartBeatAns(PMSAHeartBeatAns & msg)
{
	printf("ADL Recv HeartBeatAns : %d \n", msg.m_dwGSID);
	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS HeartBeatAns GSID : %d \n"), msg.m_dwGSID);

	DWORD dwGSID = msg.m_dwGSID;

	::XsigQueueSignal(GetThreadPool(), &theHBManager, (HSIGNAL)HASIGNAL_HEARTBEATANS, 0, (LPARAM)dwGSID);
}

void CGSLinkManagerADL::OnAnnounceAns(PMSAAnnounceAns & msg)
{
	// �ǹ� ����.. 
	printf("ADL Recv AnnounceAns : %d \n", msg.m_dwGSID);

}

void CGSLinkManagerADL::OnOrderAns(PMSAOrderAns & msg)
{
	printf("ADL Recv OrderAns : %s , MCID [%d]\n", msg.m_sOrderName.c_str(), msg.m_dwMCID);
	if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0,_T("[ADL] Recived GS OrderAns \n"));

	if(msg.m_dwMCID == 0UL)
		return;
	tstring _shaid =  theGSInfoTable.GetHAID();
	tstring _sAnsTime;
	_sAnsTime = GetTimeFormat(_sAnsTime, 3);

	PMSMessage_MA pld(PMSMessage_MA::orderAns_Tag);
	pld.un.m_orderAns->m_dwHAID = _tstol(_shaid.c_str());
	pld.un.m_orderAns->m_dwMCID = msg.m_dwMCID;
	if(msg.m_sErrorMsg.length())
	{
		pld.un.m_orderAns->m_lErr = OE_GSIDETAIL;
		pld.un.m_orderAns->m_sErrDesc = msg.m_sErrorMsg;
	}
	else 
		pld.un.m_orderAns->m_lErr = OE_SUCCESS;
	pld.un.m_orderAns->m_lTargetRange = msg.m_lTargetRange;
	pld.un.m_orderAns->m_sAnsTime = tstr2str(_sAnsTime);
	pld.un.m_orderAns->m_sOrderName = msg.m_sOrderName;
	pld.un.m_orderAns->m_sOrderVal = msg.m_sOrderVal;
	pld.un.m_orderAns->m_sReqTime = msg.m_sReqTime;
	pld.un.m_orderAns->m_unitID = msg.m_pmsUnitID;

	GBuf buf;
	::LStore(buf, pld);
	LPXBUF lpXBuf = buf.Detach();
	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_REQSENDTOMA, (WPARAM)0, (LPARAM)lpXBuf);
}

void CGSLinkManagerADL::OnWarningNtf(PMSAWarningNtf & msg)
{
	printf("ADL Recv WarningNtf : %s \n", msg.m_sWarnMsg.c_str());
	if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(0,_T("[ADL] Recived GS OnWarningNtf \n"));

	tstring sTime; 
	GetTimeFormat(sTime, 3);
	TCHAR _ssn[10] = {0, };
	_itot(msg.m_unitID.m_dwSSN, _ssn, 10);
	tstring ssn(_ssn);

	PMSFaultInfo info;
	info.m_dwGSID = msg.m_unitID.m_dwGSID;
	info.m_lFaultID = 0L;
	info.m_lGSState = GS_START;
	info.m_lLevel = msg.m_lErrLevel;
	info.m_lReason = FT_GSDETAIL;
	info.m_sDesc = msg.m_sWarnMsg;
	info.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
	info.m_sProc = msg.m_sTreatMsg;
	info.m_sReason = "GSI DETAIL";
	info.m_sSSN = tstr2str(ssn);
	info.m_sTime = tstr2str(sTime);

	GBuf buf;
	::BStore(buf, info);
	LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_WARNINGNTF, 0, (LPARAM)lpXBuf);
}

void CGSLinkManagerADL::OnPerformAns(CLink * pLink, PMSAPerformAns & msg)
{
	printf("ADL Recv PerformAns : %d size \n", msg.m_vecPerform.size());
	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS PerformAns Size : %d \n"), msg.m_vecPerform.size());

	PMSPerformInfo info;
	LONG lSize = (LONG)msg.m_vecPerform.size();
	if(lSize)
	{
		info.m_dwGSID = pLink->GetGSID();

//theErr.LOG(1,"OnPerformAns - info.m_dwGSID : %d\n", info.m_dwGSID);

		tstring _sProcName(_T(""));
		theGSSessionTable.GetTitle(_sProcName, info.m_dwGSID);
		info.m_sPerfName = tstr2str(_sProcName);

//theErr.LOG(1,"OnPerformAns - info.m_sPerfName : %s\n", info.m_sPerfName.c_str());

		info.m_vecPerform.assign(msg.m_vecPerform.begin(), msg.m_vecPerform.end());

		tstring strBuff = _T("");
		TCHAR strTemp[8];

		for (int i=0; i<(int)info.m_vecPerform.size(); i++)
		{
			_itot(info.m_vecPerform[i], strTemp, 10);
			strBuff.append(strTemp);

			if (i < (int)info.m_vecPerform.size()-1)
				strBuff.append(_T(","));
		}

		GET_VIEW()->SetListItem(info.m_dwGSID, 1, 0, _T("�����ս�"), strBuff.c_str());

		GBuf buf;
		::BStore(buf, info);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &thePfManager, (HSIGNAL)HASIGNAL_UPDATE, 0, (LPARAM)lpXBuf);
	}
	else
	{
		info.m_dwGSID = pLink->GetGSID();
		tstring _sProcName(_T(""));
		theGSSessionTable.GetTitle(_sProcName, info.m_dwGSID);
		info.m_sPerfName = tstr2str(_sProcName);
		GBuf buf;
		::BStore(buf, info);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &thePfManager, (HSIGNAL)HASIGNAL_DONOTCARE, 0, (LPARAM)lpXBuf);
	}
}

void CGSLinkManagerADL::OnStatInfoAns(CLink * pLink, PMSAStatInfoAns & msg)
{
	printf("ADL Recv StatInfoAns : %d size \n", msg.m_vecStatBase.size());

	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS StatInfoAns Size : %d \n"), msg.m_vecStatBase.size());

	// truewise : ��� ���� ���� (2005/11/05)
	TCHAR cGSID[128];
	_itot(pLink->GetGSID(), cGSID, 10);
	tstring sGSID = cGSID;
	GSINFO *gs = theGSSessionTable.FindServer(sGSID);

	PMSStatInfo statInfo;
	LONG lSize = (LONG)msg.m_vecStatBase.size();
	if(lSize)
	{	// ���� ��� ��� GSID�� SSN�� 1:1�� ������ ���̶� ����.
		ForEachElmt(VecStatBaseT, msg.m_vecStatBase, it, jt)
		{
			if ((gs) && (gs->m_lState == GS_STOP))
			{
				statInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();

				tstring _upTime; 
				GetTimeFormat(_upTime, 3);
				statInfo.m_sUpTime = tstr2str(_upTime);

				GBuf buf;
				::BStore(buf, statInfo);
				LPXBUF lpXBuf = buf.Detach();
				::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, (WPARAM)lpXBuf, 0);
			}
			else
			{
				PMSStatBase & stat_base = *it;
				statInfo.m_unitID = stat_base.m_unitID;
				statInfo.m_dwChannelCnt = stat_base.m_dwChannelCnt;
				statInfo.m_dwCU = stat_base.m_dwCU;
				statInfo.m_dwRoomCnt = stat_base.m_dwRoomCnt;
				statInfo.m_dwSession = stat_base.m_dwSession;
				statInfo.m_sOptionInfo = stat_base.m_sOptionInfo;
				tstring _upTime;

				GetTimeFormat(_upTime, 3);
				statInfo.m_sUpTime = tstr2str(_upTime);

				TCHAR strBuff[1024];

				_stprintf(strBuff, _T("SSN:%d, Category:%d, GSID:%d, Channel:%d, CU:%d, Room:%d, Session:%d"), 
					statInfo.m_unitID.m_dwSSN, statInfo.m_unitID.m_dwCategory, statInfo.m_unitID.m_dwGSID,
					stat_base.m_dwChannelCnt, stat_base.m_dwCU, stat_base.m_dwRoomCnt, stat_base.m_dwSession);

				GET_VIEW()->SetListItem(pLink->GetGSID(), 1, 0, _T("����"), strBuff);

				GBuf buf;
				::BStore(buf, statInfo);
				LPXBUF lpXBuf = buf.Detach();
				::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, (WPARAM)lpXBuf, 0);
			}
		}
	}
	else
	{
		statInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();
		GBuf buf;
		::BStore(buf, statInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, (WPARAM)lpXBuf, 0);
	}
}

void CGSLinkManagerADL::OnStatInfoPCAns(CLink * pLink, PMSAStatInfoPCAns & msg)
{
	printf("ADL Recv StatInfoPCAns : %d size \n", msg.m_vecStatBase.size());

	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS StatInfoPCAns Size : %d \n"), msg.m_vecStatBase.size());

	// truewise : ��� ���� ���� (2005/11/05)
	TCHAR cGSID[128];
	_itot(pLink->GetGSID(), cGSID, 10);
	tstring sGSID = cGSID;
	GSINFO *gs = theGSSessionTable.FindServer(sGSID);

	PMSStatInfo statInfo;
	LONG lSize = (LONG)msg.m_vecStatBase.size();
	if(lSize)
	{	// ���� ��� ��� GSID�� SSN�� 1:1�� ������ ���̶� ����.
		ForEachElmt(VecStatBaseT, msg.m_vecStatBase, it, jt)
		{
			if ((gs) && (gs->m_lState == GS_STOP))
			{
				statInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();

				tstring _upTime; 
				GetTimeFormat(_upTime, 3);
				statInfo.m_sUpTime = tstr2str(_upTime);

				GBuf buf;
				::BStore(buf, statInfo);
				LPXBUF lpXBuf = buf.Detach();
				::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, (WPARAM)lpXBuf, 0);
			}
			else
			{
				PMSStatBase & stat_base = *it;
				statInfo.m_unitID = stat_base.m_unitID;
				statInfo.m_dwChannelCnt = stat_base.m_dwChannelCnt;
				statInfo.m_dwCU = stat_base.m_dwCU;
				statInfo.m_dwRoomCnt = stat_base.m_dwRoomCnt;
				statInfo.m_dwSession = stat_base.m_dwSession;
				statInfo.m_sOptionInfo = stat_base.m_sOptionInfo;
				tstring _upTime;

				GetTimeFormat(_upTime, 3);
				statInfo.m_sUpTime = tstr2str(_upTime);

				TCHAR strBuff[1024];

				_stprintf(strBuff, _T("SSN:%d, Category:%d, GSID:%d, Channel:%d, CU:%d, Room:%d, Session:%d"), 
					statInfo.m_unitID.m_dwSSN, statInfo.m_unitID.m_dwCategory, statInfo.m_unitID.m_dwGSID,
					stat_base.m_dwChannelCnt, stat_base.m_dwCU, stat_base.m_dwRoomCnt, stat_base.m_dwSession);

				GET_VIEW()->SetListItem(pLink->GetGSID(), 1, 0, _T("����(PC)"), strBuff);

				GBuf buf;
				::BStore(buf, statInfo);
				LPXBUF lpXBuf = buf.Detach();
				::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, (WPARAM)lpXBuf, 0);
			}
		}
	}
	else
	{
		statInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();
		GBuf buf;
		::BStore(buf, statInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, (WPARAM)lpXBuf, 0);
	}
}

void CGSLinkManagerADL::OnRegionInfoAns(PMSARegionInfoAns & msg, CLink * pLink)
{
//	printf("ADL Recv RegionInfoAns : %d size \n", msg.m_vecRegionInfo.size());

	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS RegionInfoAns Size : %d \n"), msg.m_vecRegionInfo.size());

	PMSRegionInfo regionInfo;
	LONG lSize = (LONG)msg.m_vecRegionInfo.size();
	if(lSize)
	{	// ���� ��� ��� GSID�� SSN�� 1:1�� ������ ���̶� ����.
		ForEachElmt(VecRegionInfo, msg.m_vecRegionInfo, it, jt)
		{
			PMSRegionInfo & region_base = *it;

			//regionInfo.m_unitID = region_base.m_unitID;
			//regionInfo.m_vecRegion.insert(region_base.m_vecRegion.begin(), region_base.m_vecRegion.end());
			//regionInfo.m_vecRegion.assign(region_base.m_vecRegion.begin(), region_base.m_vecRegion.end());

			tstring strBuff = _T("");
			TCHAR strTemp[8];

			int count = 0;
			for (LONG i = 0 ; i<(LONG)region_base.m_vecRegion.size() ; i++ )
			{
				//_itot(i, strTemp, 10);
				//strBuff.append(strTemp);
				//strBuff.append(_T("["));
				//_itot(region_base.m_vecRegion[i], strTemp, 10);
				//strBuff.append(strTemp);
				//if (i<(LONG)region_base.m_vecRegion.size()-1)
				//	strBuff.append(_T("],"));
				//else
				//	strBuff.append(_T("]"));

				_itot(region_base.m_vecRegion[i], strTemp, 10);
				strBuff.append(strTemp);
				if (i<(LONG)region_base.m_vecRegion.size()-1)
					strBuff.append(_T(","));

				count++;
			}			

			GET_VIEW()->SetListItem(pLink->GetGSID(), 1, count, _T("���"), strBuff.c_str());

			if (GET_VIEW()->GetAddStatisticsFlag() == TRUE)
				GET_VIEW()->AddStatisticsData(pLink->GetGSID(), (LONG)region_base.m_vecRegion.size(), strBuff.c_str());

			GBuf buf;
			//::BStore(buf, regionInfo);
			::BStore(buf, region_base);
			LPXBUF lpXBuf = buf.Detach();
			::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, 0, (LPARAM)lpXBuf);
		}	
	}
	else
	{
		regionInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();
		GBuf buf;
		::BStore(buf, regionInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, 0, (LPARAM)lpXBuf);
	}
}

void CGSLinkManagerADL::OnRegionInfoPCAns(PMSARegionInfoPCAns & msg, CLink * pLink)
{
//	printf("ADL Recv RegionInfoAns : %d size \n", msg.m_vecRegionInfo.size());

	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[ADL] Recived GS RegionInfoPCAns Size : %d \n"), msg.m_vecRegionInfo.size());

	PMSRegionInfo regionInfo;
	LONG lSize = (LONG)msg.m_vecRegionInfo.size();
	if(lSize)
	{	// ���� ��� ��� GSID�� SSN�� 1:1�� ������ ���̶� ����.
		ForEachElmt(VecRegionInfo, msg.m_vecRegionInfo, it, jt)
		{
			PMSRegionInfo & region_base = *it;

			//regionInfo.m_unitID = region_base.m_unitID;
			//regionInfo.m_vecRegion.insert(region_base.m_vecRegion.begin(), region_base.m_vecRegion.end());
			//regionInfo.m_vecRegion.assign(region_base.m_vecRegion.begin(), region_base.m_vecRegion.end());

			tstring strBuff = _T("");
			TCHAR strTemp[8];

			int count = 0;
			for (LONG i = 0 ; i<(LONG)region_base.m_vecRegion.size() ; i++ )
			{
				//_itot(i, strTemp, 10);
				//strBuff.append(strTemp);
				//strBuff.append(_T("["));
				//_itot(region_base.m_vecRegion[i], strTemp, 10);
				//strBuff.append(strTemp);
				//if (i<(LONG)region_base.m_vecRegion.size()-1)
				//	strBuff.append(_T("],"));
				//else
				//	strBuff.append(_T("]"));

				_itot(region_base.m_vecRegion[i], strTemp, 10);
				strBuff.append(strTemp);
				if (i<(LONG)region_base.m_vecRegion.size()-1)
					strBuff.append(_T(","));

				count++;
			}			

			GET_VIEW()->SetListItem(pLink->GetGSID(), 1, count, _T("���(PC)"), strBuff.c_str());

			if (GET_VIEW()->GetAddStatisticsFlag() == TRUE)
				GET_VIEW()->AddStatisticsData(pLink->GetGSID(), (LONG)region_base.m_vecRegion.size(), strBuff.c_str());

			GBuf buf;
			//::BStore(buf, regionInfo);
			::BStore(buf, region_base);
			LPXBUF lpXBuf = buf.Detach();
			::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, 0, (LPARAM)lpXBuf);
		}	
	}
	else
	{
		regionInfo.m_unitID.m_dwGSID = (DWORD)pLink->GetGSID();
		GBuf buf;
		::BStore(buf, regionInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, 0, (LPARAM)lpXBuf);
	}
}

