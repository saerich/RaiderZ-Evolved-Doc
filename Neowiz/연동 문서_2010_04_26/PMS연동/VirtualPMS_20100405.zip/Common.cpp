#include "stdafx.h"
#include "Common.h"
#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

#include "ConfigInfo.h"
#include "DBManager.h"
#include "IniManager.h"

#define HOSTNAMELEN 30


int GetString(tstring &strsur, tstring &strdest,TCHAR* cdelimiter)
{
	tstring strswap;
	strswap = strsur;
	int nlen = strsur.find(cdelimiter);	
	if(nlen ==-1)
	{
		strdest.assign(strsur);
		return 0;
	}
	strdest.assign( strsur.substr(0,nlen));	
	strsur.erase(strsur.begin(),strsur.begin()+ nlen + 3);
	return nlen+3;
}

int GetString(tstring &strsur, tstring &strdest, TCHAR cdelimiter)
{
	tstring strswap(strsur);
	strswap.assign(strsur);
	
	int nlen = strsur.find(cdelimiter);
	if(nlen==-1)
	{
		nlen = strsur.find(_T('\0'));
		if(nlen==-1)
		{
			strdest.assign(strsur);
			return 0;
		}
	}
	strdest.assign(strsur.substr(0,nlen));
	strsur.erase(strsur.begin(),strsur.begin()+ nlen + 1);


	return nlen+1;
}

tstring GetTimeFormat(tstring &str,int nType)
{
	tstring strDate;
	SYSTEMTIME _time;
	memset(&_time, 0, sizeof(SYSTEMTIME));
	::GetLocalTime(&_time);
	switch(nType)
	{
	case 1:
		str = ::format(_T("%04d/%02d/%02d\r\n"), _time.wYear,_time.wMonth,_time.wDay);		
		break;
	case 2:
		str = ::format(_T("%04d/%02d/%02d/%02d/%02d\r\n"), _time.wYear,_time.wMonth,_time.wDay,_time.wHour,_time.wMinute);
		break;
	case 3:
		str = ::format(_T("%04d-%02d-%02d %02d:%02d:%02d\r\n"), _time.wYear,_time.wMonth,_time.wDay,_time.wHour,_time.wMinute,_time.wSecond);
		break;
	}
	return str;
}

////////////////////////////////////////////////////////////////////////////////
CGSInfoTable theGSInfoTable;

BOOL CGSInfoTable::InitSeverBaseInfo()
{
	char _host[100] = {0, };
	::gethostname(_host, sizeof(_host));
	m_sHostName = str2tstr(_host);

	TCHAR szDBHostName[HOSTNAMELEN+1];
	BOOL bRet=FALSE;

	
	//DWORD dwRet = ::GetPrivateProfileString(_T("DBINFO"), _T("HOSTNAME"), _T("127.0.0.1"), szDBHostName, HOSTNAMELEN, PMSConnServer_INI);

	//if(!dwRet)
	//{
	//	theErr.LOG(0, _T("PMSConnServer_CONFIG.ini READ ERROR\n"));
	//	return FALSE;
	//}

	//if(_tcslen(szDBHostName)==0)
	//{
	//	//��񿡼� ������ ������ �� ���� ��� INI���� ������ �������о� �´�.
	//	theErr.LOG(0, _T("PMSConnServer_CONFIG READ ERROR - SECTION NAME NULL\n"));
	//	return FALSE;
	//}	

	tstring strBaseInfo,strTemp;
	strBaseInfo.reserve(2000);

	if (g_ConfigInfo.GetLoadType() == 0)
	{
		//DB 
		theErr.LOG(0, _T("DB - Init Start\n"));

		try
		{
			if(!thedbmanager.InitDBManager(szDBHostName,strBaseInfo))
			{
				theErr.LOG(0, _T("DB Init Error\n"));
				bRet = FALSE;
			}
			else
			{
				theErr.LOG(1, _T("%s\n"),strBaseInfo.c_str());

				GetString(strBaseInfo,m_strMAIP,'/');
				GetString(strBaseInfo,m_strMAPort,'/');
				GetString(strBaseInfo,m_strHAIP,'/');
				GetString(strBaseInfo,m_strHAID,'/');
				GetString(strBaseInfo,m_strHAPort,'/');
				GetString(strBaseInfo,m_strHostGroupID,'/'); // chs, gls, sf, login server...

				m_sSvrBaseInfo.assign(strBaseInfo);
				bRet = TRUE;
			}
		}
		catch(...)
		{
			theErr.LOG(0, _T("Unknown Error"));
			bRet = FALSE;
		}
	}
	else
	{
		//ini file
		theErr.LOG(0, _T("VirtualPMS.ini - Init Start\n"));

		tstring sIniFile = _T("VirtualPMS.ini");
		CIniManager inimgr;
		inimgr.SetIniFileName(sIniFile);

		m_strMAIP = inimgr.GetValue(_T("SETTING"), _T("MAIP"));
		if (m_strMAIP.length() == 0) m_strMAIP = _T("219.254.21.19");

		m_strMAPort = inimgr.GetValue(_T("SETTING"), _T("MAPort"));
		if (m_strMAPort.length() == 0) m_strMAPort = _T("9898");

		m_strHAIP = inimgr.GetValue(_T("SETTING"), _T("HAIP"));
		if (m_strHAIP.length() == 0) m_strHAIP = _T("127.0.0.1");

		m_strHAID = inimgr.GetValue(_T("SETTING"), _T("HAID"));
		m_strHAPort = inimgr.GetValue(_T("SETTING"), _T("HAPort"));
		if (m_strHAPort.length() == 0) m_strHAPort = _T("8989");

		m_strHostGroupID = inimgr.GetValue(_T("SETTING"), _T("HostGroupID"));

		bRet = TRUE;
	}

	//GET_VIEW()->SetRichEditText(_T("[Config] MAIP :"));
	//GET_VIEW()->SetRichEditText(m_strMAIP.c_str());
	//GET_VIEW()->SetRichEditText(_T("\n"));
	//GET_VIEW()->SetRichEditText(_T("[Config] MAPort :"));
	//GET_VIEW()->SetRichEditText(m_strMAPort.c_str());
	//GET_VIEW()->SetRichEditText(_T("\n"));
	GET_VIEW()->SetRichEditText(_T("[Config] HAIP :"));
	GET_VIEW()->SetRichEditText(m_strHAIP.c_str());
	GET_VIEW()->SetRichEditText(_T("\n"));
	GET_VIEW()->SetRichEditText(_T("[Config] HAID :"));
	GET_VIEW()->SetRichEditText(m_strHAID.c_str());
	GET_VIEW()->SetRichEditText(_T("\n"));
	GET_VIEW()->SetRichEditText(_T("[Config] HAPort :"));
	GET_VIEW()->SetRichEditText(m_strHAPort.c_str());
	GET_VIEW()->SetRichEditText(_T("\n"));
	GET_VIEW()->SetRichEditText(_T("[Config] HostGroupID :"));
	GET_VIEW()->SetRichEditText(m_strHostGroupID.c_str());
	GET_VIEW()->SetRichEditText(_T("\n"));

	return bRet;
}


///////////////////////////////////////////////////////////////////////////////////////////
//CGSSessionTable
CGSSessionTable theGSSessionTable;

BOOL CGSSessionTable::InitGSSessionTable()
{
	TLock lo(this);

	if (g_ConfigInfo.GetLoadType() == 1)
	{
		tstring sIniFile = _T("VirtualPMS.ini");
		CIniManager inimgr;
		inimgr.SetIniFileName(sIniFile);

		int count = inimgr.GetIntValue(_T("GS"), _T("COUNT"));

		TCHAR fieldName[16];

		tstring strGSID, strSSN;

		for (int i=0; i<count; i++)
		{
			GSINFO *pinfo = new GSINFO();

			_stprintf(fieldName, _T("GSID%d"), i+1);
			strGSID = inimgr.GetValue(_T("GS"), fieldName);

			_stprintf(fieldName, _T("SSN%d"), i+1);
			pinfo->m_infoMap[_T("SSN")] = inimgr.GetValue(_T("GS"), fieldName);

			_stprintf(fieldName, _T("EXETITLE%d"), i+1);
			pinfo->m_infoMap[_T("EXETITLE")] = inimgr.GetValue(_T("GS"), fieldName);
			pinfo->m_infoMap[_T("PERFNAME")] = inimgr.GetValue(_T("GS"), fieldName);
			_stprintf(fieldName, _T("EXEPATH%d"), i+1);
			pinfo->m_infoMap[_T("EXEPATH")] = inimgr.GetValue(_T("GS"), fieldName);
			_stprintf(fieldName, _T("EXECUTEKIND%d"), i+1);
			pinfo->m_infoMap[_T("EXECUTEKIND")] = inimgr.GetValue(_T("GS"), fieldName);
			_stprintf(fieldName, _T("CFG%d"), i+1);
			pinfo->m_infoMap[_T("CFGNAME")] = inimgr.GetValue(_T("GS"), fieldName);

			//pinfo->m_infoMap[_T("CFGNAME")] = _T("cfg");
			pinfo->m_infoMap[_T("STATUS")] = _T("1");
			pinfo->m_infoMap[_T("KILLMEHTOD")] = _T("stop");
			pinfo->m_infoMap[_T("STARTMETHOD")] = _T("start");
			pinfo->m_infoMap[_T("RECOVERMETHOD")] = _T("restart");
			pinfo->m_infoMap[_T("MAXCPU")] = _T("100");
			pinfo->m_infoMap[_T("MINCPU")] = _T("-1");
			pinfo->m_infoMap[_T("MAXMEM")] = _T("9999");
			pinfo->m_infoMap[_T("MINMEM")] = _T("-1");
			pinfo->m_infoMap[_T("COUNT1MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT1MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT2MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT2MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT3MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT3MIN")] = _T("0");
			pinfo->m_infoMap[_T("COUNT4MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT4MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT5MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT5MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT6MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT6MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT7MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT7MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT8MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT8MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT9MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT9MIM")] = _T("0");
			pinfo->m_infoMap[_T("COUNT10MAX")] = _T("0");
			pinfo->m_infoMap[_T("COUNT10MIM")] = _T("0");

			theErr.LOG(1, _T("[CGSSessionTable] Init - Total GSID %s\n"), strGSID.c_str());

			m_gsBaseinfo[strGSID]= pinfo;

			tstring strmode = pinfo->m_infoMap[_T("EXECUTEKIND")];
			::OutputDebugString(strmode.c_str());
			tstring exemode = _T("");

			if (strmode.compare(_T("0")) == 0)
				exemode = _T("�ܼ�");
			else if (strmode.compare(_T("1")) == 0) 
				exemode = _T("����");
			else if (strmode.compare(_T("2")) == 0) 
				exemode = _T("��ũ��Ʈ");
			else
				exemode = _T("???");

			GET_VIEW()->SetListGS(pinfo->m_infoMap[_T("EXETITLE")].c_str(),
				pinfo->m_infoMap[_T("EXEPATH")].c_str(),
				strGSID.c_str(),
				theGSInfoTable.GetHAIP().c_str(),
				theGSInfoTable.GetHAPort().c_str(),
				exemode.c_str(),
				pinfo->m_infoMap[_T("CFGNAME")].c_str());
		}
		return TRUE;
	}

	tstring strBaseinfo;
	strBaseinfo.reserve(1000);
	int nGSCount=0;
	int nRet=0;
	tstring strTemp;
	
	strBaseinfo.assign(theGSInfoTable.GetGSBaseInfo());
	int nlen = theGSInfoTable.GetGSBaseInfo().length();

	GBuf buf(NULL,nlen);
	
	GetString(strBaseinfo,strTemp,'/');

	nGSCount = _tstoi(strTemp.data());

	strTemp.clear();

	for(int i=0; i<nGSCount; i++)
	{
		tstring strGSID, strcount;

		GSINFO *pinfo = new GSINFO();
		GetString(strBaseinfo,strGSID,'/');

		tstring _SSN(_T(""));
		GetString(strBaseinfo, _SSN, '/');
		pinfo->m_infoMap[_T("SSN")] = _SSN;


		GetString(strBaseinfo,pinfo->m_infoMap[_T("STATUS")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("EXETITLE")],'/');		
		GetString(strBaseinfo,pinfo->m_infoMap[_T("EXEPATH")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("PERFNAME")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("EXECUTEKIND")],'/'); //0 :exe 1 :Service
		GetString(strBaseinfo,pinfo->m_infoMap[_T("CFGNAME")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("KILLMEHTOD")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("STARTMETHOD")],'/');
		GetString(strBaseinfo,pinfo->m_infoMap[_T("RECOVERMETHOD")],'/');
		// unix �迭�� ��� / �� ���丮 ��ΰ� �Ǿ '\'
		// �� �Է� �ް� �̰��� �ٽ� /�� ���� �ϵ��� �߰�
		for (unsigned int kkk = 0; kkk < pinfo->m_infoMap[_T("STARTMETHOD")].length(); kkk++)
		{
			if (pinfo->m_infoMap[_T("STARTMETHOD")][kkk] == '\\')
			{
				pinfo->m_infoMap[_T("STARTMETHOD")][kkk] = '/';
			}
		}
		for (unsigned int kkk = 0; kkk < pinfo->m_infoMap[_T("KILLMEHTOD")].length(); kkk++)
		{
			if (pinfo->m_infoMap[_T("KILLMEHTOD")][kkk] == '\\')
			{
				pinfo->m_infoMap[_T("KILLMEHTOD")][kkk] = '/';
			}
		}
		for (unsigned int kkk = 0; kkk < pinfo->m_infoMap[_T("RECOVERMETHOD")].length(); kkk++)
		{
			if (pinfo->m_infoMap[_T("RECOVERMETHOD")][kkk] == '\\')
			{
				pinfo->m_infoMap[_T("RECOVERMETHOD")][kkk] = '/';
			}
		}

		GetString(strBaseinfo,strcount,'/');
		nRet = GetString(strcount,pinfo->m_infoMap[_T("MAXCPU")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("MAXCPU")]= _T("0");

		nRet = GetString(strcount,pinfo->m_infoMap[_T("MINCPU")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("MINCPU")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("MAXMEM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("MAXMEM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("MIMMEM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("MINMEM")]= _T("0");

		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT1MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT1MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT1MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT1MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT2MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT2MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT2MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT2MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT3MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT3MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT3MIN")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT3MIN")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT4MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT4MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT4MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT4MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT5MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT5MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT5MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT5MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT6MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT6MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT6MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT6MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT7MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT7MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT7MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT7MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT8MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT8MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT8MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT8MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT9MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT9MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT9MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT9MIM")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT10MAX")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT10MAX")]= _T("0");
		nRet = GetString(strcount,pinfo->m_infoMap[_T("COUNT10MIM")],'^');
		if(nRet==0)
			pinfo->m_infoMap[_T("COUNT10MIM")]= _T("0");

		theErr.LOG(1, _T("[CGSSessionTable] Init - Total GSID %s\n"), strGSID.c_str());

		m_gsBaseinfo[strGSID]= pinfo;

		tstring strmode = pinfo->m_infoMap[_T("EXECUTEKIND")];
		tstring exemode = _T("");

		if (strmode.compare(_T("0")) == 0)
			exemode = _T("�ܼ�");
		else if (strmode.compare(_T("1")) == 0) 
			exemode = _T("����");
		else if (strmode.compare(_T("2")) == 0) 
			exemode = _T("��ũ��Ʈ");
		else
			exemode = _T("???");
			

		GET_VIEW()->SetListGS(pinfo->m_infoMap[_T("EXETITLE")].c_str(),
			pinfo->m_infoMap[_T("EXEPATH")].c_str(),
			strGSID.c_str(),
			theGSInfoTable.GetHAIP().c_str(),
			theGSInfoTable.GetHAPort().c_str(),
			exemode.c_str(),
			pinfo->m_infoMap[_T("CFGNAME")].c_str());
	
	}
	if (i==0)
	{
		theErr.LOG(0, _T("Not Found GSID\n"));
	}
	else
	{
		theErr.LOG(0, _T("[CGSSessionTable] - Init SUCCESS\n"));
	}
	return TRUE;
}

GSINFOTABLE & CGSSessionTable::GetTable()
{
	return m_gsBaseinfo;
}

void CGSSessionTable::Clear()
{
	TLock lo(this);
	ForEachElmt(GSINFOTABLE, m_gsBaseinfo,it, jt)
	{
		GSINFO * p = it->second;
		delete p;
	}
	m_gsBaseinfo.clear();
}

GSINFO * CGSSessionTable::FindServer(CLink *pLink,int & nIndex, tstring & strGSID)
{
	TLock lo(this);
	GSINFOTABLE::iterator it;

	int i=0;
	for(it = m_gsBaseinfo.begin(); it != m_gsBaseinfo.end(); it++)
	{
		GSINFO &pinfo = *it->second;
		if(pinfo.m_pLink == pLink)
		{
			strGSID = it->first;//const_cast<char*>(it->first);
			break;
		}
		i++;
	}
	if(it==m_gsBaseinfo.end())
	{
		return NULL;
	}
	nIndex = i;
	return it->second;	
}

BOOL CGSSessionTable::GetServer(GSINFO & svrInfo, CLink *pLink, int &nindex, tstring &strGSID)
{
	TLock lo(this);
	GSINFO * pInfo = FindServer(pLink, nindex, strGSID);
	if(!pInfo) 
		return FALSE;
	svrInfo = *pInfo;
	return TRUE;
}

// �Ϻ��ϰ� ��ȣ���� ������..  application�� sequence�� ������ �� ���ɼ��� ���� �״�� ��... jsp 
GSINFO * CGSSessionTable::FindServer(tstring sGSID)
{
	TLock lo(this);
	GSINFOTABLE::iterator itr = m_gsBaseinfo.find(sGSID);
	if(itr == m_gsBaseinfo.end())
	{
		return NULL;
	}
	GSINFO * pInfo = itr->second;
	if(!pInfo)
		return NULL;
	return pInfo;
}

BOOL CGSSessionTable::GetServer(GSINFO & svrInfo, tstring sGSID)
{
	TLock lo(this);
	GSINFO * pInfo = FindServer(sGSID);
	if(!pInfo)
		return FALSE;
	svrInfo = *pInfo;
	return TRUE;
}

BOOL CGSSessionTable::SetRecord(tstring sGSID, GSINFO & gsInfo)	// valid value���� update..
{
	TLock lo(this);
	GSINFO * pInfo = FindServer(sGSID);
	if(!pInfo || pInfo->m_pLink)
//		if(sGSID != "888888")	// for debuging..
			return FALSE;
	if((DWORD)gsInfo.m_handle > 0UL && (DWORD)gsInfo.m_handle < 0xFFFFFFFF && gsInfo.m_dwProcessID != 0 )
	{
		if (pInfo->m_dwProcessID != gsInfo.m_dwProcessID)
		{
			pInfo->m_dwProcessID = gsInfo.m_dwProcessID;
			if (pInfo->m_handle && pInfo->m_handle!= INVALID_HANDLE_VALUE)
			{
 
				::CloseHandle(pInfo->m_handle);
			}
			pInfo->m_handle = gsInfo.m_handle;

		}
		else
		{
			::CloseHandle(gsInfo.m_handle);
		}
	}
	int map_size = gsInfo.m_infoMap.size();
	if(map_size > 0)
	{
		ArcMapT<tstring,tstring>::iterator itr = gsInfo.m_infoMap.begin();
		for( ; itr != gsInfo.m_infoMap.end(); itr++)
		{
			pInfo->m_infoMap[itr->first] = itr->second;
		}
		//pInfo->m_infoMap.insert(gsInfo.m_infoMap.begin(), gsInfo.m_infoMap.end());
	}
	if(gsInfo.m_lState > GS_MINVAL && gsInfo.m_lState < GS_MAXVAL)
		pInfo->m_lState = gsInfo.m_lState;
	if(gsInfo.m_nindex > 0 && gsInfo.m_nindex)
		pInfo->m_nindex = gsInfo.m_nindex;
	if(gsInfo.m_pLink)
		pInfo->m_pLink = gsInfo.m_pLink;
	pInfo->m_sOptAddr = gsInfo.m_sOptAddr;
	pInfo->m_sStartTime = gsInfo.m_sStartTime;
	if (gsInfo.m_sOptAddr.length() > 0)
		pInfo->m_infoMap[_T("PERFNAME")].assign(gsInfo.m_sOptAddr);
	return TRUE;
}

void CGSSessionTable::ResetRecord(DWORD dwGSID)
{
	TCHAR _gsid[10] = {0, };
	_stprintf(_gsid, _T("%d"), dwGSID);
	GSINFO * pInfo = FindServer(_gsid);
	if(!pInfo)
		return;
	pInfo->m_sStartTime.erase();
	pInfo->m_pLink = NULL;
	pInfo->m_dwProcessID = 0;
}

BOOL CGSSessionTable::GetTitle(tstring &sPerfName, DWORD dwGSID)
{
	TLock lo(this);
	TCHAR _gsid[10] = {0, };
	_itot(dwGSID, _gsid, 10);
	tstring sGSID(_gsid);
	GSINFO * pInfo = FindServer(sGSID);
	if(!pInfo) return FALSE;
	sPerfName = pInfo->m_infoMap[_T("PERFNAME")];
	if(sPerfName.length() == 0) return FALSE;
	return TRUE;
}

LONG CGSSessionTable::GetSSN(tstring & sGSID)
{
	TLock lo(this);
	GSINFO * pInfo = FindServer(sGSID);
	if(!pInfo) return -1L;
	tstring sSSN = pInfo->m_infoMap[_T("SSN")];
	return _tstol(sSSN.c_str());
}

BOOL CGSSessionTable::IsExist(DWORD dwGSID)
{
	TCHAR buff[10] = {0, };
	_stprintf(buff, _T("%d"), dwGSID);
	tstring gsid = buff;
	GSINFOTABLE::iterator itr = m_gsBaseinfo.find(gsid);
	if(itr == m_gsBaseinfo.end())
		return FALSE;
	return TRUE;
}

BOOL CGSSessionTable::FindServer(tstring & sAppName, tstring & sGSID)
{
	ForEachElmt(GSINFOTABLE, m_gsBaseinfo,it, jt)
	{
		GSINFO * p = it->second;
		tstring tempTitle = p->m_infoMap[_T("EXETITLE")];
		tstring tempTitleDebug = p->m_infoMap[_T("EXETITLE")] + _T("D");
		tstring tempPerfName = p->m_infoMap[_T("PERFNAME")];
		tstring tempPerfNameDebug = p->m_infoMap[_T("PERFNAME")] + _T("D");
		
		if (!stricmp(sAppName.c_str(), tempTitle.c_str()) ||
			!stricmp(sAppName.c_str(), tempTitleDebug.c_str()) ||
			!stricmp(sAppName.c_str(), tempPerfName.c_str()) ||
			!stricmp(sAppName.c_str(), tempPerfNameDebug.c_str()) )
		{
			sGSID = it->first;
			if (p->m_pLink)
				continue;
			return TRUE;
		}
	}	
	return FALSE;
}

