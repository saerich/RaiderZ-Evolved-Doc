// ErrorLog.cpp

#include "stdafx.h"
#include "ErrorLog.h"

#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

CErrorLog theErr;

///////////////////////////////////////////////////////////////////////////////////
// CErrorLog

CErrorLog::CErrorLog()
{
	SYSTEMTIME sys;
	memset(&sys, 0, sizeof(SYSTEMTIME));
	::GetLocalTime(&sys);
	memset(m_path, 0, sizeof(m_path));
	::CreateDirectory(LOG_DIRECTORY, NULL);
	_stprintf(m_path, _T("c:\\LOG\\PMSConnServer\\LOG%04d%02d%02d_%02d%02d.mcu"), sys.wYear, sys.wMonth, sys.wDay, sys.wHour, sys.wMinute);

	m_iLevel = SetIsLog();
}

CErrorLog::~CErrorLog()
{

}

void __cdecl CErrorLog::LOG(int iLevel, LPCTSTR fmt,...)
{
	
	TCHAR buf[1024*2] = {0, };

	va_list vl;
	va_start(vl, fmt);
	//_vsnprintf(buf, 1024*2, fmt, vl);

//_vsnwprintf
//_vsntprintf

///	_stprintf(buf, 1024*2, fmt, vl);
	_vsntprintf(buf, 1024*2, fmt, vl);

	buf[1024*2-1] = 0;
	va_end(vl);

//	_CHSLOG(iLevel, buf);

	if(m_iLevel < iLevel)
		return;
	SYSTEMTIME sys;
	memset(&sys, 0, sizeof(SYSTEMTIME));
	::GetLocalTime(&sys);
	m_CS.Lock();
	FILE * fh = _tfopen(m_path, _T("a") );

	if(fh == NULL) {
		m_CS.Unlock();
		return;
	}

	//CMainFrame *pFrame = (CMainFrame*)AfxGetMainWnd();
	//CPMSConnServerView* pView = (CPMSConnServerView*)pFrame->GetActiveView();
	//pView->SetRichEditText(buf);

	GET_VIEW()->SetRichEditText(buf);

	_ftprintf(fh, _T("PMSCS [%02d_%02d:%02d:%02d:%03d / TID:%d]  = %s"), sys.wDay, sys.wHour, sys.wMinute, sys.wSecond, sys.wMilliseconds,GetCurrentThreadId(), buf);
	fclose( fh );
	m_CS.Unlock();
}

void __cdecl CErrorLog::LOG2(int iLevel, LPCTSTR fmt,...)
{
	
	TCHAR buf[1024*2] = {0, };

	va_list vl;
	va_start(vl, fmt);
	//_vsnprintf(buf, 1024*2, fmt, vl);

//_vsnwprintf
//_vsntprintf

///	_stprintf(buf, 1024*2, fmt, vl);
	_vsntprintf(buf, 1024*2, fmt, vl);

	buf[1024*2-1] = 0;
	va_end(vl);

//	_CHSLOG(iLevel, buf);

	if(m_iLevel < iLevel)
		return;
	SYSTEMTIME sys;
	memset(&sys, 0, sizeof(SYSTEMTIME));
	::GetLocalTime(&sys);
	m_CS.Lock();
	FILE * fh = _tfopen(m_path, _T("a") );

	if(fh == NULL) {
		m_CS.Unlock();
		return;
	}

	_ftprintf(fh, _T("PMSCS [%02d_%02d:%02d:%02d:%03d / TID:%d]  = %s"), sys.wDay, sys.wHour, sys.wMinute, sys.wSecond, sys.wMilliseconds,GetCurrentThreadId(), buf);
	fclose( fh );
	m_CS.Unlock();
}


int CErrorLog::SetIsLog()
{
	//TCHAR szTemp[256] = {0, };
	//DWORD dwRet = ::GetPrivateProfileString("LOG", "ERRLEVEL", _T(""), szTemp, sizeof(szTemp), HA_ERR);
	//if(dwRet == 0) {
	//	TLOG0("Not found HA.INI file or Valid value \n");
	//	return 2;
	//}
	LONG lERRLEVEL = 1;//atoi(szTemp); 
	return lERRLEVEL;

//	CRegKey reg;
//	DWORD flag = 2;
//	char keyName[] = "Software\\Neowiz\\FACADE\\CHSCONFIG";
//	if(ERROR_SUCCESS == reg.Create(HKEY_LOCAL_MACHINE, (LPCTSTR)keyName, "ISREGISTER")) {
//		if(ERROR_SUCCESS == reg.QueryValue(flag, "ISREGISTER")) {
//			return flag;
//		}
//		else 
//			reg.SetValue(flag, "ISREGISTER");
//	}
//	return 2;
}

void CErrorLog::NewLogFile()
{
	SYSTEMTIME sys;
	memset(&sys, 0, sizeof(SYSTEMTIME));
	::GetLocalTime(&sys);
	memset(m_path, 0, sizeof(m_path));
	_stprintf(m_path, _T("c:\\LOG\\PMSConnServer\\LOG%04d%02d%02d_%02d%02d.mcu"), sys.wYear, sys.wMonth, sys.wDay, sys.wHour, sys.wMinute);

}

