#include "stdafx.h"
#include "Configinfo.h"
#include "IniManager.h"

#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

using std::string;

CConfigInfo g_ConfigInfo;

CConfigInfo::CConfigInfo(void)
{
}

CConfigInfo::~CConfigInfo(void)
{
}

BOOL CConfigInfo::LoadConfig()
{
	BOOL bRet = TRUE;
	
	tstring sIniFile = _T("VirtualPMS.ini");
	CIniManager inimgr;
	inimgr.SetIniFileName(sIniFile);
	m_config.m_sDBName = inimgr.GetValue(_T("DB"), _T("NAME"));
	if (m_config.m_sDBName.length() == 0)
		m_config.m_sDBName = _T("PMS_TEST");

	m_config.m_sDBServer = inimgr.GetValue(_T("DB"), _T("SERVER"));
	if (m_config.m_sDBServer.length() == 0)
		m_config.m_sDBServer = _T("PA07.sayclub.com");

	m_config.type = inimgr.GetIntValue(_T("SYSTEM"), _T("TYPE"));
	if ((m_config.type < 0) || (m_config.type > 1)) m_config.type = 0;

	nLog = inimgr.GetIntValue(_T("SYSTEM"), _T("LOG"));

	if ( (nLog <0) || (nLog > 3) ) nLog = 1;

	GET_VIEW()->SetRichEditColor(11,135,211);

	if (m_config.type == 1)
		theErr.LOG(0, _T("Config Load from INI file\n"));
	else 
		theErr.LOG(0, _T("Config Load from DB\n"));
		
	if (m_config.type == 0)
	{
		theErr.LOG(1, _T("Sql Server  : %s\n"), m_config.m_sDBServer.c_str());
		theErr.LOG(1, _T("Sql DB Name : %s\n"), m_config.m_sDBName.c_str());
	}
	else
	{
		theErr.LOG(0, _T("ini File Load : VirtualPMS.ini\n"));
	}
	
	GET_VIEW()->SetRichEditColor(30,50,80);

	return bRet;
}

tstring CConfigInfo::GetDBName() const
{
	return m_config.m_sDBName;
}

tstring CConfigInfo::GetDBServer() const 
{
	return m_config.m_sDBServer;
}

int CConfigInfo::GetLoadType() const
{
	return m_config.type;
}

int CConfigInfo::GetLogValue() const
{
	return nLog;
}


