#include "stdafx.h"
#include "GSListener.h"
#include "ClientMgr.h"
#include "Common.h"
#include "GSLinkManager.h"


CGSListener theGSListener;
CGSListener::CGSListener()
{
}
CGSListener::~CGSListener()
{
	TBase::Destroy();
}


///////////////////////////////////////////////////////////////////////////////////////////////////


BOOL CGSListener::OnError(CLink*pLink, long lEvent, int nErrorCode)
{
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////


BOOL CGSListener::RunGSListener(LONG lPort)
{	
	// Listener�� �����Ѵ�.IP��PORT�� ��񿡼� ����� ����
	BOOL bRet = TBase::Create(lPort  ,NULL);

	if(!bRet)
	{
		theErr.LOG(1, _T("[CGSLINSTNER START] ERROR HA PORT %d \n") ,lPort);
		return FALSE;
	}
	return bRet;
}


///////////////////////////////////////////////////////////////////////////////////////////////////


void CGSListener::OnAccept(SOCKET hSocket,int nErrorCode, LPCSTR szAddr, LONG lPort)
{
   	if (hSocket == INVALID_SOCKET)
	{
		theErr.LOG(1,_T("[CGSListener] invalid socket  : %d\n"),1);
		return;
	}
	
	if (nErrorCode)
	{
		theErr.LOG(1,_T("[CGSListener] Accept Error ErrorCode  : %d\n"),nErrorCode);
		::closesocket(hSocket);
		return;
	}

	USES_CONVERSION;
	theErr.LOG(1,_T("[CGSLINSTNER OnAccept] GSI ACCEPT IP : %s\n"), A2T(szAddr));
	

	BOOL bRet = theGSmanager.AddClient(hSocket, szAddr);

	if ( !bRet )
		closesocket(hSocket);
 
}