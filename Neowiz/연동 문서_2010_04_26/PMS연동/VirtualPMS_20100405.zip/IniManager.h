#ifndef __INIMANAGER_H_
#define __INIMANAGER_H_
#pragma once
#include <string>
#include <windows.h>
class CIniManager
{
public:
	CIniManager(void);
	CIniManager(const tstring& sIniFileName);
	void SetIniFileName(const tstring& sIniFileName, const BOOL& isCurFolder = TRUE);
	virtual ~CIniManager(void);
	virtual BOOL	PutValue(const tstring& sSectionName, const tstring& sLeftValue, const tstring& sRightValue);
	virtual BOOL	PutValue(const tstring& sSectionName, const tstring& sLeftValue, const int& nRightValue);
	virtual tstring	GetValue(const tstring& sSectionName, const tstring& sLeftValue);
	virtual int		GetIntValue(const tstring& sSectionName, const tstring& sLeftValue);
#ifdef UNICODE 
	virtual tstring CIniManager::GetValueByAscii(const tstring& sSectionName, const tstring& sLeftValue);
#endif
protected:
	tstring m_sIniFileName;
};

#endif // ifndef __INIMANAGER_H_