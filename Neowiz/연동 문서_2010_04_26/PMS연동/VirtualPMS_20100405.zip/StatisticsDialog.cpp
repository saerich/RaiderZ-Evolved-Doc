// StatisticsDialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "PMSConnServer.h"
#include "StatisticsDialog.h"
#include ".\statisticsdialog.h"

#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

// CStatisticsDialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CStatisticsDialog, CDialog)
CStatisticsDialog::CStatisticsDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CStatisticsDialog::IDD, pParent)
{
}

CStatisticsDialog::~CStatisticsDialog()
{
}

void CStatisticsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_PARSESTAT, m_list_stat);
}


BEGIN_MESSAGE_MAP(CStatisticsDialog, CDialog)
END_MESSAGE_MAP()


// CStatisticsDialog �޽��� ó�����Դϴ�.

BOOL CStatisticsDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SetWindowText(_T("Statistics Dialog"));

	LV_COLUMN lvcolumnstat;
	lvcolumnstat.mask = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvcolumnstat.fmt	= LVCFMT_LEFT;

	lvcolumnstat.pszText	=	_T("NO");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 40;
	m_list_stat.InsertColumn(0, &lvcolumnstat);

	lvcolumnstat.pszText	=	_T("STATDATE");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 120;
	m_list_stat.InsertColumn(1, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("GSID");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(2, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("TOTCOUNT");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 70;
	m_list_stat.InsertColumn(3, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("0-13");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(4, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("14-16");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(5, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("17-19");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(6, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("20-24");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(7, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("25-29");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(8, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("30-39");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(9, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("40-99");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(10, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("Male");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(11, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("Female");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(12, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("���");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(13, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(14, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("��õ");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(15, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(16, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("�泲");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(17, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("���");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(18, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(19, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("���");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(20, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("�泲");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(21, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("�뱸");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(22, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("�λ�");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(23, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("���");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(24, &lvcolumnstat);

	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(25, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(26, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(27, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("����");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(28, &lvcolumnstat);
	
	lvcolumnstat.pszText	=	_T("�ܱ���");
	lvcolumnstat.iSubItem	=	0;
	lvcolumnstat.cx = 50;
	m_list_stat.InsertColumn(29, &lvcolumnstat);

	m_list_stat.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	return TRUE;
}

void CStatisticsDialog::AddData(CString gsid, CString size, CString datetime, CString data)
{
	int row = m_list_stat.GetItemCount();
	TCHAR buff[8];
	_itot(row+1, buff, 10);

	int count = 0;
	long num = 0;
	long totalcount = 0;
	int curPos = 0;

	int region[MAX_REGION] = { 0 };
	int age[MAX_AGE] = { 0 };
	int gender[MAX_GENDER] = { 0 };

	CString strTemp;
	CString temp;

	temp = data.Tokenize(_T(","), curPos);

	int i_size = _ttoi(size.GetBuffer());

	if (i_size == (MAX_REGION * (MAX_AGE-1) * MAX_GENDER))
	{
		count = 0;

		while(temp != "")
		{
			num = _tstol(temp.GetBuffer());

			int current_region;
			int current_age;
			int current_gender;

			if (count % MAX_GENDER == 0)
				current_gender = 0;
			else
				current_gender = 1;
			gender[current_gender] += num;

			if (count < ((MAX_AGE-1) * (MAX_GENDER)) )
				region[0] += num;
			else
				region[count / ((MAX_AGE-1) * (MAX_GENDER))] += num;
			current_region = count / ((MAX_AGE-1) * (MAX_GENDER));

			current_age = ( count - ( current_region * ((MAX_AGE-1) * (MAX_GENDER)) ) ) / 2;
			age[current_age] += num;

			totalcount += num;

			temp = data.Tokenize(_T(","), curPos);
			count ++;
		}
	}
	else if (i_size == (MAX_REGION * (MAX_AGE) * MAX_GENDER))
	{
		count = 0;

		while(temp != "")
		{
			num = _tstol(temp.GetBuffer());

			int current_region;
			int current_age;
			int current_gender;

// 	m_RegionArray8[m_current_gender][m_current_age][m_current_region] = m_edit_addcount;

			current_region = count % MAX_REGION;
			region[current_region] += num;

			if ( count < (MAX_AGE * MAX_REGION) )
				current_gender = 0;
			else
				current_gender = 1;
			gender[current_gender] += num;

			if (current_gender == 0)
				current_age = count / (MAX_REGION);
			else
				current_age = (count / MAX_REGION) - MAX_AGE;
			age[current_age] += num;

			totalcount += num;

			temp = data.Tokenize(_T(","), curPos);
			count ++;
		}
	}
	else
	{
		AfxMessageBox(_T("��� ������ ��ġ�� �� �� �Ǿ����ϴ�."));
		return;
	}

	m_list_stat.InsertItem(row, buff);
	m_list_stat.SetItemText(row, 1, datetime);
	m_list_stat.SetItemText(row, 2, gsid);
	strTemp.Format(_T("%d"), totalcount);
	m_list_stat.SetItemText(row, 3, strTemp);

	strTemp.Format(_T("%d"), age[0]);
	m_list_stat.SetItemText(row, 4, strTemp);
	strTemp.Format(_T("%d"), age[1]);
	m_list_stat.SetItemText(row, 5, strTemp);
	strTemp.Format(_T("%d"), age[2]);
	m_list_stat.SetItemText(row, 6, strTemp);
	strTemp.Format(_T("%d"), age[3]);
	m_list_stat.SetItemText(row, 7, strTemp);
	strTemp.Format(_T("%d"), age[4]);
	m_list_stat.SetItemText(row, 8, strTemp);
	strTemp.Format(_T("%d"), age[5]);
	m_list_stat.SetItemText(row, 9, strTemp);
	strTemp.Format(_T("%d"), age[6]);
	m_list_stat.SetItemText(row, 10, strTemp);

	strTemp.Format(_T("%d"), gender[0]);
	m_list_stat.SetItemText(row, 11, strTemp);
	strTemp.Format(_T("%d"), gender[1]);
	m_list_stat.SetItemText(row, 12, strTemp);

	strTemp.Format(_T("%d"), region[0]);
	m_list_stat.SetItemText(row, 13, strTemp);
	strTemp.Format(_T("%d"), region[1]);
	m_list_stat.SetItemText(row, 14, strTemp);
	strTemp.Format(_T("%d"), region[2]);
	m_list_stat.SetItemText(row, 15, strTemp);
	strTemp.Format(_T("%d"), region[3]);
	m_list_stat.SetItemText(row, 16, strTemp);
	strTemp.Format(_T("%d"), region[4]);
	m_list_stat.SetItemText(row, 17, strTemp);
	strTemp.Format(_T("%d"), region[5]);
	m_list_stat.SetItemText(row, 18, strTemp);
	strTemp.Format(_T("%d"), region[6]);
	m_list_stat.SetItemText(row, 19, strTemp);
	strTemp.Format(_T("%d"), region[7]);
	m_list_stat.SetItemText(row, 20, strTemp);
	strTemp.Format(_T("%d"), region[8]);
	m_list_stat.SetItemText(row, 21, strTemp);
	strTemp.Format(_T("%d"), region[9]);
	m_list_stat.SetItemText(row, 22, strTemp);
	strTemp.Format(_T("%d"), region[10]);
	m_list_stat.SetItemText(row, 23, strTemp);
	strTemp.Format(_T("%d"), region[11]);
	m_list_stat.SetItemText(row, 24, strTemp);
	strTemp.Format(_T("%d"), region[12]);
	m_list_stat.SetItemText(row, 25, strTemp);
	strTemp.Format(_T("%d"), region[13]);
	m_list_stat.SetItemText(row, 26, strTemp);
	strTemp.Format(_T("%d"), region[14]);
	m_list_stat.SetItemText(row, 27, strTemp);
	strTemp.Format(_T("%d"), region[15]);
	m_list_stat.SetItemText(row, 28, strTemp);
	strTemp.Format(_T("%d"), region[16]);
	m_list_stat.SetItemText(row, 29, strTemp);
}

