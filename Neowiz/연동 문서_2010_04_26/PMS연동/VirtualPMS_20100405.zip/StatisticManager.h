#pragma once
#include "common.h"
#include "../include/ADL/PMSCommon.h"

class PMSStatInfo;
class PMSRegionInfo;
class CStMgr : public IXObject
{
	IMPLEMENT_TISAFEREFCNT(CStMgr)
	typedef IXObject TBase;
	typedef ArcMapT<PMSUnitID, PMSStatInfo * > TMapStatTbl;
	typedef ArcMapT<PMSUnitID, PMSRegionInfo *>	TMapRegionTbl;

	typedef pair<PMSUnitID, PMSStatInfo *> PairT;
	typedef pair<PMSUnitID, PMSRegionInfo *> PairT2;
public:
	STDMETHOD_(void, OnSignal)(HSIGNAL hSig, WPARAM wParam, LPARAM lParam);

public:
	BOOL Start();
	BOOL Stop();

	BOOL AddClient(DWORD dwGSID);
	void RemoveClient(DWORD dwGSID);

	void UpdateStatInfo(WPARAM wParam, LPARAM lParam);
	void DoNotCare(WPARAM wParam, LPARAM lParam);
	void SendStatReqMsg();
	void GatherStatDataReq();
private:
	BOOL CalcStatistic(tstring strsour, tstring &strCU);
	void CheckCount();
public:
	CStMgr(void);
	~CStMgr(void);
private:
	GXSigTimer m_StatTimer;
	TMapStatTbl m_mapStatTbl;
	TMapRegionTbl m_mapRegionTbl;
};

extern CStMgr theStManager;
