#include "stdafx.h"
#include ".\heartbeatmanager.h"
#include "ClientMgr.h"
#include "GSLinkmanager.h"
#include "common.h"
#include "../include/ADL/PMSStatusManagement.h"
#include "gslinkmanager.h"
#include "GSLinkManagerADL.h"
#include "GSControler.h"


CHBMgr theHBManager;
int CHBMgr::m_TSEQ =0;
CHBMgr::CHBMgr(void)
{
}

CHBMgr::~CHBMgr(void)
{
	if(m_HBTimer.IsActive())
	{
		m_HBTimer.Deactivate();
		theErr.LOG2(1,_T("[CHBMgr] Destory Timer Deact\n"));
	}
}

BOOL CHBMgr::Start()
{
	BOOL bRet=TRUE;
	bRet = bRet && m_HBTimer.Activate(GetThreadPool(), this, MG_DUETIME, MG_DUETIME);
	return bRet;
}

BOOL CHBMgr::Stop()
{
	return TRUE;
}

BOOL CHBMgr::AddClient(DWORD dwGSID, CLink *pLink)
{
	TLock lo(this);
	TMapHB::iterator it = m_mapHBTbl.find(dwGSID);
	if(it != m_mapHBTbl.end())
	{
		CHeartBeatInfo * p = it->second;
		delete p;
		theErr.LOG(1, _T("----- NOTE : alread registered GSI form HBManager ---- "));
	}
	CHeartBeatInfo *pItem = new CHeartBeatInfo;
	pItem->m_lTimeOutCount = 0;
	m_mapHBTbl[dwGSID] = pItem;
	theErr.LOG(1,_T("[CHBMgr] AddClient - Client : %s\n"), str2tstr(pLink->m_sSourceIP).c_str());
	return TRUE;
}
void CHBMgr::RemoveClient(DWORD dwGSID)
{
	TLock lo(this);
	TMapHB::iterator it = m_mapHBTbl.find(dwGSID);
	if(it != m_mapHBTbl.end())
	{
		theErr.LOG(1,_T("[CHBMgr] RemoveClient - Client : \n"));
		CHeartBeatInfo *p = it->second;
		m_mapHBTbl.erase(it);
		delete (p);
	}
}

STDMETHODIMP_(void) CHBMgr::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	TLock lo(this);
	if(hSig == (HSIGNAL)HASIGNAL_HEARTBEATANS)
	{
		TMapHB::iterator it = m_mapHBTbl.find((DWORD)lParam);		
		if (it != m_mapHBTbl.end())	
		{
			CHeartBeatInfo* pItem = it->second;

			// truewise : ��Ʈ��Ʈ ���� �ذ�
			//if (pItem->m_lTimeOutCount <= 4)
			{
				//theErr.LOG(1,"[HBMANAGER] GSID:%d OutCount %d \n",it->first, pItem->m_lTimeOutCount);
				pItem->m_lTimeOutCount = 0;
			}
		}
	}
	else if(hSig == (HSIGNAL)0) 
	{
		return;
	}
	else if(m_HBTimer.IsHandle(hSig))
	{
		if(theGSmanager.IsExistLink())	// text base ..
		{
			if(m_TSEQ>=65535)
				m_TSEQ = 0;
			else
				m_TSEQ++;
			char sztemp[256]={0,};

			sprintf(sztemp,"HBREQ%%%d\r\n",m_TSEQ);
			GBuf buf((LPVOID)sztemp,strlen(sztemp)+1);

			LPXBUF lpXBuf = buf.Detach();
			::XsigQueueSignal(GetThreadPool(), &theGSmanager, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf);
			CheckCount();
		}
		
		if(theGSLinkManagerADL.IsExistLink())	// ADL base
		{
			if(m_TSEQ>=65535)
				m_TSEQ = 0;
			else
				m_TSEQ++;
			
			PayloadGS pld(PayloadGS::msgPMSHeartBeatReq_Tag);
			pld.un.m_msgPMSHeartBeatReq->m_lIndexNo = m_TSEQ;

			GBuf buf;
			::LStore(buf, pld);
			LPXBUF lpXBuf = buf.Detach();
			::XsigQueueSignal(GetThreadPool(), &theGSLinkManagerADL, (HSIGNAL)HASIGNAL_REQSENDTOGS, 0, (LPARAM)lpXBuf);
			CheckCount();
		}
	}
}


void CHBMgr::CheckCount()
{
	tstring strTime;
	PMSFaultInfo pmsFaultInfo;

	ForEachElmt(TMapHB, m_mapHBTbl, it, jt)
	{	
		// ���� GSI�� ���°� Run �� ���°� �ƴϸ� HeartBeat�� ������ �ʴ´�.
		if (!theGSControler.GetGSIStatus(it->first))
			continue;

		CHeartBeatInfo *p = it->second;
		ASSERT( p != NULL);
		p->m_lTimeOutCount++;
	
		LONG lLevel = 0L;
		if( (p->m_lTimeOutCount > 5 ) && (p->m_lTimeOutCount <= 7 ) )
			lLevel = FL_ALERT;
		else if(p->m_lTimeOutCount >= 8 )
			lLevel = FL_CRITICAL;
		else 
			continue;
		//���μ��������� ALive������ �Ǵ��ϰ� �˷��ִ� �κ��� �߰��ؾ��Ѵ�.
		
		GetTimeFormat(strTime,3);

		pmsFaultInfo.m_lGSState = GS_START;
		pmsFaultInfo.m_lLevel = lLevel;
		pmsFaultInfo.m_lReason = FT_GSIDELAYHB;
		pmsFaultInfo.m_dwGSID = it->first;
		pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
		pmsFaultInfo.m_sReason = "HEARTBEAT DELAY";
		pmsFaultInfo.m_sDesc = "HEARTBEAT DELAY";
		pmsFaultInfo.m_sProc = "STOP";
		pmsFaultInfo.m_sTime = tstr2str(strTime);
		pmsFaultInfo.m_sSSN = "";


		GBuf buf;
		::BStore(buf, pmsFaultInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, 0, (LPARAM)lpXBuf);

		theErr.LOG(1,_T("Error Heartbeat timeout  GSID:%d FAULT Count %d  ##### \n"), it->first, p->m_lTimeOutCount);
		pmsFaultInfo.Clear();
	}
}


