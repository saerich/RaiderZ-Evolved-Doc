
#ifndef __GSLISTNERADL_H
#define __GSLISTNERADL_H

#pragma once
#include "link.h"


class CGSListenerADL : public GXListener
{
	IMPLEMENT_TISAFEREFCNT(CGSListenerADL)
public:
	typedef GXListener TBase;

public:
	CGSListenerADL(void);
	~CGSListenerADL(void);

	BOOL RunGSListenerADL(LONG lPort);

protected:
	virtual BOOL OnError(CLink* pLink, long lEvent, int nErrorCode);
	virtual void OnAccept(SOCKET hSocket,int nErrorCode, LPCSTR szAddr, LONG lPort);


};

extern CGSListenerADL theGSListenerADL;
#endif