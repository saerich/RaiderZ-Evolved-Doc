
#include "stdafx.h"
#include "DbManager.h"
#include "ConfigInfo.h"

using namespace std;

CDBManager thedbmanager;
CDBManager::CDBManager(void)
{
	m_spConnection = NULL;
	m_cmd = NULL;
}

CDBManager::~CDBManager(void)
{
}


BOOL CDBManager::Open()
{
	return TRUE;
}

STDMETHODIMP_(void) CDBManager::OnSignal(HSIGNAL hSig,WPARAM wParam,LPARAM lParam)
{
	TLock lo(this);

	if(INSERT_CU == wParam)
	{
	}
	else
	{
	}
}

BOOL CDBManager::InitDBManager(TCHAR szDBHostName[],tstring &strBaseInfo)
{
	USES_CONVERSION;
	_bstr_t  bstrcon;
	_bstr_t bstrHostName,bstrUserName;
	
	TCHAR szConn[1024]={0,};

	_stprintf(szConn, szDBConnString, g_ConfigInfo.GetDBName().c_str(), g_ConfigInfo.GetDBServer().c_str());

	bstrcon.Assign(T2BSTR(szConn));
	HRESULT hr;

	try	
	{	
		hr = m_spConnection.CreateInstance(__uuidof(Connection));
		if(FAILED(hr))
		{
			theErr.LOG(0, _T("Connection Create Error\n"));
			return FALSE;
		}
		hr = m_spConnection ->Open(bstrcon, _bstr_t(L""), _bstr_t(L""), adModeUnknown);
		if(FAILED(hr))
		{	
			theErr.LOG(0, _T("DB Open Err\n"));
			return hr;
		}
		_CommandPtr cmd;
		hr =cmd.CreateInstance(__uuidof(Command));

		if(FAILED(hr))
		{
			return FALSE;
		}

		char cHostName[100] = {0 ,};
		tstring strHostName;

		HOSTENT* hostinfo;
		memset(cHostName,0,sizeof(cHostName));
		::gethostname(cHostName,sizeof(cHostName));
		hostinfo = ::gethostbyname(cHostName);
	  
		bstrHostName.Assign(T2BSTR(A2T(cHostName)));	

		//AfxMessageBox(_T("[DBMANAGER] ===== Host Name : %s =====\n"), A2T(cHostName));

		cmd->ActiveConnection= m_spConnection;
		cmd->CommandText = _bstr_t("psp_getHAstartInfo_hostname");
		cmd->CommandType = adCmdStoredProc;

		cmd->Parameters->Append( cmd->CreateParameter(_bstr_t("hostname"),adVarChar,adParamInput,20,_variant_t(bstrHostName)));
		cmd->Parameters->Append( cmd->CreateParameter(_bstr_t("username"),adVarChar,adParamInput,20,_variant_t(bstrHostName)));
		cmd->Parameters->Append( cmd->CreateParameter(_bstr_t("ReturnString"),adVarChar,adParamOutput,5120,_variant_t("0")));
		cmd->Parameters->Append( cmd->CreateParameter(_bstr_t("RetVal"),adInteger,adParamReturnValue,4,_variant_t("0")));
		
		cmd->Execute(NULL,NULL,adCmdStoredProc);

		int nRet=0;
		if(cmd->Parameters->Item[ _variant_t("RetVal")]->Value.vt)
		{
			nRet = cmd->Parameters->Item[ _variant_t("RetVal")]->Value.intVal;
		}
		
		if(cmd->Parameters->Item[ _variant_t("ReturnString")]->Value.vt != NULL)
		{
			strBaseInfo =(_bstr_t)cmd->Parameters->Item[_variant_t("ReturnString")]->Value.bstrVal;

		}

		m_spConnection->Close();	

		return TRUE;	
	}
	catch(_com_error &e) 
	{
		theErr.LOG(0, _T("DB Com Exception\n"));
		theErr.LOG(0, e.ErrorMessage());
		hr = e.Error();
		return hr;
	}
	catch(...) 
	{
		theErr.LOG(0, _T("DB Exception\n"));
		hr = E_UNEXPECTED;
		return hr;
	}
}

