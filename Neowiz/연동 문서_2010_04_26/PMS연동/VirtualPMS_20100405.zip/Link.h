#pragma once

#include <GXLinkUtl.h>

class CLink : public GXLink
{
	typedef GXLink TBase;

public :
	CLink() { m_lGSID = 0L; };
	CLink(LPCSTR sIP) { m_sSourceIP = sIP; m_lGSID = 0L;}
	virtual ~CLink() {};

	void SetGSID(LONG lGSID) { m_lGSID = lGSID; }
	LONG GetGSID() { return m_lGSID; };
	string GetGSIDStr()
	{
		char _gsid[10] = {0, };
		itoa(m_lGSID, _gsid, sizeof(_gsid));
		string _temp(_gsid);
		return _temp;
	}
public:
	string m_sSourceIP;

private:
	LONG m_lGSID;
};
