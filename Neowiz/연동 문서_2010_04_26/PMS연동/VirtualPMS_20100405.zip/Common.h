#ifndef _COMMON_H
#define _COMMON_H

#include "Link.h"
#include "SysTimeMaker.h"

#define MG_DUETIME 15000
#define DUETIME 15000

#define HASIGNAL_GSFAULT		0xFFFFFFFE
#define HASIGNAL_GSISTARTNTF	0xFFFFFFFD
#define HASIGNAL_HEARTBEATANS	0xFFFFFFFC
#define HASIGNAL_REQSENDTOGS	0xFFFFFFFB
#define HASIGNAL_UPDATE			0xFFFFFFFA
#define HASIGNAL_DONOTCARE		0xFFFFFFF9


#define HASIGNAL_CONTROLREQ		0xFFFFFFEE
#define HASIGNAL_REQSENDTOMA	0xFFFFFFED
#define HASIGNAL_STATANS		0xFFFFFFEC

#define HASIGNAL_WARNINGNTF		0xFFFFFFEA

#define HASIGNAL_ANNOUNCEREQ	0xFFFFFFE8
#define HASIGNAL_ORDERREQ		0xFFFFFFE7
#define HASIGNAL_PERFORMREQ		0xFFFFFFE6
#define HASIGNAL_STATINFOREQ	0xFFFFFFE5


enum {
	POST_HEALTHANS = 1, 
	POST_HEARTBEATANS,
	POST_STATANS,
	POST_ANS_DONT_CARE,
	DB_CU=1001
};

enum E_STATE{INIT,ALREADY};

enum CONTROLTYPE 
{
	GS_MINVAL = 1,	// �̺��� ���� ���� ��� ����..
	GS_START= 5, 
	GS_STOP, 
	GS_RESTART, 

	GS_MAXVAL = 8888
};

enum CONNTECTIONSTATE
{
	GS_WAITFOR_START = 1,
	GS_WAITFOR_STOP = 2
};

int GetString(tstring &strsur,tstring &strdest,TCHAR* cdelimiter);
int GetString(tstring &strsur,tstring &strdest,TCHAR cdelimiter);

tstring GetTimeFormat(tstring &str,int nType);


class CGSInfoTable
{
	IMPLEMENT_TISAFE(CGSInfoTable)
public: 
	BOOL InitSeverBaseInfo();


	const tstring& GetGSBaseInfo()const {return m_sSvrBaseInfo; };
	const tstring& GetMAIP() const {return m_strMAIP; }
	const tstring& GetMAPort() const {return m_strMAPort; }
	const tstring& GetHAIP()const {return m_strHAIP;}
	const tstring& GetHAPort() const {return m_strHAPort;}
	const tstring& GetHAID() const{return m_strHAID;}
	const DWORD GetHostGroupID() const {return (DWORD)_tstoi(m_strHostGroupID.c_str()); }

	const tstring& GetHostName() const { return m_sHostName; }
private:
	tstring m_sSvrBaseInfo;

	tstring m_strMAIP;
	tstring m_strMAPort;
	tstring m_strHAIP;
	tstring m_strHAPort;
	tstring m_strHAID;
	tstring m_strHostGroupID;

	tstring m_sHostName;
};

extern CGSInfoTable theGSInfoTable;

/////////////////////////////////////////////////////////////////////////////////////
class GSINFO
{
public:
	ArcMapT<tstring,tstring> m_infoMap;
	CLink *m_pLink;
	int m_nindex;
	HANDLE m_handle;
	LONG m_lState;
	tstring m_sOptAddr;
	tstring m_sStartTime;
	DWORD	m_dwProcessID;
	LONG m_lConn;   // 2005/12/05  HA ��� ���� ���� ���� ó���� ���� flag

public:
	GSINFO()
	{
		m_pLink = NULL; m_nindex = 0; m_handle = NULL; m_lState = 0L;	m_dwProcessID = 0;
	}
};

typedef ArcMapT<tstring, GSINFO*> GSINFOTABLE;	
class CGSSessionTable
{
	IMPLEMENT_TISAFE(CGSSessionTable)
public:
	BOOL InitGSSessionTable();
	GSINFOTABLE & GetTable();
	void Clear();
	GSINFO * FindServer(CLink *pLink,int & nIndex,tstring & strGSID);
	BOOL GetServer(GSINFO & svrInfo, CLink *pLink,int &nindex,tstring &strGSID);
	GSINFO * FindServer(tstring sGSID);
	BOOL GetServer(GSINFO & svrInfo, tstring sGSID);
	BOOL SetRecord(tstring sGSID, GSINFO & gsInfo);
	void ResetRecord(DWORD dwGSID);
	BOOL GetTitle(tstring &sPerfName, DWORD dwGSID);
	LONG GetSSN(tstring &sGSID);
	BOOL IsExist(DWORD dwGSID);
	BOOL FindServer(tstring & sAppName, tstring & sGSID);
private:
	GSINFOTABLE m_gsBaseinfo; //Gameserver Baseinfo

};

extern CGSSessionTable theGSSessionTable;

#endif 
