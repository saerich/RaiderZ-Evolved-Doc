#pragma once

//#include "../include/ADL/PMSCommon.h"
//#include "../include/ADL/PMSGSCommon.h"

#define ORA_CONSTRING \
	L"Provider=SQLOLEDB.1;"\
	L"Data Source=%s;" \
	L"User Id=%s;" \
	L"PASSWORD=%s;"


enum {INSERT_CU=2001};

class CDBManager : public IXObject
{
	IMPLEMENT_TISAFEREFCNT(CDBManager)
	CDBManager(void);
public:
	virtual ~CDBManager(void);
	STDMETHOD_(void, OnSignal) (HSIGNAL hSig, WPARAM wParam, LPARAM lParam);

public:
	BOOL Open();
	BOOL InitDBManager(TCHAR szDBHostName[],tstring &strBaseInfo);
private:

protected:
	_ConnectionPtr m_spConnection;
	_CommandPtr m_cmd;
	_RecordsetPtr m_rs;

private:
	tstring m_strconnection;
	tstring m_strUserID;
	tstring m_strPassword;
};

extern CDBManager thedbmanager;
