#include "StdAfx.h"
#include "GSLinkManager.h"
#include "ClientMgr.h"
#include "PerformanceManager.h"
#include "StatisticManager.h"
#include "common.h"
#include "sysTimeMaker.h"
#include <shellapi.h>
#include "Control.h"
#include "GSControler.h"
#include "ConfigInfo.h"

#include "MainFrm.h"
#include "PMSConnServer.h"
#include "PMSConnServerDoc.h"
#include "PMSConnServerView.h"

CGSLinkManager theGSmanager;
int CGSLinkManager::m_Seq = 0;
DWORD CGSLinkManager::m_dwID = 0;



CGSLinkManager::CGSLinkManager(void)
{
}


CGSLinkManager::~CGSLinkManager(void)
{
	theGSSessionTable.Clear();
}


BOOL CGSLinkManager::OnError(CLink * pLink, long lEvent,int nErrorCode)
{
	int nIndex;
	tstring strGSID;

	GSINFO *pInfo = theGSSessionTable.FindServer(pLink, nIndex ,strGSID);
	if(pInfo) 
	{
		tstring strTime;
		GetTimeFormat(strTime,3);
		DWORD dwGSID = _tstoi(strGSID.c_str());

		PMSFaultInfo pmsFaultInfo;
		pmsFaultInfo.m_lGSState = pInfo->m_lState;
		pmsFaultInfo.m_lLevel = FL_CRITICAL;
		pmsFaultInfo.m_lReason = FT_GSITERM;
		pmsFaultInfo.m_dwGSID = dwGSID;
		pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
		pmsFaultInfo.m_sReason = "GSI TERMINATED" ;
		pmsFaultInfo.m_sDesc = "GSI TERMINATED";
		pmsFaultInfo.m_sProc = "RESTRART";
		pmsFaultInfo.m_sTime = tstr2str(strTime);
		pmsFaultInfo.m_sSSN = "";// theGSInfoTable.GetSSN();


		GBuf buf;
		::BStore(buf, pmsFaultInfo);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, (WPARAM)0, (LPARAM)lpXBuf);

		theHBManager.RemoveClient(dwGSID);
		thePfManager.RemoveClient(dwGSID);
		theStManager.RemoveClient(dwGSID);
		theGSSessionTable.ResetRecord(dwGSID);
	}
	theErr.LOG(1,_T("OnError from GSLinkManager %s (%d) ErrorCode :%u\n"),strGSID.c_str(), pLink->GetHandle(), GetLastError());

	RemoveLink(pLink);
	pLink->Unregister();
	delete pLink; 

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// 
BOOL CGSLinkManager::AddClient(SOCKET hSocket, LPCSTR sIP)
{
	TLock lo(this);
	ASSERT(hSocket!=INVALID_SOCKET);

	CLink *pLink = new CLink(sIP);

	ASSERT(pLink!=NULL);

	if(!pLink->Register(hSocket,this,HSIGNAL_XLINKHANDLER))
	{
		delete pLink;
		return FALSE;
	}
	
	if(! AddLink(pLink))
	{
		delete pLink;
		return FALSE;
	}

	theErr.LOG(1,_T("[TEXT] GS Link Count .. TOTAL GSI  : %d\n"), mLinkMap.size());
	return TRUE;
}

BOOL CGSLinkManager::IsExistLink()
{
	return !mLinkMap.empty();
}

STDMETHODIMP_(void) CGSLinkManager::OnSignal(HSIGNAL hSig, WPARAM wParam, LPARAM lParam)
{
	TLock lo(this);
	if(hSig == (HSIGNAL)HASIGNAL_ANNOUNCEREQ)
	{
		TreatAnnounceMsg((LPVOID)lParam);
	}
	//else if(hSig == HASIGNAL_ORDERREQ)
	//{
	//	TreatOrderMsg((LPVOID)lParam);
	//}
	else if(hSig == (HSIGNAL)HASIGNAL_REQSENDTOGS)
	{
		LPXBUF lpXBuf = (LPXBUF) lParam;
		GBuf buf(lpXBuf, FALSE);
		ForEachElmt(TLinkMap,mLinkMap,it,jt)
		{
			CLink *p = (*it).second;
			ASSERT(p!=NULL);
			p->DoSend(buf);
		}		
	}
	else if(hSig == 0)
	{
		;	
	}
	else
	{
		TBase::OnSignal(hSig, wParam, lParam);
	}
}

void CGSLinkManager::TreatAnnounceMsg(LPVOID lpV)
{	
	if(!IsExistLink()) return;
	LPXBUF lpXBuf = (LPXBUF)lpV;
	GBuf buf(lpXBuf, FALSE);
	PMSAnnounceReq msg;
	::BLoad(msg, buf);

/*
	tstring strTime;
	TCHAR *sztemp=NULL;
	GetTimeFormat(strTime, 1);				
	sztemp = new TCHAR[msg.m_sAnnMsg.length() + strTime.length() + 15];
	//ANNO + delimiter + ������ ����%YYYY-MM-DD-HH-MM-SS
	_stprintf(sztemp,_T("ANNO%%%s%%%s"), msg.m_sAnnMsg.c_str(), strTime.c_str());
	GBuf buf2((LPVOID)sztemp, _tcslen(sztemp) + 1);
*/
	tstring strTime;

	char *sztemp=NULL;
	GetTimeFormat(strTime, 1);				

	// Japan
/*
	char *szUnicode=NULL;
	int len = msg.m_sAnnMsg.length() * 2;
	szUnicode = new char[len + 1];
	memcpy(szUnicode, msg.m_sAnnMsg.c_str(), sizeof(szUnicode));
	string tmpAnnMsg = string(szUnicode);
*/

	// Original
	string tmpAnnMsg = tstr2str(msg.m_sAnnMsg);


	string tmpTime = tstr2str(strTime);

	sztemp = new char[tmpAnnMsg.length() + tmpTime.length() + 15];
	//ANNO + delimiter + ������ ����%YYYY-MM-DD-HH-MM-SS
	sprintf(sztemp,"ANNO%%%s%%%s", tmpAnnMsg.c_str(), tmpTime.c_str());
	GBuf buf2((LPVOID)sztemp, strlen(sztemp) + 1);

	ForEachElmt(TLinkMap, mLinkMap, it, jt)
	{
		CLink *p = (*it).second;
		ASSERT(p!=NULL);
		
		if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[TEXT] Announce Message .. To [ %s ] : Msg [ %s ] \n"), str2tstr(p->m_sSourceIP).c_str(), msg.m_sAnnMsg.c_str());
		p->DoSend(buf2);
	}
	delete [] sztemp;
}

//void CGSLinkManager::TreatOrderMsg(LPVOID lpV)
//{
//	// string base������ order�� �������� �ʾ���...
//	GBuf buf((LPXBUF)lpV, FALSE);
//	PMSOrderReq msg;
//	::BLoad(msg, buf);
//
//
//	string _shaid =  theGSInfoTable.GetHAID();
//	PMSMessage_MA pld(PMSMessage_MA::orderAns_Tag);
//	pld.un.m_orderAns->m_dwHAID = msg.m_dwHAID;
//	pld.un.m_orderAns->m_dwMCID = msg.m_dwMCID;
//	pld.un.m_orderAns->m_lErr = ;
//	pld.un.m_orderAns->m_lTargetRange = msg.m_lTargetRange;
//	pld.un.m_orderAns->m_sAnsTime = ;
//	pld.un.m_orderAns->m_sOrderName = msg.m_sOrderName;
//	pld.un.m_orderAns->m_sOrderVal = msg.m_sOrderVal;
//	pld.un.m_orderAns->m_sReqTime = msg.m_sReqTime;
//	pld.un.m_orderAns->m_unitID = msg.m_unitID;
//	GBuf buf2;
//	::LStore(buf2, pld);
//	LPXBUF lpXBuf = buf2.Detach();
//	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_ORDERANS, (WPARAM)0, (LPARAM)lpXBuf);
//}

BOOL CGSLinkManager::RemoveClient(CLink *pLink)
{
	TLock lo(this);

	pLink->Unregister();
	delete pLink;
	return TRUE;
}


int CGSLinkManager::Parsstring(tstring str, tstring &strdest)
{
	BOOL bRet=TRUE;

	tstring::iterator it;

	int nlen = str.find(_T("\r\n\0"));
	if(nlen ==-1)
		bRet = -1;
	else
		strdest.assign(str,0,nlen);
	return nlen;
}


BOOL CGSLinkManager::OnReceive(CLink *pLink)
{
	USES_CONVERSION;

	int nOrglen=0;
	LPXBUF OrgMsgBuf = NULL;	

	if(!pLink->CopyRecv(&OrgMsgBuf))
	{
		return FALSE;
	}
	tstring strOrgMessage;
	tstring strMessage;
	tstring strHeader;
	nOrglen = OrgMsgBuf->GetLength();

	//strOrgMessage.assign(OrgMsgBuf->GetData(),nOrglen);	


	//char *test = new char[nOrglen+1];
	//strcpy(test, (char*)OrgMsgBuf->GetData());
	//test[nOrglen] = '\0';
	//strOrgMessage = tstring(A2T(test));

	strOrgMessage.assign(A2T((LPCSTR)OrgMsgBuf->GetData()),nOrglen);	

	OrgMsgBuf->Delete();
	

	if (strOrgMessage.length() == 0)
	{
		theErr.LOG(1, _T("[CGSLinkManager] OnRecieve Msg from GSI] size :%d, bufLen :%d, msg :%s \n"),
			strOrgMessage.length(), nOrglen, strOrgMessage.c_str());
	}
	else
	{
		theErr.LOG(1, _T("[CGSLinkManager] OnRecieve Msg from GSI] size :%d, bufLen :%d, msg :%s "),
			strOrgMessage.length(), nOrglen, strOrgMessage.c_str());
	}

	for(;;)
	{
		int nlentemp=0;
		if (strOrgMessage.length() == 0)
		{
			break;
		}
		// Original �޽������� �޽����� �и� �Ѵ�.
		if(Parsstring(strOrgMessage,strMessage) == tstring::npos)
		{
			theErr.LOG(1,_T("[CGSLinkManager] ERROR - Parse String Error can't find \\r\\n\\0\n"));
			strOrgMessage.clear();
			pLink->RemoveRecv(nOrglen); // ���۸� ����.
			break;
		}
//		theErr.LOG(1,"Parse String After ", nlen);
//		nlen += nlentemp;
//		theErr.LOG(1,"[strOrgMessage] Len %d ", nlen);
		nlentemp = strMessage.length()+3;		
		pLink->RemoveRecv(nlentemp);//\r\n\0
		nOrglen -= nlentemp;
		strOrgMessage.erase(0, nlentemp);



		// ���ǹ��� �ҽ� �ڵ��̴�. by grayo
		//if(nlen == nOrglen)
		//{
		//	strOrgMessage.clear();
		//	break;
		//}
		//else if (nlentemp > nOrglen)
		//{
		//	// \0�� ������ ���ɼ��� ũ�� Ȯ�� ���
		//	theErr.LOG(1,"[strMessage] Len %d / %d 1 <- may be special character is missed ex) \\r\\n\\0\n", nlentemp, nOrglen);
		//	strOrgMessage.clear();
		//	break;
		//}
		//else
//		{
			//theErr.LOG(1,"[strMessage] Len %d / %s 1\n",strMessage.length(),strMessage.c_str());
//			string temp = strOrgMessage.substr(nlentemp,nOrglen-nlentemp);
//			strOrgMessage.clear();
//			strOrgMessage.assign(temp);
			// ���κ� �ڵ��� ��� ��ũ�� �޼����� �������϶� ó�� �ϱ� ���� ��ƾ���� ���δ�.
			// ���� �̹��� ó�� �� �κи�ŭ ũ�Ⱑ �۾� ���ٸ� orglen�� ũ�⵵ �۾� ���� �Ѵ�. by grayo
//			nOrglen -= nlentemp;
//		}

		GetString(strMessage, strHeader, '%');
		if(strHeader.compare(_T("INIT"))==0)
		{

			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			TreatINIT(strMessage, pLink);
		}
		else if(strHeader.compare(_T("INFA"))==0)
		{// INitialize Fault Answer..
			// GSI�� �ڱ� ������ �ϰ� ���������� ������ ����� ������.
			// GSIMamager�� ManagerCli���� GSIDNtf�� ���̶�� �뺸�Ѵ�.
			// GSI�� �ڱ����� ����� ���з� ������.
			// ���� �ڵ带 Ȯ��DB�� �����ϰ� ��ַ� ManagerCli���� �뺸�Ѵ�.
			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			TreatINFA(strMessage);			
		}
		else if(strHeader.compare(_T("HBANS"))==0)
		{
			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			TreatHBANS(strMessage);
		}
		else if(strHeader.compare(_T("PEAN"))==0 || (strHeader.compare(_T("ERR_DONT_PF"))==0))
		{
			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			TreatPEAN(strMessage, strHeader);
		}
		//���������� ��������� �����Ѵ�.
		else if(strHeader.compare(_T("STAN"))==0 || (strHeader.compare(_T("ERR_DONT_ST"))==0))
		{
			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			TreatSTAN(strMessage, strHeader);
		}
		else if(strHeader.compare(_T("HEALTHANS"))==0)
		{
			if (g_ConfigInfo.GetLogValue() > 1) theErr.LOG(1, _T("[OnReceive::%s] MSG: %s (%d)\n"), strHeader.c_str(), strMessage.c_str(), strMessage.length());
			theErr.LOG(1, _T("[CGSLinkManager] ERROR - Unknown message from GS  .. [HEALTHANS] \n"));
		}
		else if((strHeader.compare(_T("ERR_DONT_AN"))==0))
		{
		}

		strMessage.clear();
	}
	strOrgMessage.clear();
	return TRUE;
}

void CGSLinkManager::TreatINIT(tstring &sMessage, CLink * pLink)
{
	tstring strGSID,strStartTime,strUPTIME(_T("UPTIME"));
	tstring strGSStartTime, strTime;
	if(!GetString(sMessage, strGSID,'%'))
	{
		theErr.LOG(1,_T("[CGSLinkManager] TreatINIT - INIT Message Not Match\n"));
		return ;
	}
	tstring sProcessId;
	if (!GetString(sMessage, sProcessId, '%'))
	{
		theErr.LOG(1,_T("[CGSLinkManager] TreatINIT - INIT Message Not Match Failed Get Game Server's Process ID\n"));
		return ;

	}
	GSINFO gsInfo;
	gsInfo.m_pLink = pLink;
	gsInfo.m_lState = GS_START;
	GetTimeFormat(strTime,3);
	gsInfo.m_infoMap[_T("TIME")] = strTime;
	gsInfo.m_sStartTime = strTime;
	gsInfo.m_dwProcessID = _tstoi(sProcessId.c_str());

	if(!theGSSessionTable.SetRecord(strGSID, gsInfo))
	{
		RemoveLink(pLink);
		pLink->Unregister();
		delete pLink; 

		theErr.LOG(1,_T("[CGSLinkManager] TreatINIT - INITNTF Invalid GSID %s\n"),strGSID.c_str());
		return ;
	}

	PMSStartupInfo startInfo;
	startInfo.m_dwGSID = _tstol(strGSID.c_str());
	startInfo.m_sStartTime = tstr2str(strTime);
	GBuf buf;
	::BStore(buf, startInfo);
	LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSISTARTNTF, 0, (LPARAM)lpXBuf);

	theHBManager.AddClient(startInfo.m_dwGSID, pLink);
	thePfManager.AddClient(startInfo.m_dwGSID, pLink);
	theStManager.AddClient(startInfo.m_dwGSID);

	sMessage.clear();
	theErr.LOG(1,_T("[CGSLinkManager] TreatINIT - INIT Success GSID %d \n"), startInfo.m_dwGSID);

	pLink->SetGSID(startInfo.m_dwGSID);

}

void CGSLinkManager::TreatINFA(tstring &sMessage)
{
	tstring strGSID;
	if(!GetString(sMessage, strGSID, '%'))
	{
		theErr.LOG(1,_T("[CGSLinkManager] TreatINFA - INIT Message Not Match\n"));
	}
	GSINFO *pinfo = theGSSessionTable.FindServer(strGSID);
	if(!pinfo)
	{
		theErr.LOG(1,_T("[CGSLinkManager] TreatINFA ERROR - received check message Unknowm server : %s \n"), strGSID.c_str());
		return;	
	}

	tstring sTime; 
	GetTimeFormat(sTime, 3);

	PMSFaultInfo pmsFaultInfo;
	pmsFaultInfo.m_dwGSID = _tstol(strGSID.c_str());
	pmsFaultInfo.m_lGSState = GS_START;
	pmsFaultInfo.m_sReason = "GSI INITFAULT";
	pmsFaultInfo.m_lLevel =  FL_CRITICAL;
	pmsFaultInfo.m_lReason = FT_GSDETAIL;
	pmsFaultInfo.m_sDesc = "GSI INITFAULT";
	pmsFaultInfo.m_sHAID = tstr2str(theGSInfoTable.GetHAID());
	pmsFaultInfo.m_sProc = "RESTRART";
	pmsFaultInfo.m_sSSN = "";
	pmsFaultInfo.m_sTime = tstr2str(sTime);

	GBuf buf;
	::BStore(buf, pmsFaultInfo);
	LPXBUF lpXBuf = buf.Detach();

	::XsigQueueSignal(GetThreadPool(), &theManagerCli, (HSIGNAL)HASIGNAL_GSFAULT, (WPARAM)0, (LPARAM)lpXBuf);
}

void CGSLinkManager::TreatHBANS(tstring &sMessage)
{
	tstring strGSID;
	GetString(sMessage, strGSID, '%');
	DWORD dwGSID = _tstol(strGSID.c_str());

	::XsigQueueSignal(GetThreadPool(), &theHBManager, (HSIGNAL)HASIGNAL_HEARTBEATANS, 0, (LPARAM)dwGSID);
}

void CGSLinkManager::TreatPEAN(tstring &sMessage, tstring & sHeader)
{	// GS�� ���� ���� performance data.. table update.. MA�� ������ MA�� �䱸 �ÿ�..

//theErr.LOG(1,"CGSLinkManager::TreatPEAN - sMessage %s\n", sMessage.c_str());

	PMSPerformInfo Info;
	if(sHeader.compare(_T("ERR_DONT_PF")) == 0)
	{
		Info.m_dwGSID = _tstol(sMessage.c_str());

//theErr.LOG(1,"CGSLinkManager::TreatPEAN 1 - sMessage=%s\n", sMessage.c_str());

		GBuf buf;
		::BStore(buf, Info);
		LPXBUF lpXBuf = buf.Detach();
		::XsigQueueSignal(GetThreadPool(), &thePfManager, (HSIGNAL)HASIGNAL_DONOTCARE, 0, (LPARAM)lpXBuf);
	}
	else
	{
		tstring sGSID;
		GetString(sMessage, sGSID, '%');
		Info.m_dwGSID = _tstoi(sGSID.c_str());

		tstring _stemp;

		GET_VIEW()->SetListItem(Info.m_dwGSID, 0, 0, _T("�����ս�"), sMessage.c_str());

		while(GetString(sMessage, _stemp, '%'))
		{
			Info.m_vecPerform.push_back(_tstoi(_stemp.c_str()));
			_stemp.clear();
		}

		GBuf buf;
		::BStore(buf, Info);
		LPXBUF lpXBuf = buf.Detach();

		::XsigQueueSignal(GetThreadPool(), &thePfManager, (HSIGNAL)HASIGNAL_UPDATE, 0, (LPARAM)lpXBuf);
	}
}

void CGSLinkManager::TreatSTAN(tstring &sMessage, tstring &sHeader)
{
	PMSStatInfo statInfo;
	PMSRegionInfo regionInfo;
	if(sHeader.compare(_T("ERR_DONT_ST"))==0)
	{
		statInfo.m_unitID.m_dwGSID = _tstoi(sMessage.c_str());
		statInfo.m_unitID.m_dwSSN = theGSSessionTable.GetSSN(sMessage);
		GBuf buf;
		::BStore(buf, statInfo);
		LPXBUF lpXBuf = buf.Detach();

		GBuf buf2;
		::BStore(buf2, regionInfo);
		LPXBUF lpXBuf2 = buf2.Detach();
		::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_DONOTCARE, (WPARAM)lpXBuf, (LPARAM)lpXBuf2);
	}
	else 
	{
		// GSLinkManager������ PMSStatInfo�� �� ä��� ����.. 
		// �� �����ʹ� MA���� �˾Ƽ� ó��.. 
		tstring sGSID;
		tstring _cu;
		GetString(sMessage, sGSID, '%');
		statInfo.m_unitID.m_dwGSID = _tstoi(sGSID.c_str());
		statInfo.m_unitID.m_dwSSN = theGSSessionTable.GetSSN(sGSID);
		statInfo.m_unitID.m_dwCategory = 0UL;

		// truewise : ��� ���� ���� (2005/11/05)
		GSINFO *gs = theGSSessionTable.FindServer(sGSID);

		if ((gs) && (gs->m_lState == GS_STOP))
		{
			GBuf buf;
			tstring s_sUpTime;
			GetTimeFormat(s_sUpTime, 3);
			statInfo.m_sUpTime = tstr2str(s_sUpTime);
			::BStore(buf, statInfo);
			LPXBUF lpXBuf = buf.Detach();

			GBuf buf2;
			::BStore(buf2, regionInfo);
			LPXBUF lpXBuf2 = buf2.Detach();
			::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, (WPARAM)lpXBuf, (LPARAM)lpXBuf2);
		}
		else
		{
			GetString(sMessage, _cu, '%');
			statInfo.m_dwCU = _tstoi(_cu.c_str());
			tstring s_sUpTime;
			GetTimeFormat(s_sUpTime, 3);
			statInfo.m_sUpTime = tstr2str(s_sUpTime);
			GBuf buf;
			::BStore(buf, statInfo);
			LPXBUF lpXBuf = buf.Detach();

			GET_VIEW()->SetListItem(statInfo.m_dwCU, 0, 0, _T("���"), sMessage.c_str());

			// region statistics������ ����.. 
			ParseStatInfo(regionInfo.m_vecRegion, sMessage);
			regionInfo.m_unitID.m_dwGSID = statInfo.m_unitID.m_dwGSID;
			regionInfo.m_unitID.m_dwSSN = statInfo.m_unitID.m_dwSSN;
			statInfo.m_unitID.m_dwCategory = 0UL;
			GBuf buf2;
			::BStore(buf2, regionInfo);
			LPXBUF lpXBuf2 = buf2.Detach();
			::XsigQueueSignal(GetThreadPool(), &theStManager, (HSIGNAL)HASIGNAL_UPDATE, (WPARAM)lpXBuf, (LPARAM)lpXBuf2);
		}
	}
}

void CGSLinkManager::ParseStatInfo(vecRegionInfoT & vecRegion, tstring & sStatList)
{
	// ADLManager�� ���ϴ� text base�� GS ��, �ܺ� ������ �Ϻδ� SSN : GSID = 1 : 1�� ���踦 ����.
	tstring _temp;

//	theErr.LOG(1,"[GS->HA vector �ֱ��� sMessage : %s ]\n", sStatList.c_str());
	while ( sStatList.length() )
	{
		if ( GetString(sStatList, _temp, '%') != 0 )
		{
//			theErr.LOG(1,"[GS->HA vector �ִ� string : %s ]\n", _temp.c_str());
			vecRegion.push_back(_tstol(_temp.c_str()));
			_temp.clear();
		}
		else// if ( sStatList.length() == 1 ) 
		{
//			theErr.LOG(1,"[GS->HA vector �ִ� ������ string : %s ]\n", sStatList.c_str());
			vecRegion.push_back(_tstol(sStatList.c_str()));
			//sStatList.erase(sStatList.begin(),sStatList.begin() + 1);
			sStatList.clear();
		}
	}

//	theErr.LOG(1,"[GS->HA vector�� size : %d ]\n", vecRegion.size());
}

///////////////////////////////////////////////////////////////////////////////////////////////////

BOOL CGSLinkManager::Stop()
{

	//TLock lo(this);

	//ForEachElmt(GSINFOTABLE, m_gsBaseinfo, i, j)
	//{
	//	GSINFO* pginfo = i->second;
	//	pginfo->m_pmap.clear();
	//	delete pginfo;
	//}
	//m_gsinfotable.clear();

	//m_timerAlive.Deactivate();

	//theErr.LOG(2, "CGSLinkManager::Stop()\n");

	return TRUE;
}

//��� GSI���� �������Ѵ�.
BOOL CGSLinkManager::SendToGSIHeartBeatReq()
{
	string strbuf;
	TLinkMap::iterator it;
	TLinkMap gsmap;
	char sztemp[256]={0,};

	if(m_Seq==65535)
		m_Seq = 0;
	else
		++m_Seq;

	sprintf(sztemp,"HBREQ%%%d\r\n",m_Seq);

	GBuf buf((LPVOID)sztemp,strlen(sztemp)+1);

	gsmap = GetLinkMap();
	for(it= gsmap.begin();it!=gsmap.end();it++)
	{
		((*it).second)->DoSend(buf);
		
	}
	if (g_ConfigInfo.GetLogValue() > 0) theErr.LOG(1,_T("[HBManager] %d \n"),gsmap.size());

#ifdef _DEBUG
	//TLOG1("[CGSLINKMANAGER SendToGSIHeartBeatReq] To GSI%s\n",sztemp);
#endif

	return TRUE;
}


BOOL CGSLinkManager::SendToGSIPerformanceReq()
{
	string strbuf;
	TLinkMap::iterator it;
	TLinkMap gsmap;
	char sztemp[256]={0,};

	sprintf(sztemp,"PERE\r\n");
	GBuf buf((LPVOID)sztemp,strlen(sztemp)+1);

	gsmap = GetLinkMap();
	for(it= gsmap.begin();it!=gsmap.end();it++)
	{
		(it->second)->DoSend(buf);
	}

#ifdef _DEBUG
	//TLOG1("[CGSLINKMANAGER SendToGSIPerformanceReq] Send To GSI %s\n",sztemp);
#endif

	return TRUE;
}


BOOL CGSLinkManager::SendToGSIStatisticReq()
{
	string strbuf;

	TLinkMap::iterator it;
	TLinkMap gsmap;
	char sztemp[256]={0,};

	sprintf(sztemp,"STRE\r\n");

	GBuf buf((LPVOID)sztemp,strlen(sztemp)+1);

	gsmap = GetLinkMap();
	for(it= gsmap.begin();it!=gsmap.end();it++)
	{
		(it->second)->DoSend(buf);
	}

#ifdef _DEBUG
	//TLOG1("[CGSLINKMANAGER SendToGSIStatisticReq] Send To GSI %s\n",sztemp);
#endif

	return TRUE;
}
