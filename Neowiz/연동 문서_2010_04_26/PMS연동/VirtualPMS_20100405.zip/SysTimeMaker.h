#pragma once

class CSysTimeMaker : public SYSTEMTIME
{
public:
	CSysTimeMaker(void){};
	virtual ~CSysTimeMaker(void){};

	string GetTime(string &str,int nType)
	{
		string strDate;
		memset(this, 0, sizeof(SYSTEMTIME));
		::GetLocalTime(this);
		switch(nType)
		{
		case 1:
			str = ::format("%04d/%02d/%02d\r\n", this->wYear,this->wMonth,this->wDay);		
			break;
		case 2:
			str = ::format("%04d/%02d/%02d/%02d/%02d\r\n", this->wYear,this->wMonth,this->wDay,this->wHour,this->wMinute);
			break;
		case 3:
			str = ::format("%04d-%02d-%02d %02d:%02d:%02d\r\n", this->wYear,this->wMonth,this->wDay,this->wHour,this->wMinute,this->wSecond);
			break;
		}
		return str;
	}
};
extern CSysTimeMaker theTimeMaker;
