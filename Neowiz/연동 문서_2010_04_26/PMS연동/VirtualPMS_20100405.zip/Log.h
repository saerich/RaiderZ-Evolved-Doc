// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOG_H__CC6D2ADE_8888_416C_8178_56238F90434F__INCLUDED_)
#define AFX_LOG_H__CC6D2ADE_8888_416C_8178_56238F90434F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <time.h>

class CLog  
{
protected:
	BOOL OnLoggingError(LPCTSTR lpStr);
	BOOL WriteLog( LPCTSTR lpStr );
	string MakeLogString(LPCTSTR lpStr);
	BOOL CreateLogFile();
	string GetToday();
	void CompareDate();

public:
	CLog();
	virtual ~CLog();
	
private:	
	HANDLE	m_hLogFile;
	string	m_strLogFile;
	string	m_strDate;

public:
	BOOL Initialize( LPCTSTR lpSvrName );	
public:
	BOOL FileLogMulti(LPCTSTR fmt,...);
	BOOL FileLogOne(LPCTSTR lp);
	void EventLog(LPCTSTR fmt,...);
	void DbgOut(LPCTSTR fmt,...);
};

#endif // !defined(AFX_LOG_H__CC6D2ADE_8888_416C_8178_56238F90434F__INCLUDED_)
