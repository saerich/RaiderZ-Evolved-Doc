#pragma once
#include <GXLinkUtl.h>

#include "../include/ADL/PMSCommon.h"
#include "../include/ADL/PMSGSCommon.h"
#include "link.h"

#include "HeartBeatManager.h"


#define HEART_INTERVAL		10000

enum {
	GSI_HEARTBEAT_REQ=0,
	GSI_ANNOUNCE_REQ,
	GSI_PERFORMACE_REQ,
	GSI_STATISTIC_REQ,
};


class CGSLinkManager : public XLinkManagerT<CLink>
{
	IMPLEMENT_TISAFEREFCNT(CGSLinkManager)
public:
	typedef XLinkManagerT<CLink> TBase;
	CGSLinkManager(void);
	virtual ~CGSLinkManager(void);

	BOOL AddClient( SOCKET hSocket, LPCSTR sIP);
	BOOL RemoveClient(CLink* pLink);
	BOOL IsExistLink();

	STDMETHOD_(void, OnSignal) (HSIGNAL hSig, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnReceive(CLink *pLink);
	virtual BOOL OnError(CLink* pSocket, long lEvent, int nErrorCode);

	void TreatAnnounceMsg(LPVOID lpV);
	//void TreatOrderMsg(LPVOID lpV);
public:
	BOOL Stop();

	void TreatINIT(tstring &sMessage, CLink * pLink);
	void TreatINFA(tstring &sMessage);
	void TreatHBANS(tstring &sMessage);
	void TreatPEAN(tstring &sMessage, tstring &sHeader);
	void TreatSTAN(tstring &sMessage, tstring &sHeader);

	void ParseStatInfo(vecRegionInfoT & vecRegion, tstring & sStatList);

protected:
	BOOL SendToGSIHeartBeatReq();
	BOOL SendToGSIPerformanceReq();
	BOOL SendToGSIStatisticReq();

private:
	BOOL Parsstring(tstring str,tstring &strdest);

private:
	GXSigTimer m_timerAlive;
	static int m_Seq;
	int m_nServiceType;
	static DWORD m_dwID;
};

extern CGSLinkManager theGSmanager;

